"""CLI entry point: unified subcommands for ODID capture, query, export and replay.

Usage::

    sudo odid init                                   # first-time setup wizard
    sudo odid sniff wlan1 --tui --web
    sudo odid sniff wlan1 --lat 51.5 --lon -0.12 --watchlist ids.txt
    sudo odid scan wlan1 --dwell 3 --tui
    sudo odid btsniff --lat 51.5 --lon -0.12
    sudo odid replay logs/capture.pcap --tui
    odid query --since 1h
    odid export --format kml
"""

from __future__ import annotations

import json
import logging
import math
import os
import queue
import re
import signal
import sys
import threading
import time
from collections import deque
from enum import Enum
from pathlib import Path
from types import SimpleNamespace
from typing import Optional, Annotated

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from odid import __version__

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="odid",
    help=f"OpenDroneID Sniffer & Decoder v{__version__}. ASTM F3411 compliant.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console(stderr=True)
log = logging.getLogger("odid")

# ---------------------------------------------------------------------------
# Global options (set before commands run)
# ---------------------------------------------------------------------------

_verbose = False
_log_json = False
_log_dir = "logs"
_no_pcap = False
_no_jsonl = False
_no_csv = False
_no_db = False
_max_sessions = 0
_min_free_mb = 200
_max_drones = 2000
_db_retention_days = 90
_log_dir_explicit = False
_shutdown_timeout = 10


@app.callback()
def _global(
    verbose: Annotated[Optional[bool], typer.Option("--verbose/--quiet", "-v", help="Enable debug logging")] = None,
    log_dir: Annotated[Optional[str], typer.Option("--log-dir", help="Output directory for logs/pcap/csv/db [default: logs]")] = None,
    no_pcap:  Annotated[Optional[bool], typer.Option("--no-pcap/--pcap",   help="Disable pcap capture")] = None,
    no_jsonl: Annotated[Optional[bool], typer.Option("--no-jsonl/--jsonl", help="Disable JSONL logging")] = None,
    no_csv:   Annotated[Optional[bool], typer.Option("--no-csv/--csv",     help="Disable CSV export")] = None,
    no_db:    Annotated[Optional[bool], typer.Option("--no-db/--db",       help="Disable SQLite database")] = None,
    max_sessions: Annotated[Optional[int], typer.Option("--max-sessions", metavar="N", min=0,
                            help="Keep only the N most recent session log files (0=unlimited)")] = None,
    log_json: Annotated[bool, typer.Option("--log-json", help="Emit structured JSON log records to stderr")] = False,
    timeout_shutdown: Annotated[int, typer.Option("--timeout-shutdown", metavar="N", min=1,
                                help="Seconds to wait for writer thread on shutdown (default 10)")] = 10,
):
    global _verbose, _log_json, _log_dir, _no_pcap, _no_jsonl, _no_csv, _no_db, _max_sessions, _shutdown_timeout
    global _min_free_mb, _log_dir_explicit, _max_drones, _db_retention_days

    # Precedence: explicit CLI value > TOML config > built-in default
    cfg = _config()

    def _pick(cli_val, key, default, conv):
        if cli_val is not None:
            return cli_val
        if key in cfg:
            try:
                return conv(cfg[key])
            except (TypeError, ValueError):
                typer.echo(f"WARNING: ignoring invalid config value {key}={cfg[key]!r}", err=True)
        return default

    _verbose = _pick(verbose, "verbose", False, _to_bool)
    _log_dir = _pick(log_dir, "log_dir", "logs", str)
    _log_dir_explicit = log_dir is not None or "log_dir" in cfg
    _no_pcap = _pick(no_pcap, "no_pcap", False, _to_bool)
    _no_jsonl = _pick(no_jsonl, "no_jsonl", False, _to_bool)
    _no_csv = _pick(no_csv, "no_csv", False, _to_bool)
    _no_db = _pick(no_db, "no_db", False, _to_bool)
    _max_sessions = max(0, _pick(max_sessions, "max_sessions", 0, int))
    _min_free_mb = max(0, _pick(None, "min_free_mb", 200, int))
    _max_drones = max(0, _pick(None, "max_drones", 2000, int))
    _db_retention_days = max(0, _pick(None, "db_retention_days", 90, int))
    _log_json = log_json
    _shutdown_timeout = timeout_shutdown

    _setup_logging()


_TRUE_STRINGS = {"true", "yes", "on", "1"}
_FALSE_STRINGS = {"false", "no", "off", "0"}


def _to_bool(value) -> bool:
    """Strict boolean for config values: bool, 0/1, or true/false/yes/no/on/off.

    bool() would turn the string "false" into True.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        v = value.strip().lower()
        if v in _TRUE_STRINGS:
            return True
        if v in _FALSE_STRINGS:
            return False
    raise ValueError(f"not a boolean: {value!r}")


_config_cache: Optional[dict] = None


def _config() -> dict:
    """Load the TOML config once per process."""
    global _config_cache
    if _config_cache is None:
        from odid.config import load as load_config
        _config_cache = load_config()
    return _config_cache


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

class _JSONFormatter(logging.Formatter):
    """Emit structured JSON log records."""
    def format(self, record: logging.LogRecord) -> str:
        d = {
            "ts": self.formatTime(record, datefmt="%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            d["exc"] = self.formatException(record.exc_info)
        return json.dumps(d)


class _JournalFormatter(logging.Formatter):
    """Prefix each line with the record's syslog priority (``<4>``) for journald."""
    def format(self, record: logging.LogRecord) -> str:
        from odid.web.logs import syslog_priority
        prefix = f"<{syslog_priority(record.levelno)}>"
        # journald splits on newlines: prefix every line (tracebacks too)
        return prefix + super().format(record).replace("\n", "\n" + prefix)


def _setup_logging():
    level = logging.DEBUG if _verbose else logging.INFO
    root = logging.getLogger()
    root.setLevel(level)
    for h in root.handlers[:]:
        root.removeHandler(h)

    handler = logging.StreamHandler(sys.stderr)
    from odid.web.logs import stderr_is_journal
    if _log_json:
        handler.setFormatter(_JSONFormatter())
    elif stderr_is_journal():
        # journald stamps the time; the <N> prefix gives each line its level
        handler.setFormatter(_JournalFormatter("%(levelname)-5s %(name)s: %(message)s"))
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-5s %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        ))
    root.addHandler(handler)

    # Quiet scapy unless in verbose mode
    if not _verbose:
        logging.getLogger("scapy").setLevel(logging.WARNING)

    log.debug("odid v%s starting", __version__)


# ---------------------------------------------------------------------------
# Interface commands
# ---------------------------------------------------------------------------

@app.command("interfaces")
def cmd_interfaces():
    """List available WiFi interfaces."""
    from odid.capture.interface import list_interfaces
    ifaces = list_interfaces()
    if not ifaces:
        typer.echo("No WiFi interfaces found.")
        raise typer.Exit(1)
    typer.echo("\nWiFi Interfaces:")
    for iface in ifaces:
        mode = iface.get("type", "unknown")
        ch   = iface.get("channel", "?")
        typer.echo(f"  {iface['name']:12s}  mode={mode:10s}  channel={ch}")
    typer.echo()


@app.command("setup")
def cmd_setup(
    interface: Annotated[str, typer.Argument(help="WiFi interface to configure")],
    channel: Annotated[int, typer.Option("-c", "--channel", help="Channel")] = 6,
):
    """Configure an interface for monitor mode."""
    from odid.capture.interface import enable_monitor_mode, is_monitor_mode
    typer.echo(f"Configuring {interface} for monitor mode on channel {channel}...")
    try:
        enable_monitor_mode(interface, channel)
        ok = is_monitor_mode(interface)
    except Exception as e:
        typer.echo(f"  ERROR: {e}", err=True)
        log.debug("setup error", exc_info=True)
        raise typer.Exit(1)
    if not ok:
        typer.echo(f"  ✗ ERROR: {interface} is NOT in monitor mode after setup", err=True)
        raise typer.Exit(1)
    typer.echo(f"  ✓ {interface} is now in monitor mode on channel {channel}")


@app.command("diagnose")
def cmd_diagnose(
    interface: Annotated[str, typer.Argument(help="WiFi interface to diagnose")],
):
    """Check interface status and confirm capture readiness."""
    from odid.capture.interface import get_interface_info, is_monitor_mode
    typer.echo(f"\nDiagnosing {interface}...\n")
    try:
        info = get_interface_info(interface)
        typer.echo(f"  Type    : {info.get('type', '?')}")
        typer.echo(f"  Channel : {info.get('channel', '?')}")
        typer.echo(f"  Freq    : {info.get('frequency', '?')} MHz")
    except Exception as e:
        typer.echo(f"  ERROR getting interface info: {e}", err=True)
        log.debug("diagnose error", exc_info=True)
        raise typer.Exit(1)

    if not is_monitor_mode(interface):
        typer.echo(f"\n  WARNING: {interface} is NOT in monitor mode.")
        typer.echo(f"  Run: sudo odid setup {interface}")
        raise typer.Exit(1)

    typer.echo("\n  ✓ Interface is in monitor mode. Ready for capture.")
    typer.echo(f"\n  To start sniffing:\n    sudo odid sniff {interface}")
    typer.echo(f"\n  To scan all channels:\n    sudo odid scan {interface}")


# ---------------------------------------------------------------------------
# Init wizard
# ---------------------------------------------------------------------------

@app.command("init")
def cmd_init():
    """Interactive first-time setup wizard: detects interfaces and writes config."""
    from rich.prompt import Prompt, Confirm, IntPrompt, FloatPrompt

    def _ask_range(prompt_cls, label, lo, hi, default=None):
        kwargs = {} if default is None else {"default": default}
        while True:
            val = prompt_cls.ask(label, console=console, **kwargs)
            if val is not None and lo <= val <= hi:
                return val
            console.print(f"  [red]Please enter a value between {lo} and {hi}[/red]")

    typer.echo()
    console.rule("[bold cyan]ODID Sniffer Setup Wizard[/bold cyan]")
    typer.echo()

    # Detect interfaces
    try:
        from odid.capture.interface import list_interfaces
        ifaces = list_interfaces()
    except Exception:
        ifaces = []

    if ifaces:
        names = [iface["name"] for iface in ifaces]
        typer.echo("WiFi interfaces detected:")
        for i, iface in enumerate(ifaces):
            typer.echo(f"  [{i}] {iface['name']:12s}  mode={iface.get('type','?')}")
        typer.echo()
        while True:
            answer = Prompt.ask("WiFi interface for capture (number or name)", default=names[0],
                                console=console).strip()
            if answer.isdigit():
                if int(answer) < len(names):
                    wifi_iface = names[int(answer)]
                    break
                console.print(f"  [red]No interface number {answer}[/red]")
                continue
            if _valid_iface_name(answer):
                wifi_iface = answer
                break
            console.print("  [red]Enter a listed number or a valid interface name[/red]")
    else:
        while True:
            wifi_iface = Prompt.ask("WiFi interface for capture (not auto-detected)", default="wlan1",
                                    console=console).strip()
            if _valid_iface_name(wifi_iface):
                break
            console.print("  [red]Invalid interface name[/red]")

    # Observer position
    typer.echo()
    set_observer = Confirm.ask("Set observer position (lat/lon) for distance calculation?", default=False)
    obs_lat = obs_lon = None
    if set_observer:
        obs_lat = _ask_range(FloatPrompt, "  Observer latitude", -90.0, 90.0)
        obs_lon = _ask_range(FloatPrompt, "  Observer longitude", -180.0, 180.0)

    # Output preferences
    typer.echo()
    web_default = Confirm.ask("Start web dashboard by default?", default=False)
    web_port = 8080
    if web_default:
        web_port = _ask_range(IntPrompt, "  Web dashboard port", 1, 65535, default=8080)

    no_pcap  = not Confirm.ask("Enable pcap capture?", default=True)
    no_jsonl = not Confirm.ask("Enable JSONL logging?", default=True)
    no_csv   = not Confirm.ask("Enable CSV export?", default=True)
    no_db    = not Confirm.ask("Enable SQLite database?", default=True)

    # Drone TTL
    typer.echo()
    drone_ttl = _ask_range(IntPrompt, "Evict drones not heard for N seconds (0=never)", 0, 86400, default=300)

    # Watchlist
    typer.echo()
    watchlist = Prompt.ask("Watchlist file path (leave blank to skip)", default="", console=console)

    # Build config
    config: dict = {
        "capture": {
            "interface": wifi_iface,
            "drone_ttl": drone_ttl,
        },
        "output": {
            "web": web_default,
            "web_port": web_port,
            "no_pcap": no_pcap,
            "no_jsonl": no_jsonl,
            "no_csv": no_csv,
            "no_db": no_db,
        },
    }
    if obs_lat is not None:
        config["observer"] = {"lat": obs_lat, "lon": obs_lon}
    if watchlist:
        config["alerts"] = {"watchlist": watchlist}

    from odid.config import save as save_config, config_path, load_raw, ConfigError
    # Merge into the existing file so keys the wizard doesn't ask about survive
    try:
        merged = load_raw(strict=True)
    except ConfigError as e:
        console.print(f"  [yellow]WARNING: the existing config could not be parsed:[/yellow] {e}")
        backup = config_path().with_name(config_path().name + ".bak")
        if not Confirm.ask(f"  Replace it? (the current file is kept as {backup.name})", default=False):
            typer.echo("  Config not written.")
            raise typer.Exit(1)
        try:
            backup.write_bytes(config_path().read_bytes())
        except OSError as be:
            typer.echo(f"  ✗ Could not back up the config: {be}", err=True)
            raise typer.Exit(1)
        merged = {}
    for section, values in config.items():
        merged.setdefault(section, {})
        if isinstance(merged[section], dict):
            merged[section].update(values)
        else:
            merged[section] = values
    try:
        save_config(merged)
    except (OSError, ValueError) as e:
        typer.echo(f"  ✗ Could not write config {config_path()}: {e}", err=True)
        raise typer.Exit(1)
    typer.echo()
    typer.echo(f"  ✓ Config written to {config_path()}")

    # Optionally configure monitor mode now
    typer.echo()
    if Confirm.ask(f"Configure {wifi_iface} for monitor mode now?", default=True):
        try:
            from odid.capture.interface import enable_monitor_mode
            enable_monitor_mode(wifi_iface, 6)
            typer.echo(f"  ✓ {wifi_iface} configured for monitor mode")
        except Exception as e:
            typer.echo(f"  ✗ Could not configure monitor mode: {e} (try: sudo odid setup {wifi_iface})", err=True)

    # Systemd service offer (not when the package's service is installed)
    typer.echo()
    if _packaged_unit() is not None:
        typer.echo(f"  {_PACKAGED_HINT}")
    elif Confirm.ask("Install systemd service for auto-start on boot?", default=False):
        _install_systemd_service(wifi_iface)

    typer.echo()
    console.print(f"[green]Setup complete.[/green] Run: sudo odid sniff {wifi_iface} --tui")
    typer.echo()


# ---------------------------------------------------------------------------
# Accounts and TLS for the dashboard
# ---------------------------------------------------------------------------

_SERVICE_DATA_DIR = Path("/var/lib/odid")


def _admin_auth_file(file: Optional[Path]) -> Path:
    """Accounts file for odid passwd / users: --file, else the log directory
    if one was chosen, else the installed service's (/var/lib/odid), else
    ./logs."""
    if file is not None:
        return file
    if not _log_dir_explicit and _SERVICE_DATA_DIR.is_dir():
        return _SERVICE_DATA_DIR / "auth.json"
    return _auth_file()


_AuthFileOpt = Annotated[Optional[Path], typer.Option(
    "--file", metavar="PATH", help="Accounts file [default: /var/lib/odid/auth.json when the "
                                   "service is installed, else auth.json in --log-dir]")]


def _read_new_password(password_stdin: bool) -> str:
    if password_stdin:
        return sys.stdin.readline().rstrip("\r\n")
    import getpass
    first = getpass.getpass("New password: ")
    if getpass.getpass("Repeat password: ") != first:
        typer.echo("ERROR: passwords do not match", err=True)
        raise typer.Exit(1)
    return first


@app.command("passwd")
def cmd_passwd(
    user: Annotated[str, typer.Argument(help="Account name (created if new)")],
    role: Annotated[Optional[str], typer.Option(
        "--role", help="admin (full control) or viewer (map only) [default: admin for a new "
                       "account, unchanged otherwise]")] = None,
    password_stdin: Annotated[bool, typer.Option(
        "--password-stdin", help="Read the password from the first line of stdin")] = False,
    file: _AuthFileOpt = None,
):
    """Create a dashboard account or change its password (signs it out everywhere)."""
    from odid.web.auth import AuthError, AuthStore
    path = _admin_auth_file(file)
    try:
        store = AuthStore(path)
        new = user not in store.users()
        if role is not None and role not in ("admin", "viewer"):
            raise AuthError("Role must be admin or viewer")
        password = _read_new_password(password_stdin)
        store.set_user(user, password, role)
    except AuthError as e:
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)
    except OSError as e:
        typer.echo(f"ERROR: cannot write {path}: {e} (run with sudo?)", err=True)
        raise typer.Exit(1)
    typer.echo(f"  ✓ {'Created' if new else 'Updated'} {user} ({store.role_of(user)}) in {path}")


@app.command("users")
def cmd_users(
    remove: Annotated[Optional[str], typer.Option("--remove", metavar="NAME",
                                                  help="Delete this account")] = None,
    force: Annotated[bool, typer.Option("--force", help="Allow deleting the last account")] = False,
    file: _AuthFileOpt = None,
):
    """List dashboard accounts (or remove one with --remove)."""
    from odid.web.auth import AuthError, AuthStore
    path = _admin_auth_file(file)
    try:
        store = AuthStore(path)
        if remove:
            if not force and list(store.users()) == [remove]:
                typer.echo(f"ERROR: {remove} is the last account. A dashboard that is reachable "
                           "from the network would then refuse every request until an account "
                           "is created again. Use --force to delete it anyway.", err=True)
                raise typer.Exit(1)
            store.remove_user(remove)
            typer.echo(f"  ✓ Removed {remove}")
        users = store.users()
    except AuthError as e:
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)
    except OSError as e:
        typer.echo(f"ERROR: {path}: {e} (run with sudo?)", err=True)
        raise typer.Exit(1)
    if not users:
        typer.echo(f"No accounts in {path}. A running dashboard that is reachable from the "
                   "network refuses every request until one exists; after a restart it stays "
                   "on 127.0.0.1. Create one with: sudo odid passwd <name>")
    for name, r in users.items():
        typer.echo(f"  {name:20s} {r}")


@app.command("tls")
def cmd_tls(
    regenerate: Annotated[bool, typer.Option("--regenerate", help="Replace an existing certificate")] = False,
    tailscale_cert: Annotated[bool, typer.Option(
        "--tailscale-cert", help="Use this node's Tailscale-issued certificate (real CA, "
                                 "valid for <name>.ts.net) instead of a self-signed one")] = False,
    cert: Annotated[Path, typer.Option("--cert", help="Certificate path")] = Path("/etc/odid/tls/cert.pem"),
    key: Annotated[Path, typer.Option("--key", help="Private key path")] = Path("/etc/odid/tls/key.pem"),
):
    """Create the dashboard's HTTPS certificate and print its fingerprint."""
    from odid.web import tls as tlsmod
    try:
        if tailscale_cert:
            name = tlsmod.tailscale_dns_name()
            if not name:
                typer.echo("ERROR: Tailscale is not running / logged in (sudo tailscale up)", err=True)
                raise typer.Exit(1)
            import subprocess as _sp
            _prepare_tls_dir(cert.parent)
            try:
                r = _sp.run(["tailscale", "cert", "--cert-file", str(cert), "--key-file", str(key),
                             name], capture_output=True, text=True, timeout=120)
            except _sp.TimeoutExpired:
                typer.echo("ERROR: tailscale cert did not finish within 120 s", err=True)
                raise typer.Exit(1)
            if r.returncode != 0:
                typer.echo(f"ERROR: tailscale cert failed: {r.stderr.strip()}", err=True)
                raise typer.Exit(1)
        elif cert.exists() and key.exists() and not regenerate:
            typer.echo(f"  Certificate exists: {cert} (use --regenerate to replace it)")
        else:
            _prepare_tls_dir(cert.parent)
            if key.parent != cert.parent:
                _prepare_tls_dir(key.parent)
            tlsmod.generate_self_signed(cert, key, tlsmod.local_names(), _lan_ipv4s())
            typer.echo(f"  ✓ Self-signed certificate: {cert}")
        _secure_tls_files(cert, key)
        typer.echo(f"  SHA-256 fingerprint: {tlsmod.fingerprint(cert)}")
        typer.echo("  Compare it with the one your browser shows before accepting the certificate.")
    except typer.Exit:
        raise
    except (OSError, RuntimeError) as e:
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)


def _lan_ipv4s() -> list[str]:
    """Global IPv4 addresses of this machine (for the certificate's SANs)."""
    import subprocess as _sp
    try:
        r = _sp.run(["ip", "-j", "-4", "addr", "show", "scope", "global"],
                    capture_output=True, text=True, timeout=5)
        return [a["local"] for ifc in json.loads(r.stdout or "[]")
                for a in ifc.get("addr_info", []) if a.get("local")]
    except (OSError, ValueError, _sp.SubprocessError):
        return []


def _wifi_connections() -> list[tuple[str, str]]:
    """Active NetworkManager WiFi connections as [(name, device)]."""
    import subprocess as _sp
    try:
        r = _sp.run(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"],
                    capture_output=True, text=True, timeout=10)
    except (OSError, _sp.SubprocessError):
        return []
    out = []
    for line in r.stdout.splitlines() if r.returncode == 0 else []:
        # nmcli -t escapes ':' inside fields as '\:'
        parts = re.split(r"(?<!\\):", line)
        if len(parts) == 3 and parts[1] == "802-11-wireless":
            out.append((parts[0].replace("\\:", ":"), parts[2]))
    return out


def _disable_wifi_powersave(conns) -> list[tuple[str, Optional[str]]]:
    """Persistently turn off power saving on these WiFi connections (and now,
    on their devices). [(name, error or None)]."""
    import subprocess as _sp
    results = []
    for name, dev in conns:
        try:
            r = _sp.run(["nmcli", "connection", "modify", name, "802-11-wireless.powersave", "2"],
                        capture_output=True, text=True, timeout=15)
            err = None if r.returncode == 0 else (r.stderr or r.stdout).strip() or "nmcli failed"
            if err is None and dev:
                _sp.run(["iw", "dev", dev, "set", "power_save", "off"],
                        capture_output=True, text=True, timeout=10)
        except (OSError, _sp.SubprocessError) as e:
            err = str(e)
        results.append((name, err))
    return results


def _prepare_tls_dir(directory: Path) -> None:
    """As root: the certificate directory must be root-owned (root:odid 0750)
    inside a root-owned parent, so nobody else can plant symlinks there."""
    if os.geteuid() != 0:
        directory.mkdir(parents=True, exist_ok=True)
        return
    import grp
    from odid.provision import check_root_owned_dir
    check_root_owned_dir(directory.parent)
    if not directory.exists():
        directory.mkdir(mode=0o750)
    check_root_owned_dir(directory)
    try:
        os.chown(directory, 0, grp.getgrnam("odid").gr_gid, follow_symlinks=False)
    except KeyError:
        pass
    os.chmod(directory, 0o750)


def _secure_tls_files(cert: Path, key: Path) -> None:
    """Cert 0644, key 0640, both root:odid (the service reads them via its
    group). Refuses symlinks; never follows them."""
    import grp
    import stat as _stat
    gid = None
    if os.geteuid() == 0:
        try:
            gid = grp.getgrnam("odid").gr_gid
        except KeyError:
            gid = None
    for path, mode in ((cert, 0o644), (key, 0o640)):
        st = os.lstat(path)
        if not _stat.S_ISREG(st.st_mode):
            raise OSError(f"{path} is not a regular file")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            if gid is not None:
                os.fchown(fd, 0, gid)
            os.fchmod(fd, mode)
        finally:
            os.close(fd)


@app.command("provision")
def cmd_provision(
    lat: Annotated[Optional[float], typer.Option("--lat", help="Observer latitude")] = None,
    lon: Annotated[Optional[float], typer.Option("--lon", help="Observer longitude")] = None,
    dongle: Annotated[Optional[str], typer.Option(
        "--dongle", metavar="IFACE", help="WiFi dongle to capture with, or 'none'")] = None,
    bladerf: Annotated[Optional[str], typer.Option(
        "--bladerf", metavar="MODE", help="BladeRF use: wifi, bt or none")] = None,
    bladerf_gain: Annotated[int, typer.Option("--bladerf-gain", min=0, max=71,
                                              help="BladeRF RX gain (dB)")] = 40,
    builtin_bt: Annotated[Optional[bool], typer.Option(
        "--builtin-bt/--no-builtin-bt", help="Scan with the Pi's own Bluetooth adapter")] = None,
    admin: Annotated[Optional[str], typer.Option(
        "--admin", metavar="NAME", help="Admin account to create if there is none [default: admin]")] = None,
    password_stdin: Annotated[bool, typer.Option(
        "--password-stdin", help="Read the admin password from stdin (headless)")] = False,
    lan: Annotated[Optional[bool], typer.Option(
        "--lan/--no-lan", help="Serve the dashboard over HTTPS on the local network (port 8443)")] = None,
    tailscale: Annotated[Optional[bool], typer.Option(
        "--tailscale/--no-tailscale",
        help="Publish the dashboard to your tailnet with 'tailscale serve' (HTTPS)")] = None,
    wifi_powersave_off: Annotated[Optional[bool], typer.Option(
        "--wifi-powersave-off/--keep-wifi-powersave",
        help="Turn off WiFi power saving on the network connection, so the dashboard "
             "stays reachable")] = None,
    restart: Annotated[bool, typer.Option("--restart/--no-restart",
                                          help="Restart odid.service to apply")] = True,
    yes: Annotated[bool, typer.Option("--yes", "-y",
                                      help="Don't ask: use the options and detected defaults")] = False,
    config_file: Annotated[Optional[Path], typer.Option("--config", hidden=True)] = None,
    state_dir: Annotated[Optional[Path], typer.Option("--state-dir", hidden=True)] = None,
):
    """Configure the installed service (odid.service): radios, observer position.

    Writes /etc/odid/config.toml. Run with sudo after installing the package;
    every question can be answered with an option for headless setup, e.g.
    sudo odid provision -y --dongle wlan1 --bladerf wifi --lat 51.5 --lon -0.12
    """
    from rich.prompt import Confirm, FloatPrompt, Prompt
    from odid import provision as prov
    from odid.config import ConfigError, SERVICE_CONFIG_PATH, read_file

    config_file = config_file or SERVICE_CONFIG_PATH
    state_dir = state_dir or prov.STATE_DIR
    if os.geteuid() != 0 and config_file == SERVICE_CONFIG_PATH:
        typer.echo("ERROR: run as root: sudo odid provision", err=True)
        raise typer.Exit(1)
    try:
        if config_file == SERVICE_CONFIG_PATH and config_file.parent.exists():
            prov.check_root_owned_dir(config_file.parent)
        existing = read_file(config_file)
    except ConfigError as e:
        typer.echo(f"ERROR: {e}; fix or remove the file first", err=True)
        raise typer.Exit(1)
    except OSError as e:
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)

    hw = prov.detect()
    c = prov.Choices(bladerf_gain=bladerf_gain)
    console.rule("[bold cyan]ODID Sniffer service setup[/bold cyan]")

    # Observer position (needed only for distances; keep the current one)
    if (lat is None) != (lon is None):
        raise typer.BadParameter("--lat and --lon must be given together")
    if lat is not None:
        c.lat, c.lon = _validate_observer(lat, lon)
    elif not yes:
        obs = existing.get("observer") or {}
        if Confirm.ask("Set the observer (sensor) position?",
                       default="lat" not in obs, console=console):
            c.lat, c.lon = _validate_observer(
                FloatPrompt.ask("  Latitude", console=console, default=obs.get("lat")),
                FloatPrompt.ask("  Longitude", console=console, default=obs.get("lon")))
    if c.lat is not None:
        try:
            dash_obs = read_file(state_dir / "settings.toml").get("observer") or {}
        except (ConfigError, OSError):
            dash_obs = {}
        if dash_obs:
            console.print("  [yellow]WARNING: the observer position set in the dashboard "
                          f"({state_dir / 'settings.toml'}) overrides this one; change or "
                          "reset it under Settings.[/yellow]")

    # WiFi dongle
    names = [w["name"] for w in hw.wifi]
    if dongle is not None:
        if dongle.lower() != "none":
            if not _valid_iface_name(dongle) or dongle.isdigit():
                raise typer.BadParameter(f"invalid interface name {dongle!r}")
            c.dongle = dongle
    else:
        default = prov.default_dongle(hw)
        if hw.wifi:
            console.print("WiFi interfaces: " + ", ".join(
                f"{w['name']}{' (connected, keep for networking)' if w['has_ip'] else ''}"
                for w in hw.wifi))
        if yes:
            c.dongle = default
        elif names:
            answer = Prompt.ask("WiFi dongle to capture with ('none' to skip)",
                                choices=names + ["none"], default=default or "none",
                                console=console)
            c.dongle = None if answer == "none" else answer
    if c.dongle and any(w["name"] == c.dongle and w["has_ip"] for w in hw.wifi):
        console.print(f"  [yellow]WARNING: {c.dongle} is connected to a network; the service "
                      "will refuse to switch it to monitor mode.[/yellow]")

    # BladeRF
    if bladerf is not None:
        mode = bladerf.lower()
        if mode not in ("wifi", "bt", "none"):
            raise typer.BadParameter("--bladerf must be wifi, bt or none")
        c.bladerf = None if mode == "none" else mode
    elif hw.bladerf:
        console.print("BladeRF detected.")
        mode = "wifi" if yes else Prompt.ask(
            "Use the BladeRF for", choices=["wifi", "bt", "none"], default="wifi", console=console)
        c.bladerf = None if mode == "none" else mode

    # Built-in Bluetooth
    if builtin_bt is not None:
        c.builtin_bt = builtin_bt
    elif hw.bt_adapters:
        c.builtin_bt = True if yes else Confirm.ask(
            f"Scan for Bluetooth Remote ID with the built-in adapter ({hw.bt_adapters[0]})?",
            default=True, console=console)

    cfg = prov.merge_config(existing, c)
    output = cfg.setdefault("output", {})
    try:
        port = int(output.get("web_port", 8080))
        if not 1 <= port <= 65535:
            raise ValueError
    except (TypeError, ValueError):
        typer.echo(f"ERROR: web_port in {config_file} must be a port number (1-65535), "
                   f"not {output.get('web_port')!r}", err=True)
        raise typer.Exit(1)

    # -- Accounts (required before anything is reachable from the network) --
    from odid.web.auth import AuthError, AuthStore
    store = AuthStore(state_dir / "auth.json")
    generated = None
    if not store.has_users():
        name = admin or ("admin" if yes else Prompt.ask("Admin account name", default="admin",
                                                        console=console))
        if password_stdin:
            password = sys.stdin.readline().rstrip("\r\n")
        elif yes:
            import secrets
            password = generated = secrets.token_urlsafe(12)
        else:
            typer.echo(f"Password for {name} (8+ characters):")
            password = _read_new_password(False)
        try:
            store.set_user(name, password, "admin")
        except AuthError as e:
            typer.echo(f"ERROR: {e}", err=True)
            raise typer.Exit(1)
        except OSError as e:
            typer.echo(f"ERROR: cannot write {store.path}: {e}", err=True)
            raise typer.Exit(1)
        typer.echo(f"  ✓ Admin account {name} created")
    else:
        typer.echo(f"  ✓ Accounts: {', '.join(store.users())} (change with: sudo odid passwd)")

    # -- LAN: HTTPS listener with a self-signed certificate ----------------
    if lan is None:
        lan = True if yes else Confirm.ask(
            "Serve the dashboard over HTTPS on the local network?", default=True, console=console)
    output["web_tls"] = bool(lan)
    output["web_host"] = "127.0.0.1"      # plain HTTP only for this Pi / tailscale serve
    fingerprint = None
    if lan:
        from odid.web import tls as tlsmod
        output.setdefault("web_tls_host", "0.0.0.0")
        output.setdefault("web_tls_port", 8443)
        # Always the fixed, root-owned location: root never operates on
        # paths taken from a config file
        cert, key = tlsmod.DEFAULT_CERT, tlsmod.DEFAULT_KEY
        output["tls_cert"], output["tls_key"] = str(cert), str(key)
        if config_file == SERVICE_CONFIG_PATH:
            try:
                _prepare_tls_dir(cert.parent)
                if not (cert.exists() and key.exists()):
                    tlsmod.generate_self_signed(cert, key, tlsmod.local_names(), _lan_ipv4s())
                    typer.echo(f"  ✓ Self-signed certificate created: {cert}")
                _secure_tls_files(cert, key)
                fingerprint = tlsmod.fingerprint(cert)
            except (OSError, RuntimeError) as e:
                typer.echo(f"ERROR: TLS certificate: {e}", err=True)
                raise typer.Exit(1)

    # -- WiFi power saving drops the Pi off the network now and then ------
    if config_file == SERVICE_CONFIG_PATH and wifi_powersave_off is not False:
        conns = _wifi_connections()
        if conns and (wifi_powersave_off or yes or Confirm.ask(
                f"Turn off WiFi power saving on {', '.join(n for n, _ in conns)} "
                "(keeps the dashboard reachable)?", default=True, console=console)):
            for name, err in _disable_wifi_powersave(conns):
                if err:
                    typer.echo(f"  ✗ WiFi power saving on {name}: {err}", err=True)
                else:
                    typer.echo(f"  ✓ WiFi power saving off: {name}")

    # -- Tailscale: HTTPS on <pi>.<tailnet>.ts.net via "tailscale serve" ----
    ts_url = None
    if tailscale is not False and config_file == SERVICE_CONFIG_PATH:
        from odid.web.tls import tailscale_dns_name
        ts_name = tailscale_dns_name()
        if ts_name is None:
            if tailscale:
                typer.echo("  ✗ Tailscale is not installed / logged in; run: sudo tailscale up, "
                           "then provision again", err=True)
        elif tailscale or yes or Confirm.ask(
                f"Publish the dashboard to your tailnet as https://{ts_name}/ ?",
                default=True, console=console):
            import subprocess as _sp
            try:
                r = _sp.run(["tailscale", "serve", "--bg", "--https=443",
                             f"http://127.0.0.1:{port}"], capture_output=True, text=True,
                            timeout=60)
            except (OSError, _sp.SubprocessError) as e:
                r = _sp.CompletedProcess([], 1, "", f"{type(e).__name__}: {e}")
            if r.returncode == 0:
                hosts = _str_list(output.get("allowed_hosts"))
                if ts_name not in hosts:
                    output["allowed_hosts"] = hosts + [ts_name]
                output["trusted_proxy"] = True     # client IPs via X-Forwarded-For
                ts_url = f"https://{ts_name}/"
                typer.echo(f"  ✓ tailscale serve: {ts_url}")
            else:
                typer.echo(f"  ✗ tailscale serve failed: {(r.stderr or r.stdout).strip()}", err=True)

    try:
        backup = prov.apply(cfg, config_file, state_dir)
    except (OSError, ValueError) as e:
        typer.echo(f"ERROR: could not write {config_file}: {e}", err=True)
        raise typer.Exit(1)
    typer.echo(f"  ✓ Wrote {config_file}")
    sources = [a["source"] for a in cfg["serve"]["autostart"]]
    typer.echo(f"  ✓ Sources started by the service: {', '.join(sources) or 'none'}")
    if backup is not None:
        typer.echo(f"  ✓ Previous source state kept as {backup}")

    if config_file == SERVICE_CONFIG_PATH:
        try:
            msg = prov.set_nm_unmanaged(c.dongle)
            if msg:
                typer.echo(f"  ✓ {msg}")
        except OSError as e:
            typer.echo(f"  ✗ Could not update NetworkManager config: {e}", err=True)

    if restart and config_file == SERVICE_CONFIG_PATH and prov.service_active():
        ok, err = prov.restart_service()
        typer.echo("  ✓ Restarted odid.service" if ok else f"  ✗ Restart failed: {err}")

    typer.echo("")
    typer.echo(f"  On this Pi:   http://127.0.0.1:{port}/")
    if lan:
        import socket as _socket
        host = _socket.gethostname().split(".")[0]
        typer.echo(f"  On the LAN:   https://{host}.local:{output.get('web_tls_port', 8443)}/"
                   "  (self-signed certificate)")
        if fingerprint:
            typer.echo(f"                SHA-256 {fingerprint}")
    if ts_url:
        typer.echo(f"  Tailnet:      {ts_url}")
    if generated:
        typer.echo(f"\n  Generated admin password (shown once): {generated}")
    typer.echo("")


_IFACE_RE = re.compile(r"^[A-Za-z0-9_.-]{1,15}$")


def _valid_iface_name(name: str) -> bool:
    return bool(_IFACE_RE.match(name or ""))


def _systemd_unit_text(interface: str, work_dir: Path) -> Optional[str]:
    """Return the odid.service unit text, or None if a path can't be expressed safely."""
    log_dir = (work_dir / _log_dir).resolve()
    py = sys.executable
    # WorkingDirectory takes a bare path (quotes make it "not absolute"), so
    # refuse paths with whitespace/quotes/specifiers rather than mis-escaping.
    for path in (str(work_dir), str(log_dir), py):
        if re.search(r'[\s"\'\\%$]', path):
            return None
    from odid.config import SERVICE_CONFIG_PATH
    # The service runs as root, so it reads a root-owned copy of the config
    # (/etc/odid/config.toml), never a file an unprivileged user can edit.
    env_line = f"Environment=ODID_CONFIG={SERVICE_CONFIG_PATH}\n"
    # No --tui: a systemd service has no terminal. Monitor mode is (re)applied
    # before each start because it does not survive a reboot. Restart forever
    # (every 10 s) so a USB dongle plugged in after boot is picked up.
    return f"""[Unit]
Description=OpenDroneID Sniffer
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
WorkingDirectory={work_dir}
{env_line}ExecStartPre={py} -m odid setup {interface}
ExecStart={py} -m odid --log-dir {log_dir} sniff {interface}
Restart=on-failure
RestartSec=10
User=root

[Install]
WantedBy=multi-user.target
"""


# The odid-sniffer package's unit. odid init must never shadow it with a unit
# in /etc/systemd/system (that would run `sniff` as root, unsandboxed).
_PACKAGED_UNITS = (Path("/usr/lib/systemd/system/odid.service"),
                   Path("/lib/systemd/system/odid.service"))
_PACKAGED_HINT = ("The odid-sniffer package's service is installed; configure it with "
                  "`sudo odid provision` instead.")


def _packaged_unit() -> Optional[Path]:
    return next((u for u in _PACKAGED_UNITS if u.exists()), None)


def _install_service_config() -> bool:
    """Copy the user's config to the root-owned file the service reads.

    An existing, different service config is only replaced after asking, and
    a backup is kept. False if the user declined."""
    import shutil
    from rich.prompt import Confirm
    from odid.config import CONFIG_PATH, SERVICE_CONFIG_PATH
    if not CONFIG_PATH.exists() or CONFIG_PATH.resolve() == SERVICE_CONFIG_PATH.resolve():
        return True
    existed = SERVICE_CONFIG_PATH.exists()
    if existed:
        if SERVICE_CONFIG_PATH.read_bytes() == CONFIG_PATH.read_bytes():
            return True
        if not Confirm.ask(f"  {SERVICE_CONFIG_PATH} already exists and differs from "
                           f"{CONFIG_PATH}. Replace it (a backup is kept)?", default=False):
            typer.echo(f"  Kept {SERVICE_CONFIG_PATH}.")
            return False
        backup = SERVICE_CONFIG_PATH.with_name(
            f"{SERVICE_CONFIG_PATH.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(SERVICE_CONFIG_PATH, backup)
        typer.echo(f"  ✓ Previous service config kept as {backup}")
    SERVICE_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Write in place: an existing file keeps its owner and mode
    with open(SERVICE_CONFIG_PATH, "wb") as f:
        f.write(CONFIG_PATH.read_bytes())
    if not existed:
        os.chown(SERVICE_CONFIG_PATH, 0, 0)
        os.chmod(SERVICE_CONFIG_PATH, 0o644)
    typer.echo(f"  ✓ Service config: {SERVICE_CONFIG_PATH} (copy of {CONFIG_PATH}; "
               "edit it as root and restart the service to change service settings)")
    return True


def _install_systemd_service(interface: str):
    """Write a systemd unit file for odid."""
    from rich.prompt import Confirm

    if not _valid_iface_name(interface):
        typer.echo(f"  ✗ Invalid interface name {interface!r}; systemd service not installed", err=True)
        return

    unit = _systemd_unit_text(interface, Path.cwd().resolve())
    if unit is None:
        typer.echo("  ✗ The working directory path contains characters systemd cannot take "
                   "unescaped; systemd service not installed", err=True)
        return
    if _packaged_unit() is not None:
        typer.echo(f"  ✗ {_PACKAGED_HINT}", err=True)
        return
    service_path = Path("/etc/systemd/system/odid.service")
    if service_path.exists() and not Confirm.ask(f"  {service_path} already exists. Overwrite?", default=False):
        typer.echo("  Skipped systemd service install.")
        return
    try:
        if not _install_service_config():
            typer.echo("  Skipped systemd service install.")
            return
        service_path.write_text(unit)
        import subprocess as _sp
        r = _sp.run(["systemctl", "daemon-reload"], check=False, capture_output=True, text=True)
        if r.returncode != 0:
            log.warning("systemctl daemon-reload failed: %s", r.stderr.strip())
        r = _sp.run(["systemctl", "enable", "odid.service"], check=False, capture_output=True, text=True)
        if r.returncode != 0:
            typer.echo(f"  WARNING: systemctl enable failed: {r.stderr.strip()}", err=True)
        typer.echo(f"  ✓ systemd service installed: {service_path}")
        typer.echo("  Run: sudo systemctl start odid")
    except PermissionError:
        typer.echo("  ✗ Permission denied; run as root to install systemd service", err=True)
    except OSError as e:
        typer.echo(f"  ✗ Could not install systemd service: {e}", err=True)


# ---------------------------------------------------------------------------
# Live capture commands
# ---------------------------------------------------------------------------

def _validate_observer(lat, lon) -> tuple[Optional[float], Optional[float]]:
    """Return (lat, lon) as floats, or (None, None). Both or neither must be set."""
    if lat is None and lon is None:
        return None, None
    if lat is None or lon is None:
        raise typer.BadParameter("--lat and --lon must be given together (check the [observer] config too)")
    try:
        lat_f, lon_f = float(lat), float(lon)
    except (TypeError, ValueError):
        raise typer.BadParameter(f"Observer position must be numeric, got lat={lat!r} lon={lon!r}")
    if not (-90.0 <= lat_f <= 90.0 and -180.0 <= lon_f <= 180.0):
        raise typer.BadParameter(f"Observer position out of range: {lat_f}, {lon_f}")
    return lat_f, lon_f


def _resolve_opts(
    lat=None, lon=None, watchlist=None, web=None, web_port=None, web_host=None,
    drone_ttl=None, alert_webhook=None,
) -> SimpleNamespace:
    """Merge per-command options with the TOML config (CLI > config > default)."""
    cfg = _config()

    def pick(val, key, default, conv=lambda v: v):
        if val is not None:
            return val
        if cfg.get(key) not in (None, ""):
            try:
                return conv(cfg[key])
            except (TypeError, ValueError):
                raise typer.BadParameter(f"Invalid config value {key}={cfg[key]!r}")
        return default

    lat, lon = _validate_observer(pick(lat, "lat", None), pick(lon, "lon", None))
    return SimpleNamespace(
        lat=lat,
        lon=lon,
        watchlist=pick(watchlist, "watchlist", None, str),
        web=pick(web, "web", False, _to_bool),
        web_port=_in_range("web_port", pick(web_port, "web_port", 8080, int), 1, 65535),
        web_host=pick(web_host, "web_host", "127.0.0.1", str),
        drone_ttl=_in_range("drone_ttl", pick(drone_ttl, "drone_ttl", 300, int), 0, 10**9),
        alert_webhook=pick(alert_webhook, "webhook", None, str),
        allowed_hosts=_str_list(cfg.get("allowed_hosts")),
        web_tls=pick(None, "web_tls", False, _to_bool),
        web_tls_host=pick(None, "web_tls_host", "0.0.0.0", str),
        web_tls_port=_in_range("web_tls_port", pick(None, "web_tls_port", 8443, int), 1, 65535),
        tls_cert=pick(None, "tls_cert", "/etc/odid/tls/cert.pem", str),
        tls_key=pick(None, "tls_key", "/etc/odid/tls/key.pem", str),
        allow_insecure_http=pick(None, "allow_insecure_http", False, _to_bool),
        trusted_proxy=pick(None, "trusted_proxy", False, _to_bool),
    )


def _in_range(name: str, value: int, lo: int, hi: int) -> int:
    """Config values skip click's min/max checks, so apply them here too."""
    if not lo <= value <= hi:
        raise typer.BadParameter(f"{name} must be between {lo} and {hi}, got {value}")
    return value


def _str_list(value) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value]
    return [str(v) for v in value]


def _resolve_interface(interface: Optional[str]) -> str:
    """CLI interface argument, else ``[capture] interface`` from the config."""
    source = "argument"
    if interface is None:
        interface = _config().get("interface")
        source = "config ([capture] interface)"
        if interface in (None, ""):
            raise typer.BadParameter(
                "No interface given and none set in the config; pass one, e.g. 'odid sniff wlan1'"
            )
    interface = str(interface)
    if not _valid_iface_name(interface) or interface.isdigit():
        raise typer.BadParameter(f"Invalid interface name {interface!r} from {source}")
    if not Path("/sys/class/net", interface).exists():
        raise typer.BadParameter(f"Interface {interface!r} (from {source}) does not exist; check 'ip link'")
    return interface


# Shared option declarations for the live capture commands
_LatOpt = Annotated[Optional[float], typer.Option("--lat", help="Observer latitude")]
_LonOpt = Annotated[Optional[float], typer.Option("--lon", help="Observer longitude")]
_WatchlistOpt = Annotated[Optional[str], typer.Option("--watchlist", metavar="FILE",
                                                       help="File of UAS / operator IDs to alert on")]
_FilterOpt = Annotated[Optional[str], typer.Option("--filter", metavar="EXPR",
                                                    help="Only record/show drones matching EXPR, e.g. "
                                                         "'ua_type=Multirotor' (console, files, DB, TUI, web)")]
_TuiOpt = Annotated[bool, typer.Option("--tui", help="Live TUI dashboard (requires rich)")]
_WebOpt = Annotated[Optional[bool], typer.Option("--web/--no-web", help="Start web dashboard (requires aiohttp)")]
_WebPortOpt = Annotated[Optional[int], typer.Option("--web-port", metavar="PORT", min=1, max=65535,
                                                     help="Web dashboard port [default: 8080]")]
_WebHostOpt = Annotated[Optional[str], typer.Option("--web-host", metavar="ADDR",
                                                     help="Web dashboard bind address [default: 127.0.0.1]")]
_TtlOpt = Annotated[Optional[int], typer.Option("--drone-ttl", metavar="SECS", min=0,
                                                 help="Evict drones not heard for N seconds (0=never) [default: 300]")]
_WebhookOpt = Annotated[Optional[str], typer.Option("--alert-webhook", metavar="URL",
                                                     help="POST watchlist-match alerts to this URL")]


class _LiveSession:
    """Shared plumbing for the live capture commands.

    Owns the tracker, output backends, writer thread, optional web dashboard,
    eviction thread and signal handling, and guarantees outputs are closed.
    """

    def __init__(self, opts: SimpleNamespace, frame_filter: Optional[str] = None, tui: bool = False,
                 print_frames: Optional[bool] = None):
        self.opts = opts
        self.tui = tui
        self.print_frames = (not tui) if print_frames is None else print_frames
        self.observer = (opts.lat, opts.lon)
        # Validate everything before touching the log directory
        self.wl_set = _load_watchlist(opts.watchlist)
        self.compiled_filter = _compile_filter(frame_filter)
        _rotate_logs()
        try:
            self.tracker, self.outputs = _build_pipeline(self.compiled_filter)
        except _OutputOpenError as e:
            typer.echo(f"ERROR: {e}", err=True)
            raise typer.Exit(1)
        self.write_q, self.writer_thread = _start_writer_thread(self.outputs)
        db = self.outputs.get("db")
        self.db_pruner = _DbPruner(db) if db is not None else None
        self.alerter = _WatchlistAlerter(opts.alert_webhook)
        self.web_dash = None
        self.evict_thread = None
        self._frame_lock = threading.Lock()
        self._closing = threading.Event()
        self._stop_fns: list = []
        self._stop_requested = False
        self._install_signal_handlers()

    # -- frame path -------------------------------------------------------

    def on_frame(self, frame) -> None:
        """Capture callback; may be called from several capture threads."""
        if self._closing.is_set():
            return
        with self._frame_lock:
            self.tracker.process_frame(frame)
            drone = self.tracker.drones.get(frame.source_mac)
            # Snapshot what the file writers need now; the live DroneState
            # keeps changing while the frame waits in the queue.
            snap = ({"uas_id": drone.uas_id, "frame_count": drone.frame_count}
                    if drone is not None else None)
        if self.compiled_filter and not self.compiled_filter(drone):
            return
        self.alerter.check(drone, self.wl_set)
        if self.print_frames:
            from odid.output.console import print_frame
            print_frame(frame, drone, self.observer[0], self.observer[1])
        try:
            self.write_q.put_nowait((frame, snap))
        except queue.Full:
            log.debug("Write queue full, frame dropped")

    # -- lifecycle --------------------------------------------------------

    def on_stop(self, fn) -> None:
        """Register a callable to run when the user asks to stop."""
        self._stop_fns.append(fn)
        if self._stop_requested:
            fn()

    def _install_signal_handlers(self) -> None:
        def _handler(sig, frm):
            if self._stop_requested:
                return
            self._stop_requested = True
            console.print("\nShutting down… (Ctrl+C again to force quit)")
            # A second signal gets the OS default action, i.e. immediate exit.
            signal.signal(signal.SIGINT, signal.SIG_DFL)
            signal.signal(signal.SIGTERM, signal.SIG_DFL)
            for fn in self._stop_fns:
                try:
                    fn()
                except Exception:
                    log.debug("stop callback failed", exc_info=True)
        signal.signal(signal.SIGINT, _handler)
        signal.signal(signal.SIGTERM, _handler)

    def start_web(self) -> None:
        if self.opts.web:
            self.web_dash = _start_web_dashboard(self.opts, self.tracker, self.compiled_filter,
                                                 db=self.outputs.get("db"))

    def print_observer_info(self) -> None:
        if self.observer[0] is not None:
            typer.echo(f"  Observer: {self.observer[0]:.6f}, {self.observer[1]:.6f}\n")
        if self.web_dash:
            typer.echo(f"  Web dashboard: {_web_urls(self.opts, self.web_dash)}\n")

    def run(self, capture, run_fn, banner_fn=None, error_label: str = "Capture") -> None:
        """Start auxiliary services, run the blocking capture, then tear down."""
        import contextlib
        self.on_stop(capture.stop)
        exit_code = 0
        try:
            self.start_web()
            if banner_fn:
                banner_fn()
            self.print_observer_info()
            if self.opts.drone_ttl > 0:
                self.evict_thread = _start_evict_thread(self.tracker, self.opts.drone_ttl)
            tui_ctx = (_make_tui_ctx(self.tracker, self.observer, self.compiled_filter)
                       if self.tui else contextlib.nullcontext())
            with tui_ctx:
                run_fn()
        except _WebStartError as e:
            typer.echo(f"ERROR: {e}", err=True)
            exit_code = 1
        except ImportError as e:
            typer.echo(f"ERROR: {e}", err=True)
            exit_code = 1
        except Exception as e:
            log.error("%s error: %s", error_label, e)
            log.debug("%s traceback", error_label, exc_info=True)
            # A capture that dies on its own is a failure (lets systemd's
            # Restart=on-failure kick in); one the user stopped is not.
            if not self._stop_requested:
                exit_code = 1
        finally:
            self.teardown(capture)
        if exit_code:
            raise typer.Exit(exit_code)

    def teardown(self, capture=None) -> None:
        """Stop helpers, flush the writer and close every output (always)."""
        try:
            _stop_evict_thread(self.evict_thread)
            if self.db_pruner:
                self.db_pruner.stop()
            if self.web_dash:
                self.web_dash.stop()
        except Exception:
            log.exception("Error stopping background services")
        finally:
            self._closing.set()
            try:
                _drain_writer(self.write_q, self.writer_thread)
            finally:
                _shutdown(self.tracker, capture, self.outputs)
                self.alerter.close()


def _require_monitor_mode(interface: str) -> None:
    from odid.capture.interface import is_monitor_mode
    if not is_monitor_mode(interface):
        typer.echo(f"ERROR: {interface} is not in monitor mode.", err=True)
        typer.echo(f"Run: sudo odid setup {interface}", err=True)
        raise typer.Exit(1)


_IfaceArg = Annotated[Optional[str], typer.Argument(
    help="WiFi interface in monitor mode [default: [capture] interface from the config]")]


@app.command("sniff")
def cmd_sniff(
    interface: _IfaceArg = None,
    channel: Annotated[int, typer.Option("-c", "--channel", help="WiFi channel")] = 6,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
    drone_ttl: _TtlOpt = None,
    alert_webhook: _WebhookOpt = None,
):
    """Listen on a single WiFi channel for OpenDroneID frames."""
    opts = _resolve_opts(lat, lon, watchlist, web, web_port, web_host, drone_ttl, alert_webhook)
    interface = _resolve_interface(interface)
    _require_monitor_mode(interface)

    from odid.output.console import print_banner
    from odid.capture.wifi import WiFiCapture

    session = _LiveSession(opts, frame_filter, tui)
    capture = WiFiCapture(interface, callback=session.on_frame)
    session.run(
        capture,
        lambda: capture.sniff(channel=channel),
        banner_fn=lambda: print_banner(interface, "sniff", channel),
    )


@app.command("monitor")
def cmd_monitor(
    interface: _IfaceArg = None,
    channel: Annotated[int, typer.Option("-c", "--channel", help="WiFi channel")] = 6,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
    drone_ttl: _TtlOpt = None,
    alert_webhook: _WebhookOpt = None,
):
    """Alias for sniff (backward compatibility)."""
    cmd_sniff(interface=interface, channel=channel, lat=lat, lon=lon, watchlist=watchlist,
              frame_filter=frame_filter, tui=tui, web=web, web_port=web_port, web_host=web_host,
              drone_ttl=drone_ttl, alert_webhook=alert_webhook)


@app.command("scan")
def cmd_scan(
    interface: _IfaceArg = None,
    dwell: Annotated[Optional[float], typer.Option("-d", "--dwell", min=0.1,
                      help="Seconds per channel [default: config dwell, else 5]")] = None,
    channels: Annotated[Optional[str], typer.Option("-c", "--channels",
                          help="Comma-separated channel list [default: config channels, else 1-11]")] = None,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
    drone_ttl: _TtlOpt = None,
    alert_webhook: _WebhookOpt = None,
):
    """Hop through all 2.4 GHz channels looking for OpenDroneID frames."""
    opts = _resolve_opts(lat, lon, watchlist, web, web_port, web_host, drone_ttl, alert_webhook)
    cfg = _config()

    channel_list = None
    if channels is None and cfg.get("channels"):
        channels = cfg["channels"]
    if channels:
        try:
            items = channels.split(",") if isinstance(channels, str) else list(channels)
            channel_list = [int(str(c).strip()) for c in items]
        except (TypeError, ValueError):
            typer.echo(f"ERROR: Invalid channel list: {channels!r}  (expected e.g. '1,6,11')", err=True)
            raise typer.Exit(1)
        if not channel_list or not all(1 <= c <= 233 for c in channel_list):
            typer.echo(f"ERROR: Invalid channel list: {channels!r}", err=True)
            raise typer.Exit(1)

    if dwell is None:
        try:
            dwell = float(cfg.get("dwell", 5.0))
        except (TypeError, ValueError):
            raise typer.BadParameter(f"Invalid config value dwell={cfg.get('dwell')!r}")
    # FloatRange lets 'nan'/'inf' through; either would stop the scan hopping
    if not math.isfinite(dwell) or dwell < 0.1:
        raise typer.BadParameter(f"dwell must be a finite number of seconds >= 0.1, got {dwell!r}")

    interface = _resolve_interface(interface)
    _require_monitor_mode(interface)

    from odid.output.console import print_banner
    from odid.capture.wifi import WiFiCapture

    session = _LiveSession(opts, frame_filter, tui)
    capture = WiFiCapture(interface, callback=session.on_frame)
    session.run(
        capture,
        lambda: capture.scan(channels=channel_list, dwell_time=dwell),
        banner_fn=lambda: print_banner(interface, "scan", None),
    )


# ---------------------------------------------------------------------------
# Bluetooth sniff
# ---------------------------------------------------------------------------

@app.command("btsniff")
def cmd_btsniff(
    adapter: Annotated[Optional[str], typer.Option("--adapter", help="Bluetooth adapter")] = None,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
    drone_ttl: _TtlOpt = None,
    alert_webhook: _WebhookOpt = None,
):
    """Sniff Bluetooth Remote ID advertisements (ASTM F3411 BT4/BT5)."""
    opts = _resolve_opts(lat, lon, watchlist, web, web_port, web_host, drone_ttl, alert_webhook)
    from odid.capture.bluetooth import BTCapture

    session = _LiveSession(opts, frame_filter, tui)
    try:
        capture = BTCapture(callback=session.on_frame, adapter=adapter)
    except ImportError as e:
        session.teardown()
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)

    def _banner():
        typer.echo(f"""
{'=' * 80}
  OpenDroneID Sniffer: Bluetooth Remote ID
  ASTM F3411 BT4 Legacy + BT5 Long Range
{'=' * 80}
  Mode      : btsniff
  Adapter   : {adapter or 'system default'}
  Press Ctrl+C to stop
{'=' * 80}
""")

    session.run(capture, capture.sniff, banner_fn=_banner, error_label="BT capture")


# ---------------------------------------------------------------------------
# BladeRF SDR sniff
# ---------------------------------------------------------------------------

class _MultiCapture:
    """Run several captures concurrently; the first one runs in the caller's thread."""

    def __init__(self, captures: list):
        self.captures = captures
        self._errors: list[BaseException] = []

    def _run_one(self, cap) -> None:
        try:
            cap.sniff()
        except BaseException as e:  # noqa: BLE001 - re-raised in sniff()
            self._errors.append(e)
            self.stop()

    def sniff(self) -> None:
        threads = [threading.Thread(target=self._run_one, args=(c,), daemon=True, name="odid-capture")
                   for c in self.captures[1:]]
        for t in threads:
            t.start()
        try:
            self._run_one(self.captures[0])
        finally:
            self.stop()
            for t in threads:
                t.join(timeout=5.0)
        if self._errors:
            raise self._errors[0]

    def stop(self) -> None:
        for c in self.captures:
            c.stop()

    @property
    def packet_counts(self) -> dict:
        merged: dict = {}
        for c in self.captures:
            for k, v in (getattr(c, "packet_counts", None) or {}).items():
                merged[k] = merged.get(k, 0) + v
        return merged


@app.command("bladerf")
def cmd_bladerf(
    zmq_addr: Annotated[str, typer.Option("--zmq", metavar="ADDR",
                         help="ZMQ PULL address of the WiFi GNU Radio flowgraph")] = "tcp://127.0.0.1:5555",
    zmq_bt_addr: Annotated[Optional[str], typer.Option("--zmq-bt", metavar="ADDR",
                            help="ZMQ PULL address of a BT LE flowgraph (second SDR) to read at the same time")] = None,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
    drone_ttl: _TtlOpt = None,
    alert_webhook: _WebhookOpt = None,
):
    """Sniff OpenDroneID frames via BladeRF SDR (requires GNU Radio flowgraph).

    Start the appropriate GNU Radio flowgraph first, then run this command:

    \b
      # WiFi path (802.11 ODID):
      python flowgraphs/odid_wifi_bladerf.py
      odid bladerf --zmq tcp://127.0.0.1:5555

    \b
      # Bluetooth LE path:
      python flowgraphs/odid_bt_bladerf.py
      odid bladerf --zmq tcp://127.0.0.1:5556

    \b
      # WiFi + BT at the same time needs TWO SDRs (one bladeRF can only tune
      # one band at a time; its two RX channels share a single LO):
      python flowgraphs/odid_wifi_bladerf.py --device <serial-1> --zmq tcp://127.0.0.1:5555
      python flowgraphs/odid_bt_bladerf.py   --device <serial-2> --zmq tcp://127.0.0.1:5556
      odid bladerf --zmq tcp://127.0.0.1:5555 --zmq-bt tcp://127.0.0.1:5556

    See flowgraphs/ and BLADERF.md for setup instructions.
    """
    opts = _resolve_opts(lat, lon, watchlist, web, web_port, web_host, drone_ttl, alert_webhook)
    from odid.capture.bladerf import BladeRFCapture

    session = _LiveSession(opts, frame_filter, tui)
    try:
        caps = [BladeRFCapture(callback=session.on_frame, zmq_addr=zmq_addr)]
        if zmq_bt_addr:
            caps.append(BladeRFCapture(callback=session.on_frame, zmq_addr=zmq_bt_addr))
    except ImportError as e:
        session.teardown()
        typer.echo(f"ERROR: {e}", err=True)
        raise typer.Exit(1)
    capture = caps[0] if len(caps) == 1 else _MultiCapture(caps)

    def _banner():
        mode_label = "bladerf (WiFi + BT, two SDRs)" if zmq_bt_addr else "bladerf"
        zmq_line = f"  ZMQ WiFi  : {zmq_addr}" if zmq_bt_addr else f"  ZMQ addr  : {zmq_addr}"
        bt_line = f"  ZMQ BT    : {zmq_bt_addr}\n" if zmq_bt_addr else ""
        typer.echo(f"""
{'=' * 80}
  OpenDroneID Sniffer: BladeRF SDR
{'=' * 80}
  Mode      : {mode_label}
{zmq_line}
{bt_line}  Press Ctrl+C to stop
{'=' * 80}
""")

    session.run(capture, capture.sniff, banner_fn=_banner, error_label="BladeRF capture")


# ---------------------------------------------------------------------------
# Serve: web UI with live source switching
# ---------------------------------------------------------------------------

@app.command("serve")
def cmd_serve(
    web_port: Annotated[Optional[int], typer.Option("--web-port", metavar="PORT", min=1, max=65535,
                         help="HTTP port for the web dashboard [default: 8080]")] = None,
    host: Annotated[Optional[str], typer.Option("--host", metavar="ADDR",
                     help="Plain-HTTP bind address [default: 127.0.0.1]. For network access "
                          "use HTTPS (web_tls in the config) with accounts from 'odid passwd'; "
                          "plain HTTP off loopback is refused")] = None,
    allowed_host: Annotated[Optional[list[str]], typer.Option(
        "--allowed-host", metavar="NAME",
        help="Extra hostname the dashboard may be reached by when --host is not loopback "
             "(repeatable; local IPs and this machine's hostname are always allowed)")] = None,
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    drone_ttl: _TtlOpt = None,
    no_autostart: Annotated[bool, typer.Option(
        "--no-autostart",
        help="Start with no sources running, ignoring the saved state and [serve] autostart")] = False,
):
    """Start the web dashboard with live radio-source switching.

    No capture source is required at startup; enable and disable sources
    (BladeRF WiFi/BT, WiFi dongle, built-in BT) from the Sources panel in
    the browser without restarting.

    Sources started from the browser are remembered (serve-state.json in the
    log directory) and started again on the next run; sources that fail, e.g.
    an unplugged SDR, are retried automatically. With no saved state yet, the
    [serve] autostart list from the config is used.
    """
    opts = _resolve_opts(lat=lat, lon=lon, web=True, web_port=web_port, web_host=host,
                         drone_ttl=drone_ttl)
    if allowed_host:
        hosts = list(getattr(opts, "allowed_hosts", None) or [])
        opts.allowed_hosts = hosts + [h for h in allowed_host if h not in hosts]
    from odid.capture.autostart import SourceSupervisor, load_state, parse_autostart
    from odid.capture.manager import SourceManager
    from odid import sdnotify

    state_path = Path(_log_dir) / "serve-state.json"
    desired: dict = {}
    if not no_autostart:
        desired = load_state(state_path)
        if desired is None:
            try:
                desired = parse_autostart(_config().get("autostart"))
            except ValueError as e:
                raise typer.BadParameter(f"[serve] autostart in the config: {e}")
    supervisor = SourceSupervisor(desired, state_path)

    # Frames are shown in the browser, not printed to the terminal
    session = _LiveSession(opts, print_frames=False)

    stop_event = threading.Event()
    manager = None
    watchdog = None
    exit_code = 0
    # This run's log records, for the dashboard when there is no journal
    from odid.web.logs import LogBuffer
    log_buffer = LogBuffer()
    logging.getLogger().addHandler(log_buffer)
    try:
        from odid.output.web import WebDashboard
        dash = _make_web_dashboard(WebDashboard, opts, session.tracker, db=session.outputs.get("db"))
        from odid.web.captures import IQ_SUBDIR
        manager = SourceManager(
            on_frame=session.on_frame,
            on_sources_changed=dash.notify_sources_changed,
            on_intent=supervisor.on_intent,
            iq_dir=str(Path(_log_dir) / IQ_SUBDIR),
            on_monitor=dash.notify_sdr_monitor,
        )
        supervisor.attach(manager)
        dash.set_source_manager(manager)
        # Before the dashboard starts: settings changes restart this thread
        if opts.drone_ttl > 0:
            session.evict_thread = _start_evict_thread(session.tracker, opts.drone_ttl)
        dash.set_settings(_settings_service(opts, session, dash))
        from odid.web.actions import SystemActions
        from odid.web.logs import LogSource, own_unit
        unit = own_unit()
        dash.set_files(LogSource(log_buffer, unit), _log_dir)
        dash.set_actions(SystemActions(unit))
        from odid.web.system import SystemHealth
        dash.set_health(SystemHealth(
            _log_dir, sources=manager.get_status, disk_guard=lambda: _disk_guard,
            tls_cert=Path(opts.tls_cert) if getattr(opts, "web_tls", False) else None,
            serve_port=opts.web_port if getattr(opts, "trusted_proxy", False) else None))
        _start_dash(dash, opts)
        session.web_dash = dash
        session.on_stop(stop_event.set)
        supervisor.start()
        if desired:
            console.print("  Starting sources: " + ", ".join(desired))

        # systemd Type=notify / WatchdogSec (no-ops outside systemd)
        writer = session.writer_thread
        watchdog = sdnotify.Watchdog(lambda: writer.is_alive() and dash.is_responsive())
        watchdog.start()
        sdnotify.notify("READY=1")

        if dash._login_required():
            console.print(f"  Sign-in required (accounts: {_auth_file()})")
        else:
            console.print("  No accounts: dashboard limited to this machine "
                          "(create one with: sudo odid passwd <name>)")
        console.print(
            f"\n  Web dashboard: {_web_urls(opts, dash)}\n"
            "  Select radio sources in the browser, no restart needed.\n"
            "  Press Ctrl+C to stop\n",
        )
        stop_event.wait()
    except (_WebStartError, ImportError) as e:
        typer.echo(f"ERROR: {e}", err=True)
        exit_code = 1
    finally:
        sdnotify.notify("STOPPING=1")
        if watchdog is not None:
            watchdog.stop()
        # Refuse new start/stop requests first, so nothing can restart a
        # source while they are being torn down.
        if session.web_dash is not None and hasattr(session.web_dash, "begin_shutdown"):
            session.web_dash.begin_shutdown()
        supervisor.request_stop()
        if manager is not None:
            try:
                manager.close()
            except Exception:
                log.exception("Error stopping capture sources")
        supervisor.stop()
        session.teardown(manager)
        logging.getLogger().removeHandler(log_buffer)
    if exit_code:
        raise typer.Exit(exit_code)


# ---------------------------------------------------------------------------
# Replay
# ---------------------------------------------------------------------------

@app.command("replay")
def cmd_replay(
    pcap: Annotated[str, typer.Argument(help="Path to .pcap file")],
    lat: _LatOpt = None,
    lon: _LonOpt = None,
    watchlist: _WatchlistOpt = None,
    frame_filter: _FilterOpt = None,
    rate: Annotated[float, typer.Option("--rate", min=0.0,
                     help="Seconds delay between frames (0=fastest)")] = 0.0,
    tui: _TuiOpt = False,
    web: _WebOpt = None,
    web_port: _WebPortOpt = None,
    web_host: _WebHostOpt = None,
):
    """Replay a saved pcap capture through the full decode pipeline."""
    import contextlib
    from scapy.utils import rdpcap
    from odid.decode.frame import extract_odid
    from odid.track.tracker import DroneTracker
    from odid.output.console import print_frame, print_summary

    opts = _resolve_opts(lat, lon, watchlist, web, web_port, web_host)
    # Unlike live capture, replay only starts the dashboard when asked to:
    # the config's "web = true" is meant for live sessions.
    opts.web = bool(web)

    pcap_path = Path(pcap)
    if not pcap_path.exists():
        typer.echo(f"ERROR: pcap file not found: {pcap_path}", err=True)
        raise typer.Exit(1)

    typer.echo(f"\nLoading: {pcap_path}")
    try:
        packets = rdpcap(str(pcap_path))
    except Exception as e:
        typer.echo(f"ERROR: Could not read pcap: {e}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Packets loaded: {len(packets)}")

    tracker = DroneTracker()
    wl_set = _load_watchlist(opts.watchlist)
    compiled_filter = _compile_filter(frame_filter)
    alerter = _WatchlistAlerter(None)
    observer = (opts.lat, opts.lon)
    web_dash = None
    if opts.web:
        try:
            web_dash = _start_web_dashboard(opts, tracker, compiled_filter)
        except (_WebStartError, ImportError) as e:
            typer.echo(f"ERROR: {e}", err=True)
            raise typer.Exit(1)
        typer.echo(f"  Web dashboard: {_web_url(opts.web_host, opts.web_port)}")

    tui_ctx = _make_tui_ctx(tracker, observer, compiled_filter) if tui else contextlib.nullcontext()
    odid_count = 0

    try:
        with tui_ctx:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                transient=True,
                disable=tui,  # hide progress when TUI is active
            ) as progress:
                task = progress.add_task("Replaying frames…", total=len(packets))
                for pkt in packets:
                    progress.advance(task)
                    frame = extract_odid(pkt)
                    if not frame:
                        continue

                    odid_count += 1
                    tracker.process_frame(frame)
                    drone = tracker.drones.get(frame.source_mac)

                    if compiled_filter and not compiled_filter(drone):
                        continue
                    alerter.check(drone, wl_set)
                    if not tui:
                        print_frame(frame, drone, observer[0], observer[1])

                    if rate > 0:
                        time.sleep(rate)
        print_summary(tracker, None)
        typer.echo(f"Replay complete: {odid_count} ODID frames from {len(packets)} total packets.")
        if web_dash:
            # Keep the map up so the replayed tracks can actually be viewed
            typer.echo(f"Dashboard still running at {_web_url(opts.web_host, opts.web_port)}. "
                       "Press Ctrl+C to exit.")
            done = threading.Event()
            signal.signal(signal.SIGINT, lambda *_: done.set())
            signal.signal(signal.SIGTERM, lambda *_: done.set())
            done.wait()
    finally:
        if web_dash:
            web_dash.stop()


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------

def _open_db_readonly(db_path: Path):
    """Open the drone DB read-only, exiting with a friendly error on failure."""
    import sqlite3
    from odid.track.db import DroneDB
    if not db_path.exists():
        typer.echo(f"ERROR: Database not found: {db_path}", err=True)
        typer.echo("Start a capture session first to create the database "
                   "(or pass --db / --log-dir).", err=True)
        raise typer.Exit(1)
    try:
        return DroneDB(db_path, read_only=True)
    except sqlite3.Error as e:
        typer.echo(f"ERROR: Could not open database {db_path}: {e}", err=True)
        raise typer.Exit(1)


@app.command("query")
def cmd_query(
    db: Annotated[Optional[str], typer.Option("--db", metavar="PATH", help="Path to DB")] = None,
    since: Annotated[Optional[str], typer.Option("--since", metavar="TIMESPEC",
                      help="Time window: '1h', '30m', '2d'")] = None,
    uas_id: Annotated[Optional[str], typer.Option("--uas-id", metavar="ID")] = None,
    mac: Annotated[Optional[str], typer.Option("--mac")] = None,
    anomalies: Annotated[bool, typer.Option("--anomalies", help="Only show drones with anomalies")] = False,
    frames: Annotated[bool, typer.Option("--frames", help="Show raw frame log")] = False,
    stats: Annotated[bool, typer.Option("--stats", help="Print DB statistics")] = False,
    limit: Annotated[int, typer.Option("--limit", min=1)] = 50,
    output_json: Annotated[bool, typer.Option("--json")] = False,
):
    """Query the accumulated SQLite drone database."""
    import sqlite3
    from odid.track.db import parse_since

    since_dt = None
    if since:
        try:
            since_dt = parse_since(since)
        except ValueError as e:
            typer.echo(f"ERROR: {e}", err=True)
            raise typer.Exit(1)

    db_path = Path(db) if db else Path(_log_dir) / "odid_drones.db"
    try:
        with _open_db_readonly(db_path) as database:
            _run_query(database, stats, frames, since_dt, uas_id, mac, anomalies, limit, output_json)
    except sqlite3.Error as e:
        typer.echo(f"ERROR: Database query failed: {e}", err=True)
        raise typer.Exit(1)


def _run_query(database, stats, frames, since_dt, uas_id, mac, anomalies, limit, output_json):
    if stats:
        s = database.get_stats()
        if output_json:
            typer.echo(json.dumps(s, indent=2))
        else:
            typer.echo("\nDatabase Statistics")
            typer.echo("-" * 40)
            for k, v in s.items():
                typer.echo(f"  {k:<24s}: {v}")
            typer.echo()
        return

    if frames:
        rows = database.query_frames(mac=mac, since=since_dt, limit=limit)
        if output_json:
            typer.echo(json.dumps(rows, indent=2))
        else:
            typer.echo(f"\nFrames ({len(rows)} results):")
            typer.echo(f"  {'Timestamp':<26s} {'MAC':<18s} {'Signal':>7s} {'Ch':>4s} {'Type':<12s} {'Messages'}")
            typer.echo("  " + "-" * 88)
            for r in rows:
                typer.echo(
                    f"  {r.get('timestamp') or '':<26s}"
                    f" {r.get('mac') or '':<18s}"
                    f" {str(r.get('signal_dbm','?')):>7s}"
                    f" {str(r.get('channel','?')):>4s}"
                    f" {r.get('frame_type') or '':12s}"
                    f" {r.get('message_types') or ''}"
                )
            typer.echo()
        return

    rows = database.query_drones(
        since=since_dt, uas_id=uas_id, mac=mac,
        anomalies_only=anomalies, limit=limit,
    )
    if output_json:
        typer.echo(json.dumps(rows, indent=2))
        return
    typer.echo(f"\nDrones ({len(rows)} results):")
    typer.echo(f"  {'UAS ID':<24s} {'MAC':<18s} {'Frames':>7s} {'Last Seen':<22s} {'Warnings'}")
    typer.echo("  " + "-" * 90)
    for r in rows:
        uas = (r.get("basic_id") or {}).get("uas_id", "") or r.get("mac", "")
        mac_val = r.get("mac", "")
        fc = r.get("frame_count", 0) or 0
        last = (r.get("last_seen") or "")[:19]
        anom = "; ".join(r.get("anomalies") or [])
        typer.echo(f"  {uas:<24s} {mac_val:<18s} {fc:>7d} {last:<22s} {anom}")
    typer.echo()


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

class _ExportFormat(str, Enum):
    kml = "kml"
    gpx = "gpx"
    both = "both"


def _alt(value):
    """Altitude/height from stored data; the F3411 'unknown' value (-1000 m),
    which older versions stored as a number, becomes None."""
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    return None if value <= -1000.0 else float(value)


def _location_from_dict(d: dict, *, legacy_db_keys: bool = False):
    """Build a LocationMessage from a serialised dict (JSONL message or DB row)."""
    from odid.decode.messages import LocationMessage
    if legacy_db_keys:
        # DroneState.to_dict() uses short keys
        return LocationMessage(
            status_name=d.get("status", "") or "",
            latitude=d.get("latitude"),
            longitude=d.get("longitude"),
            altitude_msl=_alt(d.get("altitude_msl")),
            altitude_geo=_alt(d.get("altitude_geo")),
            height_agl=_alt(d.get("height_agl")),
            speed_horizontal=d.get("speed_h"),
            speed_vertical=d.get("speed_v"),
            direction_deg=d.get("direction"),
        )
    return LocationMessage(
        status_name=d.get("status_name", "") or "",
        latitude=d.get("latitude"),
        longitude=d.get("longitude"),
        altitude_msl=_alt(d.get("altitude_msl")),
        altitude_geo=_alt(d.get("altitude_geo")),
        height_agl=_alt(d.get("height_agl")),
        speed_horizontal=d.get("speed_horizontal"),
        speed_vertical=d.get("speed_vertical"),
        direction_deg=d.get("direction_deg"),
    )


def _basic_id_from_dict(d: dict):
    from odid.decode.messages import BasicIdMessage
    return BasicIdMessage(
        uas_id=d.get("uas_id", "") or "",
        ua_type_name=d.get("ua_type_name", d.get("ua_type", "")) or "",
        id_type_name=d.get("id_type_name", d.get("id_type", "")) or "",
    )


def _utcnow():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc)


def _parse_ts(value, default):
    """Parse an ISO timestamp as an aware UTC datetime (naive = local time)."""
    from datetime import datetime, timezone
    if not value:
        return default
    try:
        ts = datetime.fromisoformat(value)
        if ts.tzinfo is None:
            ts = ts.astimezone()  # legacy rows were written in local time
        return ts.astimezone(timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return default


def _drones_from_db(db_path: Path) -> list:
    import sqlite3
    from odid.track.tracker import DroneState

    try:
        with _open_db_readonly(db_path) as database:
            drone_dicts = database.get_all_drones()
            positions = {}
            if hasattr(database, "positions_for"):
                for d in drone_dicts:
                    positions[d["mac"]] = database.positions_for(d["mac"])
    except sqlite3.Error as e:
        typer.echo(f"ERROR: Could not read database {db_path}: {e}", err=True)
        raise typer.Exit(1)

    drones = []
    for d in drone_dicts:
        ds = DroneState(mac=d["mac"])
        ds.location_history = deque()  # export the whole track, not the live-view cap
        ds.frame_count = d.get("frame_count", 0) or 0
        if d.get("basic_id"):
            ds.basic_id = _basic_id_from_dict(d["basic_id"])
        last_seen = _parse_ts(d.get("last_seen"), _utcnow())
        ds.last_seen = last_seen
        ds.first_seen = _parse_ts(d.get("first_seen"), last_seen)
        for p in positions.get(d["mac"]) or []:
            loc = _location_from_dict(p)
            if loc.latitude is not None and loc.longitude is not None:
                ds.location_history.append((_parse_ts(p.get("ts"), last_seen), loc))
        history = [] if ds.location_history else (d.get("location_history") or [])
        for h in history:
            loc = _location_from_dict(h, legacy_db_keys="speed_h" in h or "status" in h)
            if loc.latitude is not None:
                ds.location_history.append((_parse_ts(h.get("timestamp"), last_seen), loc))
        if d.get("location"):
            ds.location = _location_from_dict(d["location"], legacy_db_keys=True)
            if not ds.location_history and ds.location.latitude is not None:
                ds.location_history.append((last_seen, ds.location))
        drones.append(ds)
    return drones


def _is_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _iter_jsonl_messages(messages):
    """Yield message dicts from a JSONL record, flattening Message Packs."""
    if not isinstance(messages, list):
        return
    for msg_d in messages:
        if not isinstance(msg_d, dict):
            continue
        if msg_d.get("msg_type") == "Message Pack":
            yield from (m for m in (msg_d.get("messages") or []) if isinstance(m, dict))
        else:
            yield msg_d


def _drones_from_jsonl(jsonl_path: Path) -> list:
    from odid.track.tracker import DroneState

    drones: dict = {}
    frame_count = skip_count = 0
    with open(jsonl_path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                if not isinstance(rec, dict):
                    raise TypeError("record is not an object")
                mac = rec.get("source_mac") or rec.get("mac")
                if not mac:
                    continue
                if not isinstance(mac, str):
                    raise TypeError("mac is not a string")
                ts = _parse_ts(rec.get("timestamp"), _utcnow())
                drone = drones.get(mac)
                if drone is None:
                    drone = drones[mac] = DroneState(mac=mac)
                    drone.location_history = deque()  # whole track, no live-view cap
                    drone.first_seen = drone.last_seen = ts
                else:
                    drone.first_seen = min(drone.first_seen, ts)
                    drone.last_seen = max(drone.last_seen, ts)
                drone.frame_count += 1
                for msg_d in _iter_jsonl_messages(rec.get("messages")):
                    msg_type = msg_d.get("msg_type", "")
                    if msg_type == "Location" and _is_number(msg_d.get("latitude")) \
                            and _is_number(msg_d.get("longitude")):
                        loc = _location_from_dict(msg_d)
                        drone.location = loc
                        drone.location_history.append((ts, loc))
                    elif msg_type == "Basic ID":
                        drone.basic_id = _basic_id_from_dict(msg_d)
            except (ValueError, TypeError, AttributeError):
                skip_count += 1
                continue
            frame_count += 1

    typer.echo(f"Loaded {frame_count} records → {len(drones)} drones from {jsonl_path}")
    if skip_count:
        typer.echo(f"WARNING: {skip_count} corrupt line(s) skipped in {jsonl_path}", err=True)
        log.warning("JSONL export: skipped %d corrupt line(s) in %s", skip_count, jsonl_path)
    return list(drones.values())


@app.command("export")
def cmd_export(
    jsonl: Annotated[Optional[str], typer.Argument(metavar="JSONL",
                      help="Source: session JSONL log file")] = None,
    db: Annotated[Optional[str], typer.Option("--db", metavar="PATH",
                   help="Source: SQLite database (default: <log-dir>/odid_drones.db)")] = None,
    format: Annotated[_ExportFormat, typer.Option("--format", case_sensitive=False,
                       help="Export format")] = _ExportFormat.kml,
    out: Annotated[Optional[str], typer.Option("--out", metavar="PATH",
                    help="Output file path (for 'both': path stem, .kml/.gpx are appended)")] = None,
):
    """Export flight tracks to KML or GPX."""
    from odid.output.export import export_kml, export_gpx

    log_dir = Path(_log_dir)

    if jsonl:
        jsonl_path = Path(jsonl).expanduser()
        if not jsonl_path.is_file():
            what = "not a file" if jsonl_path.exists() else "not found"
            typer.echo(f"ERROR: JSONL file {what}: {jsonl_path}", err=True)
            raise typer.Exit(1)
        try:
            drones = _drones_from_jsonl(jsonl_path)
        except OSError as e:
            typer.echo(f"ERROR: Could not read {jsonl_path}: {e.strerror or e}", err=True)
            raise typer.Exit(1)
    else:
        db_path = Path(db) if db else log_dir / "odid_drones.db"
        drones = _drones_from_db(db_path)
        typer.echo(f"Loaded {len(drones)} drones from {db_path}")

    if not drones:
        typer.echo("No drones to export.")
        return

    fmt = format.value
    if out:
        base = Path(out)
        if fmt == "both":
            stem = base.with_suffix("") if base.suffix.lower() in (".kml", ".gpx") else base
            paths = {"kml": stem.with_name(stem.name + ".kml"), "gpx": stem.with_name(stem.name + ".gpx")}
        else:
            paths = {fmt: base}
    else:
        paths = {"kml": log_dir / "export.kml", "gpx": log_dir / "export.gpx"}

    exported = []
    if fmt in ("kml", "both"):
        export_kml(drones, paths["kml"])
        exported.append(str(paths["kml"]))
    if fmt in ("gpx", "both"):
        export_gpx(drones, paths["gpx"])
        exported.append(str(paths["gpx"]))

    typer.echo("Exported:")
    for p in exported:
        typer.echo(f"  {p}")


# ---------------------------------------------------------------------------
# Pipeline helpers
# ---------------------------------------------------------------------------

class _OutputOpenError(RuntimeError):
    """An output backend could not be opened."""


class _SessionBusy(Exception):
    """Another process already holds this session timestamp's lock."""


class _SessionLock:
    """``odid_session_<ts>.lock`` held with flock() while a session runs."""

    def __init__(self, log_dir: Path, session_ts: str):
        import fcntl
        log_dir.mkdir(parents=True, exist_ok=True)
        self.path = log_dir / f"odid_session_{session_ts}.lock"
        # "a", not "w": never truncate a lock file another process holds
        self._f = open(self.path, "a")
        try:
            fcntl.flock(self._f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self._f.close()
            self._f = None
            raise _SessionBusy(self.path) from None
        self._f.truncate(0)
        self._f.write(f"{os.getpid()}\n")
        self._f.flush()

    def close(self) -> None:
        if self._f is None:
            return
        try:
            self.path.unlink(missing_ok=True)
        finally:
            self._f.close()  # releases the flock
            self._f = None

    @staticmethod
    def is_held(path: Path) -> bool:
        """True if another live process holds this session's lock."""
        import fcntl
        try:
            with open(path) as f:
                try:
                    fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                fcntl.flock(f, fcntl.LOCK_UN)
        except OSError:
            return False
        return False


def _gated(callback, frame_filter):
    """Wrap a tracker on_update callback so it only sees drones passing --filter."""
    if frame_filter is None:
        return callback

    def _cb(drone, frame):
        if frame_filter(drone):
            callback(drone, frame)
    return _cb


def _build_pipeline(frame_filter=None):
    """Construct tracker and output backends from global flags.

    All session files share one timestamp. If any backend fails to open, the
    ones already opened are closed and _OutputOpenError is raised.
    """
    import sqlite3
    from datetime import datetime
    from odid.track.tracker import DroneTracker
    tracker = DroneTracker(max_drones=_max_drones)
    outputs: dict = {}
    # Held for the whole session so a concurrent _rotate_logs() skips our
    # files. Sessions never share a timestamp (the CSV and pcap would be
    # truncated): one in use by a running session, or whose files a session
    # that just ended left behind, makes this one wait for the next second.
    deadline = time.monotonic() + 5.0
    while True:
        session_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        try:
            lock = _SessionLock(Path(_log_dir), session_ts)
        except _SessionBusy:
            lock = None
        except OSError as e:
            raise _OutputOpenError(f"Could not create log directory {_log_dir!r}: {e}") from e
        if lock is not None:
            if not any(f != lock.path for f in Path(_log_dir).glob(f"odid_*_{session_ts}.*")):
                outputs["_lock"] = lock
                break
            lock.close()
        if time.monotonic() > deadline:
            raise _OutputOpenError(
                f"Could not get a free session timestamp in {_log_dir!r} "
                "(another odid session is starting at the same moment)")
        time.sleep(0.25)

    def _open(name, factory):
        try:
            outputs[name] = factory()
        except (OSError, sqlite3.Error) as e:
            for opened_name, out in outputs.items():
                try:
                    out.close()
                except Exception:
                    log.debug("closing %s after failure", opened_name, exc_info=True)
            raise _OutputOpenError(f"Could not open {name} output in {_log_dir!r}: {e}") from e

    if not _no_jsonl:
        from odid.output.jsonl import JSONLWriter
        _open("jsonl", lambda: JSONLWriter(_log_dir, session_ts=session_ts))

    if not _no_pcap:
        from odid.output.pcap import PcapExporter
        _open("pcap", lambda: PcapExporter(_log_dir, session_ts=session_ts))

    if not _no_csv:
        from odid.output.csv import CSVWriter
        _open("csv", lambda: CSVWriter(_log_dir, session_ts=session_ts))

    if not _no_db:
        from odid.track.db import DroneDB
        _open("db", lambda: DroneDB(Path(_log_dir) / "odid_drones.db"))

        # Runs inside tracker.process_frame (serialised by the tracker lock),
        # so the drone state is consistent while it is serialised. DroneDB
        # guards its own connection; the writer thread flushes idle commits.
        # While the disk is nearly full only the per-drone row is kept current.
        def _on_update(drone, frame):
            outputs["db"].update_drone(drone)
            guard = _disk_guard
            if guard is None or not guard.low:
                outputs["db"].log_frame(frame)
        tracker.on_update(_gated(_on_update, frame_filter))

    return tracker, outputs


class _DiskGuard:
    """Pause per-frame logging (pcap, JSONL, CSV and the database's frames
    and positions) while the log directory's filesystem is nearly full, so
    an unattended sensor never fills its SD card. Each drone's database row
    keeps being updated. Checked at most every ``interval`` seconds by the
    writer thread; others read ``low``."""

    def __init__(self, path: str, min_free_mb: int, interval: float = 30.0):
        self.path = path
        self.min_free = min_free_mb * 1024 * 1024
        self.interval = interval
        self.low = False
        self.free_bytes: Optional[int] = None
        self._next = 0.0

    def check(self) -> bool:
        """True while writing is paused."""
        if self.min_free <= 0:
            return False
        now = time.monotonic()
        if now < self._next:
            return self.low
        self._next = now + self.interval
        import shutil
        try:
            self.free_bytes = shutil.disk_usage(self.path).free
        except OSError:
            return self.low
        low = self.free_bytes < self.min_free
        if low and not self.low:
            log.error("Low disk space in %s (%d MB free < %d MB): pausing pcap/JSONL/CSV "
                      "and the database frame log until space is freed", self.path,
                      self.free_bytes // 2**20, self.min_free // 2**20)
        elif self.low and not low:
            log.warning("Disk space recovered in %s, resuming frame logging", self.path)
        self.low = low
        return low


# The running session's disk guard (read by the web health page).
_disk_guard: Optional[_DiskGuard] = None


def _start_writer_thread(outputs: dict):
    """Start a background thread that drains the write queue.

    Decouples slow I/O (pcap, jsonl, csv) from the hot capture thread and
    flushes batched DB commits when capture goes quiet.
    Returns (queue, thread).
    """
    global _disk_guard
    write_q: queue.Queue = queue.Queue(maxsize=4000)
    db = outputs.get("db")
    guard = _disk_guard = _DiskGuard(_log_dir, _min_free_mb)

    def _worker():
        while True:
            try:
                item = write_q.get(timeout=1.0)
            except queue.Empty:
                guard.check()     # keep ``low`` current for the DB frame log
                # Idle tick: get buffered data onto disk even when frames stop
                if db is not None and hasattr(db, "commit_if_due"):
                    try:
                        db.commit_if_due()
                    except Exception:
                        log.exception("DB commit error")
                for name in ("csv", "pcap"):
                    out = outputs.get(name)
                    if out is not None and hasattr(out, "flush_if_due"):
                        try:
                            out.flush_if_due()
                        except Exception:
                            log.exception("%s flush error", name)
                continue
            if item is None:
                write_q.task_done()
                break
            frame, snap = item  # snap: {"uas_id", "frame_count"} taken at capture time
            if guard.check():
                write_q.task_done()
                continue
            try:
                if "jsonl" in outputs:
                    outputs["jsonl"].write_frame(frame, snap)
                if "csv" in outputs:
                    outputs["csv"].write_frame(frame, (snap or {}).get("uas_id") or "")
                if "pcap" in outputs and frame.raw_pkt is not None:
                    outputs["pcap"].write_packet(frame.raw_pkt)
            except Exception:
                log.exception("Writer thread error")
            finally:
                write_q.task_done()

    t = threading.Thread(target=_worker, daemon=True, name="odid-writer")
    t.start()
    return write_q, t


class _DbPruner:
    """Background thread deleting database history older than
    ``_db_retention_days`` (0 = keep forever): first a minute after start,
    then every ``interval`` seconds, or at once after ``wake()``."""

    def __init__(self, db, interval: float = 3600.0, first_delay: float = 60.0):
        self._db = db
        self._interval = interval
        self._first_delay = first_delay
        self._wake = threading.Event()
        self._stopping = False
        self._thread = threading.Thread(target=self._run, daemon=True, name="odid-db-prune")
        self._thread.start()

    def _run(self):
        from datetime import timedelta
        from odid.track.tracker import utcnow
        delay = self._first_delay
        while True:
            self._wake.wait(delay)
            self._wake.clear()
            if self._stopping:
                return
            delay = self._interval
            days = _db_retention_days
            if days <= 0:
                continue
            try:
                removed = self._db.prune(utcnow() - timedelta(days=days),
                                         should_stop=lambda: self._stopping)
            except Exception:
                log.exception("Database pruning failed")
                continue
            if any(removed.values()):
                log.info("Database: removed history older than %d days (%d frames, "
                         "%d positions, %d drones)", days, removed["frames"],
                         removed["positions"], removed["drones"])

    def wake(self) -> None:
        self._wake.set()

    def stop(self) -> None:
        self._stopping = True
        self._wake.set()
        self._thread.join(timeout=_shutdown_timeout)


def _drain_writer(write_q: queue.Queue, writer_thread: threading.Thread):
    """Signal the writer thread to stop and wait for it.

    Callers must stop feeding the queue first (see ``_LiveSession._closing``).
    """
    console.print("  Flushing write queue…")
    try:
        write_q.put(None, timeout=_shutdown_timeout)  # sentinel
    except queue.Full:
        log.warning("Write queue still full after %ds, giving up on flush", _shutdown_timeout)
    writer_thread.join(timeout=_shutdown_timeout)
    if writer_thread.is_alive():
        log.warning(
            "Writer thread still running after %ds; some frames may not have been flushed",
            _shutdown_timeout,
        )
        console.print(
            f"  [red]WARNING: Writer thread did not finish within {_shutdown_timeout}s. "
            "Some data may be incomplete.[/red]",
        )


def _settings_service(opts, session, dash):
    """SettingsService for the dashboard, applying live fields to this run."""
    from odid.web.settings import SettingsService
    lock = threading.Lock()

    def apply(changes: dict) -> None:
        global _min_free_mb, _verbose, _max_drones, _db_retention_days
        with lock:
            if "lat" in changes or "lon" in changes:
                opts.lat = changes.get("lat", opts.lat)
                opts.lon = changes.get("lon", opts.lon)
                session.observer = (opts.lat, opts.lon)
                dash.set_observer(opts.lat, opts.lon)
            if "drone_ttl" in changes:
                _stop_evict_thread(session.evict_thread)
                session.evict_thread = None
                opts.drone_ttl = changes["drone_ttl"]
                if opts.drone_ttl > 0:
                    session.evict_thread = _start_evict_thread(session.tracker, opts.drone_ttl)
            if "max_drones" in changes:
                _max_drones = changes["max_drones"]
                session.tracker.set_max_drones(_max_drones)
            if "db_retention_days" in changes:
                _db_retention_days = changes["db_retention_days"]
                if session.db_pruner:
                    session.db_pruner.wake()
            if "min_free_mb" in changes:
                _min_free_mb = changes["min_free_mb"]
                guard = _disk_guard
                if guard is not None:
                    guard.min_free = _min_free_mb * 1024 * 1024
                    guard._next = 0.0     # re-check on the next write
            if "verbose" in changes:
                _verbose = changes["verbose"]
                logging.getLogger().setLevel(logging.DEBUG if _verbose else logging.INFO)
                logging.getLogger("scapy").setLevel(logging.NOTSET if _verbose else logging.WARNING)
        log.info("Settings applied: %s", ", ".join(f"{k}={v!r}" for k, v in changes.items()))

    running = {
        "lat": opts.lat, "lon": opts.lon, "drone_ttl": opts.drone_ttl,
        "max_drones": _max_drones, "db_retention_days": _db_retention_days,
        "min_free_mb": _min_free_mb, "max_sessions": _max_sessions,
        "no_pcap": _no_pcap, "no_jsonl": _no_jsonl, "no_csv": _no_csv, "no_db": _no_db,
        "verbose": _verbose,
    }
    return SettingsService(running, apply)


def _start_evict_thread(tracker, ttl_seconds: int):
    """Start a background thread that evicts stale drones periodically."""
    stop_event = threading.Event()
    interval = max(1.0, min(60.0, ttl_seconds / 4))

    def _evict_loop():
        while not stop_event.wait(timeout=interval):
            try:
                evicted = tracker.evict_stale(ttl_seconds)
            except Exception:
                log.exception("Eviction error")
                continue
            if evicted:
                log.debug("TTL eviction: removed %d stale drone(s)", evicted)

    t = threading.Thread(target=_evict_loop, daemon=True, name="odid-evict")
    t.start()
    return (t, stop_event)


def _stop_evict_thread(evict_handle):
    if evict_handle is None:
        return
    t, stop_event = evict_handle
    stop_event.set()
    t.join(timeout=5)


def _make_tui_ctx(tracker, observer, frame_filter=None):
    from odid.output.tui import TUIDisplay
    tui = TUIDisplay(observer_lat=observer[0], observer_lon=observer[1], tracker=tracker)
    tracker.on_update(_gated(tui.update, frame_filter))
    return tui


class _WebStartError(RuntimeError):
    """The web dashboard could not be started (e.g. port in use)."""


def _web_url(host: str, port: int, scheme: str = "http") -> str:
    shown = "localhost" if host in ("127.0.0.1", "0.0.0.0", "::", "::1", "localhost") else host
    if ":" in shown:
        shown = f"[{shown}]"
    return f"{scheme}://{shown}:{port}/"


def _web_urls(opts, dash=None) -> str:
    urls = [_web_url(opts.web_host, opts.web_port)]
    if getattr(opts, "web_tls", False):
        host = opts.web_tls_host
        if host in ("0.0.0.0", "::"):
            import socket as _socket
            host = _socket.gethostname().split(".")[0] + ".local"
        urls.append(_web_url(host, getattr(dash, "tls_port", None) or opts.web_tls_port, "https"))
    return "  ".join(urls)


_LOOPBACK_BINDS = ("127.0.0.1", "localhost", "::1")


def _auth_file() -> Path:
    """Accounts file the dashboard reads: auth.json in the log directory."""
    return Path(_log_dir) / "auth.json"


def _web_security(opts):
    """(AuthStore, tls tuple or None) for a dashboard, enforcing the rules:

    * no accounts → every listener must be on loopback;
    * accounts + a non-loopback listener → that listener must be HTTPS
      (unless allow_insecure_http), so passwords never cross the network in
      clear text.
    Raises _WebStartError with what to do.
    """
    from odid.web.auth import AuthStore
    auth = AuthStore(_auth_file())
    tls = None
    if getattr(opts, "web_tls", False):
        from odid.web import tls as tlsmod
        try:
            ctx = tlsmod.server_context(Path(opts.tls_cert), Path(opts.tls_key))
        except (OSError, ValueError) as e:   # ssl.SSLError is an OSError
            raise _WebStartError(
                f"Cannot load the TLS certificate {opts.tls_cert} / key {opts.tls_key}: {e}. "
                "Create one with: sudo odid tls") from e
        tls = (opts.web_tls_host, opts.web_tls_port, ctx)
    plain_remote = opts.web_host not in _LOOPBACK_BINDS
    tls_remote = tls is not None and opts.web_tls_host not in _LOOPBACK_BINDS
    if (plain_remote or tls_remote) and not auth.has_users():
        raise _WebStartError(
            "Refusing to serve the dashboard to the network without sign-in: no accounts in "
            f"{_auth_file()}. Create one with: sudo odid passwd <name>  "
            "(or keep web_host on 127.0.0.1)")
    if plain_remote and not getattr(opts, "allow_insecure_http", False):
        raise _WebStartError(
            f"Refusing plain HTTP on {opts.web_host}: passwords would cross the network "
            "unencrypted. Use HTTPS (web_tls = true, see 'odid tls') and keep web_host on "
            "127.0.0.1, or set allow_insecure_http = true")
    return auth, tls


def _make_web_dashboard(dash_cls, opts, tracker, frame_filter=None, db=None):
    auth, tls = _web_security(opts)
    allowed = list(getattr(opts, "allowed_hosts", None) or [])
    if auth.has_users():
        # Reached through "tailscale serve": accept the node's MagicDNS name
        from odid.web.tls import tailscale_dns_name
        ts_name = tailscale_dns_name()
        if ts_name and ts_name not in allowed:
            allowed.append(ts_name)
    dash = dash_cls(host=opts.web_host, port=opts.web_port,
                    observer_lat=opts.lat, observer_lon=opts.lon,
                    allowed_hosts=allowed or None, db=db, auth=auth, tls=tls,
                    trust_proxy=getattr(opts, "trusted_proxy", False))
    tracker.on_update(_gated(dash.on_update, frame_filter))
    if hasattr(tracker, "on_evict") and hasattr(dash, "remove_drone"):
        tracker.on_evict(dash.remove_drone)
    return dash


def _start_dash(dash, opts) -> None:
    try:
        dash.start()
    except Exception as e:
        raise _WebStartError(
            f"Web dashboard failed to start on {opts.web_host}:{opts.web_port}: {e}"
        ) from e


def _start_web_dashboard(opts, tracker, frame_filter=None, db=None):
    """Create and start the web dashboard. Raises _WebStartError / ImportError."""
    from odid.output.web import WebDashboard
    dash = _make_web_dashboard(WebDashboard, opts, tracker, frame_filter, db)
    _start_dash(dash, opts)
    return dash


def _shutdown(tracker, capture, outputs):
    from odid.output.console import print_summary
    console.print("  Saving outputs…")
    pkt_counts = getattr(capture, "packet_counts", None)
    try:
        print_summary(tracker, pkt_counts)
    except Exception:
        log.exception("Error printing summary")

    # Close real outputs first; internal entries ("_lock") last, so the session
    # lock is only released once every file has been flushed and closed.
    for name, output in sorted(outputs.items(), key=lambda kv: kv[0].startswith("_")):
        try:
            if hasattr(output, "close"):
                if not name.startswith("_"):
                    console.print(f"  Closing {name}…")
                output.close()
        except Exception:
            log.exception("Error closing %s", name)

    paths = []
    for out in outputs.values():
        for attr in ("session_file", "pcap_file", "csv_file", "db_path"):
            if hasattr(out, attr):
                paths.append(str(getattr(out, attr)))
    if paths:
        typer.echo("Output files:")
        for p in paths:
            typer.echo(f"  {p}")
        typer.echo()


_SESSION_FILE_RE = re.compile(r"^(odid_session|odid_capture|odid_locations)_(\d{8}_\d{6})")


def _rotate_logs():
    """Prune old session files so that, with the session about to start,
    at most ``_max_sessions`` sessions remain."""
    if _max_sessions <= 0:
        return
    log_path = Path(_log_dir)
    if not log_path.exists():
        return
    sessions: dict[str, list[Path]] = {}
    for f in sorted(log_path.iterdir()):
        m = _SESSION_FILE_RE.match(f.name)
        if m:
            sessions.setdefault(m.group(2), []).append(f)

    sorted_sessions = sorted(sessions.keys())
    keep_old = _max_sessions - 1  # leave room for the new session
    to_delete = sorted_sessions[: max(0, len(sorted_sessions) - keep_old)]
    for ts in to_delete:
        locks = [f for f in sessions[ts] if f.suffix == ".lock"]
        if any(_SessionLock.is_held(f) for f in locks):
            log.info("Log rotation: skipping session %s, still running in another process", ts)
            continue
        for f in sessions[ts]:
            try:
                f.unlink()
                log.debug("Log rotation: deleted %s", f)
            except Exception as e:
                log.warning("Log rotation: failed to delete %s: %s", f, e)


# ---------------------------------------------------------------------------
# Watchlist
# ---------------------------------------------------------------------------

def _load_watchlist(path: str | None) -> set[str]:
    if not path:
        return set()
    p = Path(path).expanduser()
    if not p.exists():
        log.warning("Watchlist file not found: %s", path)
        typer.echo(f"WARNING: Watchlist file not found: {path}", err=True)
        return set()
    ids = set()
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    ids.add(line.lower())
    except OSError as e:
        raise typer.BadParameter(f"Cannot read watchlist {path!r}: {e.strerror or e}")
    log.info("Watchlist loaded: %d IDs from %s", len(ids), path)
    return ids


class _WatchlistAlerter:
    """Raise watchlist alerts at most once per (drone, hit) per ``cooldown`` seconds.

    Webhook POSTs go through a single worker thread with a bounded queue, so a
    busy or unreachable endpoint can never spawn unbounded threads.
    """

    def __init__(self, webhook_url: Optional[str] = None, cooldown: float = 60.0):
        self.webhook_url = webhook_url
        self.cooldown = cooldown
        self._last: dict[tuple[str, str], float] = {}
        self._lock = threading.Lock()
        self._q: Optional[queue.Queue] = None
        self._worker: Optional[threading.Thread] = None
        if webhook_url:
            self._q = queue.Queue(maxsize=100)
            self._worker = threading.Thread(target=self._send_loop, daemon=True, name="odid-webhook")
            self._worker.start()

    def check(self, drone, watchlist: set[str]) -> None:
        if not watchlist or drone is None:
            return
        hits = []
        uas = drone.uas_id
        if uas and uas.lower() in watchlist:
            hits.append(f"UAS ID={uas}")
        op = drone.operator_id
        if op and op.operator_id and op.operator_id.lower() in watchlist:
            hits.append(f"Operator ID={op.operator_id}")
        if not hits:
            return

        now = time.monotonic()
        with self._lock:
            fresh = [h for h in hits if now - self._last.get((drone.mac, h), -1e9) >= self.cooldown]
            for h in fresh:
                self._last[(drone.mac, h)] = now
        if not fresh:
            return

        alert = f"*** WATCHLIST MATCH: {drone.mac}: {', '.join(fresh)} ***"
        log.warning(alert)
        try:
            from colorama import Fore, Style
            typer.echo(Fore.MAGENTA + Style.BRIGHT + alert + Style.RESET_ALL)
        except ImportError:
            typer.echo(alert)

        if self._q is not None:
            try:
                self._q.put_nowait({"event": "watchlist_match", "mac": drone.mac, "hits": fresh})
            except queue.Full:
                log.warning("Webhook queue full, alert not posted")

    def _send_loop(self) -> None:
        import urllib.request
        while True:
            payload = self._q.get()
            if payload is None:
                return
            try:
                data = json.dumps(payload).encode()
                req = urllib.request.Request(self.webhook_url, data=data,
                                             headers={"Content-Type": "application/json"})
                urllib.request.urlopen(req, timeout=5).close()
            except Exception as e:
                log.debug("Webhook POST failed: %s", e)

    def close(self) -> None:
        if self._q is not None:
            try:
                self._q.put_nowait(None)
            except queue.Full:
                pass
            self._worker.join(timeout=2)


# ---------------------------------------------------------------------------
# Filter expression
# ---------------------------------------------------------------------------

# All valid filter fields with short descriptions
_VALID_FILTER_FIELDS = {
    "ua_type":     "UA type (e.g. Multirotor, FixedWing)",
    "uas_id":      "UAS ID (exact or prefix:ABC)",
    "status":      "Flight status (Airborne, Ground, Emergency)",
    "operator_id": "Operator ID (partial match)",
}


def _compile_filter(expr: str | None):
    """Compile a filter expression into a callable(drone) -> bool.

    Supported expressions::

        ua_type=Multirotor
        uas_id=prefix:ABC
        uas_id=ABC123
        status=Airborne
        operator_id=FLEET

    Raises ``typer.Exit`` with a helpful message on invalid expressions.
    """
    if not expr:
        return None

    if "=" not in expr:
        typer.echo(
            f"ERROR: Invalid filter expression {expr!r}: missing '='.\n"
            f"  Example: --filter ua_type=Multirotor",
            err=True,
        )
        raise typer.Exit(1)

    key, value = expr.split("=", 1)
    key = key.strip().lower()
    value = value.strip()

    if key not in _VALID_FILTER_FIELDS:
        import difflib
        suggestions = difflib.get_close_matches(key, _VALID_FILTER_FIELDS, n=2, cutoff=0.4)
        hint = f"  Did you mean: {', '.join(suggestions)}?" if suggestions else ""
        valid = "\n".join(f"  {k:<16s} - {v}" for k, v in _VALID_FILTER_FIELDS.items())
        typer.echo(
            f"ERROR: Unknown filter field {key!r}.\n{hint}\n\nValid fields:\n{valid}",
            err=True,
        )
        raise typer.Exit(1)

    if key == "ua_type":
        target = value.lower()
        def _f(drone):
            if drone is None or drone.basic_id is None:
                return False
            return target in drone.basic_id.ua_type_name.lower()
        return _f

    if key == "uas_id":
        if value.startswith("prefix:"):
            prefix = value[7:].lower()
            def _f(drone):
                if drone is None or not drone.uas_id:
                    return False
                return drone.uas_id.lower().startswith(prefix)
        else:
            target = value.lower()
            def _f(drone):
                if drone is None or not drone.uas_id:
                    return False
                return drone.uas_id.lower() == target
        return _f

    if key == "status":
        target = value.lower()
        def _f(drone):
            if drone is None or drone.location is None:
                return False
            return target in drone.location.status_name.lower()
        return _f

    if key == "operator_id":
        target = value.lower()
        def _f(drone):
            if drone is None or drone.operator_id is None:
                return False
            return target in drone.operator_id.operator_id.lower()
        return _f

    return None  # unreachable, but satisfies type checker


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

# Global options that users naturally type after the subcommand
# ("odid sniff wlan1 --log-dir /data"). Click only accepts group options before
# the subcommand, so main() moves them there. "--db" is NOT hoisted: query and
# export have their own "--db PATH" option.
_HOISTABLE_FLAGS = {
    "-v", "--verbose", "--quiet", "--log-json",
    "--no-pcap", "--pcap", "--no-jsonl", "--jsonl", "--no-csv", "--csv", "--no-db",
}
_HOISTABLE_VALUED = {"--log-dir", "--max-sessions", "--timeout-shutdown"}


def _subcommand_value_options(name: str) -> set[str]:
    """Option strings of subcommand ``name`` that take a value (e.g. '--db')."""
    import click
    group = typer.main.get_command(app)
    cmd = group.commands.get(name) if isinstance(group, click.Group) else None
    opts: set[str] = set()
    for p in getattr(cmd, "params", []):
        if isinstance(p, click.Option) and not p.is_flag and not p.count:
            opts.update(p.opts)
    return opts


def _hoist_global_options(argv: list[str]) -> list[str]:
    """Move global options found after the subcommand to before it.

    The subcommand is the first non-option token that isn't the value of a
    global option. After it, a token that is the value of one of the
    subcommand's own options is never hoisted, and a valued global option is
    only moved together with its value.
    """
    commands = {c.name for c in app.registered_commands}

    # 1. Locate the subcommand, skipping global options and their values.
    idx = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            return argv
        if arg.split("=", 1)[0] in _HOISTABLE_VALUED and "=" not in arg:
            i += 2
            continue
        if arg.startswith("-"):
            i += 1
            continue
        if arg in commands:
            idx = i
        break
    if idx is None:
        return argv

    head, tail = argv[:idx], argv[idx + 1:]
    sub_valued = _subcommand_value_options(argv[idx])
    hoisted: list[str] = []
    rest: list[str] = []
    i = 0
    while i < len(tail):
        arg = tail[i]
        if arg == "--":
            rest.extend(tail[i:])
            break
        name = arg.split("=", 1)[0]
        if name in sub_valued and "=" not in arg:
            # Subcommand option + its value: keep both where they are
            rest.extend(tail[i:i + 2])
            i += 2
            continue
        if arg in _HOISTABLE_FLAGS:
            hoisted.append(arg)
        elif name in _HOISTABLE_VALUED and ("=" in arg or i + 1 < len(tail)):
            hoisted.append(arg)
            if "=" not in arg:
                hoisted.append(tail[i + 1])
                i += 1
        else:
            rest.append(arg)  # includes a valued global missing its value → click reports it
        i += 1
    return head + hoisted + [argv[idx]] + rest


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    app(args=_hoist_global_options(list(argv)), prog_name="odid")


if __name__ == "__main__":
    main()
