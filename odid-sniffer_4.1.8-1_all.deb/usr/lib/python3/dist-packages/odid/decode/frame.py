"""WiFi frame extraction for OpenDroneID.

Supports the two Wi-Fi transports of ASTM F3411 (layouts per
opendroneid-core-c wifi.c):

  1. Wi-Fi NAN Service Discovery Frames (mgmt type=0 subtype=13, Action)
     - Category: Public (0x04), Action: Vendor Specific (0x09)
     - OUI: 50:6F:9A (Wi-Fi Alliance), OUI Type: 0x13 (NAN)
     - NAN attributes follow; the Service Descriptor Attribute (ID 0x03)
       with service ID 88:69:19:9D:92:09 (hash of "org.opendroneid.remoteid")
       carries the service info = message counter + Message Pack.

  2. Wi-Fi Beacon frames (type=0 subtype=8)
     - Vendor-specific Information Element (ID 221)
     - OUI: FA:0B:BC (ASD-STAN), OUI Type: 0x0D
     - IE body: message counter + Message Pack

The message counter is a full 8-bit value. The protocol version comes from
the low nibble of the (pack) message header byte.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from scapy.layers.dot11 import Dot11, Dot11Elt, RadioTap

from odid.decode.constants import (
    ODID_WIFI_OUI,
    ODID_OUI_TYPE,
    NAN_WFA_OUI,
    NAN_OUI_TYPE,
    NAN_ATTR_SERVICE_DESCRIPTOR,
    NAN_ODID_SERVICE_ID,
    MGMT_TYPE,
    ACTION_SUBTYPE,
    BEACON_SUBTYPE,
    PUBLIC_ACTION_CATEGORY,
    VENDOR_SPECIFIC_ACTION,
    ODID_MSG_SIZE,
)
from odid.decode.messages import ODIDDecoder

log = logging.getLogger(__name__)


@dataclass
class ODIDFrame:
    """Represents a decoded ODID frame from a WiFi packet."""
    source_mac: str = ""
    signal_dbm: Optional[int] = None
    channel: Optional[int] = None
    frame_type: str = ""          # "NAN Action" or "Beacon"
    message_counter: int = 0
    proto_version: int = 0
    messages: list = field(default_factory=list)
    raw_payload: bytes = b""
    # Raw scapy packet, used for pcap export; None for BT-sourced frames
    raw_pkt: Any = field(default=None, repr=False, compare=False)
    # Capture time (UTC-aware). From pkt.time for WiFi frames (so replays keep
    # the original timing); capture sources set it from the wall clock.
    timestamp: Optional[datetime] = None
    # SDR receivers report an SNR estimate (dB) rather than an absolute level
    snr_db: Optional[float] = None


def packet_timestamp(pkt) -> Optional[datetime]:
    """Return the scapy packet's capture time as a UTC-aware datetime, or None."""
    t = getattr(pkt, "time", None)
    if t is None:
        return None
    try:
        return datetime.fromtimestamp(float(t), tz=timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def extract_radio_info(pkt) -> tuple[Optional[int], Optional[int]]:
    """Extract signal strength and channel from RadioTap header.

    Returns (signal_dbm, channel).
    """
    signal = None
    channel = None

    if pkt.haslayer(RadioTap):
        rt = pkt[RadioTap]
        # Signal strength - try common attribute names
        for attr in ("dBm_AntSignal", "dBm_antsignal", "Antenna_Signal"):
            if hasattr(rt, attr):
                val = getattr(rt, attr)
                if val is not None:
                    signal = int(val)
                    log.debug("RadioTap signal via %s: %d dBm", attr, signal)
                    break

        if hasattr(rt, "ChannelFrequency"):
            channel = freq_to_channel(rt.ChannelFrequency)
            log.debug("RadioTap freq %s MHz -> channel %s", rt.ChannelFrequency, channel)
    else:
        log.debug("No RadioTap layer in packet")

    return signal, channel


def freq_to_channel(freq) -> Optional[int]:
    """Map a centre frequency in MHz to an IEEE 802.11 channel number."""
    if not freq:
        return None
    freq = int(freq)
    if freq == 2484:
        return 14
    if 2412 <= freq <= 2472:
        return (freq - 2407) // 5
    if freq == 5935:                  # 6 GHz channel 2 (sits below channel 1)
        return 2
    if 5955 <= freq <= 7115:          # 6 GHz band
        return (freq - 5950) // 5
    if 5000 <= freq <= 5925:
        return (freq - 5000) // 5
    if 4910 <= freq <= 4980:          # 4.9 GHz public safety / Japan
        return (freq - 4000) // 5
    return None


def get_source_mac(pkt) -> str:
    """Extract transmitter MAC address from 802.11 header."""
    if hasattr(pkt, "addr2") and pkt.addr2:
        return pkt.addr2
    return "unknown"


def _action_body(pkt) -> Optional[bytes]:
    """Return the body of a management Action frame, or None."""
    if not pkt.haslayer(Dot11):
        return None
    dot11 = pkt[Dot11]
    if dot11.type != MGMT_TYPE or dot11.subtype != ACTION_SUBTYPE:
        return None
    try:
        return bytes(dot11.payload)
    except Exception:
        return None


def _parse_nan_sdf(body: bytes) -> Optional[bytes]:
    """Find the ODID service info inside a NAN Service Discovery Frame body.

    Port of opendroneid-core-c odid_wifi_receive_message_pack_nan_action_frame(),
    generalised to walk all NAN attributes and to skip the optional Service
    Descriptor Attribute fields (binding bitmap, matching filter, service
    response filter) that precede the service info.

    Returns the service info bytes (message counter + Message Pack) or None.
    """
    if len(body) < 6:
        return None
    if (body[0] != PUBLIC_ACTION_CATEGORY or body[1] != VENDOR_SPECIFIC_ACTION
            or body[2:5] != NAN_WFA_OUI or body[5] != NAN_OUI_TYPE):
        return None

    off = 6
    while off + 3 <= len(body):
        attr_id = body[off]
        attr_len = int.from_bytes(body[off + 1:off + 3], "little")
        attr = body[off + 3:off + 3 + attr_len]
        off += 3 + attr_len
        if len(attr) < attr_len:
            return None  # truncated attribute
        if attr_id != NAN_ATTR_SERVICE_DESCRIPTOR or len(attr) < 9:
            continue
        if attr[0:6] != NAN_ODID_SERVICE_ID:
            continue
        control = attr[8]
        p = 9
        if control & 0x40:            # binding bitmap present
            p += 2
        if control & 0x04:            # matching filter present
            if p >= len(attr):
                return None
            p += 1 + attr[p]
        if control & 0x08:            # service response filter present
            if p >= len(attr):
                return None
            p += 1 + attr[p]
        if not control & 0x10:        # no service info
            return None
        if p >= len(attr):
            return None
        si_len = attr[p]
        info = attr[p + 1:p + 1 + si_len]
        if len(info) < si_len or si_len < 1:
            return None
        return bytes(info)
    return None


def is_odid_action_frame(pkt) -> bool:
    """Check if packet is an ODID Wi-Fi NAN Service Discovery (Action) frame."""
    body = _action_body(pkt)
    if body is None:
        return False
    try:
        return _parse_nan_sdf(body) is not None
    except Exception:
        return False


def is_odid_beacon_frame(pkt) -> bool:
    """Check if packet is a Beacon frame containing ODID vendor IE."""
    if not pkt.haslayer(Dot11):
        return False

    dot11 = pkt[Dot11]
    if dot11.type != MGMT_TYPE or dot11.subtype != BEACON_SUBTYPE:
        return False

    return _find_odid_vendor_ie(pkt) is not None


def is_odid_frame(pkt) -> bool:
    """Check if packet contains any ODID data (Action or Beacon)."""
    return is_odid_action_frame(pkt) or is_odid_beacon_frame(pkt)


def _build_frame(pkt, frame_type: str, service_info: bytes, raw_payload: bytes) -> Optional[ODIDFrame]:
    """Decode counter + messages from a NAN service info / beacon IE body."""
    if len(service_info) < 1:
        log.debug("%s ODID payload too short (%d bytes)", frame_type, len(service_info))
        return None

    signal, channel = extract_radio_info(pkt)
    counter_value = service_info[0]          # full 8-bit message counter
    odid_payload = service_info[1:]
    proto_version = odid_payload[0] & 0x0F if odid_payload else 0

    log.debug(
        "%s frame: mac=%s signal=%s ch=%s counter=%d proto=%d payload_len=%d",
        frame_type, get_source_mac(pkt), signal, channel, counter_value,
        proto_version, len(odid_payload),
    )

    messages = _decode_message_sequence(odid_payload, proto_version)
    log.debug("  Decoded %d message(s) from %s frame", len(messages), frame_type)

    return ODIDFrame(
        source_mac=get_source_mac(pkt),
        signal_dbm=signal,
        channel=channel,
        frame_type=frame_type,
        message_counter=counter_value,
        proto_version=proto_version,
        messages=messages,
        raw_payload=bytes(raw_payload),
        raw_pkt=pkt,
        timestamp=packet_timestamp(pkt),
    )


def extract_odid_from_action(pkt) -> Optional[ODIDFrame]:
    """Extract ODID messages from a Wi-Fi NAN Service Discovery Frame."""
    body = _action_body(pkt)
    if body is None:
        return None
    try:
        service_info = _parse_nan_sdf(body)
        if service_info is None:
            return None
        return _build_frame(pkt, "NAN Action", service_info, body)
    except Exception:
        log.exception("Failed to extract ODID from Action frame")
        return None


def extract_odid_from_beacon(pkt) -> Optional[ODIDFrame]:
    """Extract ODID messages from a WiFi Beacon vendor-specific IE.

    The vendor IE payload after OUI + OUI Type:
      [0]     Message Counter (8 bit)
      [1..]   Message Pack (or single 25-byte messages)
    """
    ie_data = _find_odid_vendor_ie(pkt)
    if ie_data is None:
        return None
    try:
        return _build_frame(pkt, "Beacon", ie_data, ie_data)
    except Exception:
        log.exception("Failed to extract ODID from Beacon frame")
        return None


def extract_odid(pkt) -> Optional[ODIDFrame]:
    """Extract ODID data from any supported frame type."""
    if is_odid_action_frame(pkt):
        return extract_odid_from_action(pkt)
    if is_odid_beacon_frame(pkt):
        return extract_odid_from_beacon(pkt)
    return None


def _decode_message_sequence(data: bytes, default_proto_version: int = 0) -> list:
    """Decode a sequence of 25-byte ODID messages from raw payload.

    A Message Pack consumes the rest of the payload. Each message's protocol
    version is taken from its own header byte; ``default_proto_version`` is
    kept for API compatibility.
    """
    messages = []
    offset = 0

    while offset + ODID_MSG_SIZE <= len(data):
        msg_bytes = data[offset : offset + ODID_MSG_SIZE]
        if (msg_bytes[0] >> 4) & 0x0F == 0x0F:
            decoded = ODIDDecoder.decode_message_byte(data[offset:])
            if decoded:
                messages.append(decoded)
            break
        decoded = ODIDDecoder.decode_message_byte(msg_bytes)
        if decoded:
            messages.append(decoded)
        offset += ODID_MSG_SIZE

    return messages


def _find_odid_vendor_ie(pkt) -> Optional[bytes]:
    """Search Beacon/ProbeResp IEs for ODID vendor-specific element.

    Vendor-specific IE (ID=221):
      [0-2]  OUI
      [3]    OUI Type
      [4..]  Payload

    Returns the payload bytes after OUI+Type, or None.
    """
    try:
        elt = pkt.getlayer(Dot11Elt)
        while elt:
            if elt.ID == 221 and elt.info and len(elt.info) >= 4:
                oui = elt.info[0:3]
                oui_type = elt.info[3]
                if oui == ODID_WIFI_OUI and oui_type == ODID_OUI_TYPE:
                    return bytes(elt.info[4:])
            elt = elt.payload.getlayer(Dot11Elt) if elt.payload else None
    except Exception:
        log.debug("Error scanning IEs", exc_info=True)

    return None
