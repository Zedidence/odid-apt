"""ODID protocol constants per ASTM F3411-19 / F3411-22a."""

from enum import IntEnum

# ASD-STAN OUI used in the Wi-Fi Beacon vendor-specific IE (beacon transport only)
ODID_WIFI_OUI = b"\xfa\x0b\xbc"
ODID_OUI_TYPE = 0x0D

# Wi-Fi NAN transport (opendroneid-core-c wifi.c): Public Action / Vendor
# Specific with the Wi-Fi Alliance OUI and NAN OUI type, carrying a Service
# Descriptor Attribute whose service ID is the hash of "org.opendroneid.remoteid".
NAN_WFA_OUI = b"\x50\x6f\x9a"
NAN_OUI_TYPE = 0x13
NAN_ATTR_SERVICE_DESCRIPTOR = 0x03
NAN_ODID_SERVICE_ID = b"\x88\x69\x19\x9d\x92\x09"

# 802.11 frame type/subtype constants
MGMT_TYPE = 0
ACTION_SUBTYPE = 13
BEACON_SUBTYPE = 8

# Action frame fields
PUBLIC_ACTION_CATEGORY = 0x04
VENDOR_SPECIFIC_ACTION = 0x09

# ODID message size
ODID_MSG_SIZE = 25
ODID_MSG_PAYLOAD_SIZE = 24


class ProtoVersion(IntEnum):
    """ODID protocol versions."""
    F3411_19 = 0       # Original spec
    F3411_22A_V1 = 1   # 2022 revision draft
    F3411_22A = 2      # 2022 revision final


class MessageType(IntEnum):
    """ODID message types (upper nibble of first message byte)."""
    BASIC_ID = 0x0
    LOCATION = 0x1
    AUTH = 0x2
    SELF_ID = 0x3
    SYSTEM = 0x4
    OPERATOR_ID = 0x5
    MESSAGE_PACK = 0xF


class IdType(IntEnum):
    """Basic ID - ID type field."""
    NONE = 0
    SERIAL_NUMBER = 1
    CAA_REGISTRATION = 2
    UTM_UUID = 3
    SPECIFIC_SESSION_ID = 4


ID_TYPE_NAMES = {
    IdType.NONE: "None",
    IdType.SERIAL_NUMBER: "Serial Number",
    IdType.CAA_REGISTRATION: "CAA Registration",
    IdType.UTM_UUID: "UTM UUID",
    IdType.SPECIFIC_SESSION_ID: "Session ID",
}


class UaType(IntEnum):
    """Basic ID - UA (Unmanned Aircraft) type field."""
    NONE = 0
    AEROPLANE = 1
    HELICOPTER_MULTIROTOR = 2
    GYROPLANE = 3
    HYBRID_LIFT = 4
    ORNITHOPTER = 5
    GLIDER = 6
    KITE = 7
    FREE_BALLOON = 8
    CAPTIVE_BALLOON = 9
    AIRSHIP = 10
    FREE_FALL_PARACHUTE = 11
    ROCKET = 12
    TETHERED = 13
    GROUND_OBSTACLE = 14
    OTHER = 15


UA_TYPE_NAMES = {
    UaType.NONE: "None",
    UaType.AEROPLANE: "Aeroplane",
    UaType.HELICOPTER_MULTIROTOR: "Helicopter/Multirotor",
    UaType.GYROPLANE: "Gyroplane",
    UaType.HYBRID_LIFT: "Hybrid Lift",
    UaType.ORNITHOPTER: "Ornithopter",
    UaType.GLIDER: "Glider",
    UaType.KITE: "Kite",
    UaType.FREE_BALLOON: "Free Balloon",
    UaType.CAPTIVE_BALLOON: "Captive Balloon",
    UaType.AIRSHIP: "Airship",
    UaType.FREE_FALL_PARACHUTE: "Free Fall/Parachute",
    UaType.ROCKET: "Rocket",
    UaType.TETHERED: "Tethered Aircraft",
    UaType.GROUND_OBSTACLE: "Ground Obstacle",
    UaType.OTHER: "Other",
}


class FlightStatus(IntEnum):
    """Location message - operational status."""
    UNDECLARED = 0
    GROUND = 1
    AIRBORNE = 2
    EMERGENCY = 3
    REMOTE_ID_SYSTEM_FAILURE = 4


FLIGHT_STATUS_NAMES = {
    FlightStatus.UNDECLARED: "Undeclared",
    FlightStatus.GROUND: "Ground",
    FlightStatus.AIRBORNE: "Airborne",
    FlightStatus.EMERGENCY: "Emergency",
    FlightStatus.REMOTE_ID_SYSTEM_FAILURE: "RID System Failure",
}


class HeightType(IntEnum):
    """Location message - height reference."""
    ABOVE_TAKEOFF = 0
    AGL = 1


class DescriptionType(IntEnum):
    """Self-ID message - description type."""
    TEXT = 0
    EMERGENCY = 1
    EXTENDED_STATUS = 2


DESC_TYPE_NAMES = {
    DescriptionType.TEXT: "Text",
    DescriptionType.EMERGENCY: "Emergency",
    DescriptionType.EXTENDED_STATUS: "Extended Status",
}


class OperatorLocationType(IntEnum):
    """System message - operator location type."""
    TAKEOFF = 0
    LIVE_GNSS = 1
    FIXED = 2


OPERATOR_LOC_TYPE_NAMES = {
    OperatorLocationType.TAKEOFF: "Takeoff",
    OperatorLocationType.LIVE_GNSS: "Live GNSS",
    OperatorLocationType.FIXED: "Fixed",
}


class ClassificationType(IntEnum):
    """System message - UA classification type."""
    UNDECLARED = 0
    EU = 1


class AuthType(IntEnum):
    """Auth message - authentication type."""
    NONE = 0
    UAS_ID_SIGNATURE = 1
    OPERATOR_ID_SIGNATURE = 2
    MESSAGE_SET_SIGNATURE = 3
    NETWORK_REMOTE_ID = 4
    SPECIFIC_AUTHENTICATION = 5
    OPERATOR_ID_PROVIDER = 0xA
    UTM_SYSTEM = 0xB


AUTH_TYPE_NAMES = {
    AuthType.NONE: "None",
    AuthType.UAS_ID_SIGNATURE: "UAS ID Signature",
    AuthType.OPERATOR_ID_SIGNATURE: "Operator ID Signature",
    AuthType.MESSAGE_SET_SIGNATURE: "Message Set Signature",
    AuthType.NETWORK_REMOTE_ID: "Network Remote ID",
    AuthType.SPECIFIC_AUTHENTICATION: "Specific Authentication",
    AuthType.OPERATOR_ID_PROVIDER: "Operator ID Provider",
    AuthType.UTM_SYSTEM: "UTM System",
}


# Coordinate encoding
LAT_LON_SCALE = 1e-7       # degrees per raw unit
ALT_RESOLUTION = 0.5       # meters per raw unit
ALT_OFFSET = -1000.0       # meters
SPEED_RESOLUTION_LO = 0.25 # m/s when speed_mult=0
SPEED_RESOLUTION_HI = 0.75 # m/s when speed_mult=1
VERT_SPEED_RESOLUTION = 0.5  # m/s per raw unit
DIRECTION_SCALE = 1.0        # degrees per raw unit (raw value is integer degrees 0-179)
AREA_RADIUS_SCALE = 10     # meters per raw unit
TIMESTAMP_RESOLUTION = 0.1 # seconds per raw unit

# "Invalid, No Value, or Unknown" encodings per ASTM F3411 / opendroneid-core-c
LAT_LON_INVALID = 0        # lat == 0 and lon == 0 means unknown
ALT_INVALID = 0            # raw 0 == -1000 m == unknown (altitudes, height)
SPEED_INVALID = 255        # raw 255 with speed_mult=1 == 255 m/s == unknown
VERT_SPEED_INVALID = 126   # raw 126 == 63 m/s == unknown
DIRECTION_INVALID = 361    # decoded degrees > 360 (raw 181 + EW) == unknown
LOCATION_TIMESTAMP_INVALID = 0xFFFF
LOCATION_TIMESTAMP_MAX = 36000   # one hour in 0.1 s units
TIMESTAMP_INVALID = 0xFFFFFFFF
ODID_PACK_MAX_MESSAGES = 9
