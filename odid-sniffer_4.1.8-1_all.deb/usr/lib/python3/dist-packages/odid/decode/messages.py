"""ODID message decoders - ASTM F3411 compliant.

Each ODID message is exactly 25 bytes:
  Byte 0: [msg_type:4][proto_version:4]
  Bytes 1-24: type-specific payload

The msg_type nibble and proto_version nibble are extracted by the caller
(frame.py) before dispatch. Decoder functions receive the 24-byte payload
starting at byte 1.
"""

import re
import struct
import unicodedata
import logging
import uuid
from dataclasses import dataclass, field
from typing import Optional

from odid.decode.constants import (
    MessageType,
    IdType,
    ID_TYPE_NAMES,
    UA_TYPE_NAMES,
    FLIGHT_STATUS_NAMES,
    HeightType,
    DESC_TYPE_NAMES,
    OPERATOR_LOC_TYPE_NAMES,
    AUTH_TYPE_NAMES,
    LAT_LON_SCALE, LAT_LON_INVALID,
    ALT_RESOLUTION, ALT_OFFSET, ALT_INVALID,
    SPEED_RESOLUTION_LO, SPEED_RESOLUTION_HI, SPEED_INVALID,
    VERT_SPEED_RESOLUTION, VERT_SPEED_INVALID,
    DIRECTION_SCALE,
    AREA_RADIUS_SCALE, TIMESTAMP_RESOLUTION, TIMESTAMP_INVALID,
    LOCATION_TIMESTAMP_INVALID, LOCATION_TIMESTAMP_MAX, ODID_PACK_MAX_MESSAGES,
    ODID_MSG_SIZE,
)

log = logging.getLogger(__name__)


# --- Decoded message dataclasses ---


# C0/C1 control characters (incl. ESC, CR, BEL, DEL); decoded text comes from
# untrusted radio frames and must never reach a terminal as escape sequences.
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f-\x9f]")


def _clean_text(text: str) -> str:
    """Replace control and format characters in decoded text with U+FFFD.

    Besides C0/C1 controls, Unicode format characters (category Cf: bidi
    overrides/embeddings/isolates U+202A-202E and U+2066-2069, LRM/RLM,
    ALM U+061C, zero-width U+200B-200D, BOM U+FEFF, ...) are replaced so
    untrusted text cannot reorder or hide adjacent fields when displayed.
    """
    text = _CONTROL_CHARS_RE.sub("\ufffd", text)
    if text.isascii():
        return text
    return "".join(
        "\ufffd" if unicodedata.category(ch) == "Cf" else ch
        for ch in text
    )

@dataclass
class BasicIdMessage:
    msg_type: str = "Basic ID"
    proto_version: int = 0
    id_type: int = 0
    id_type_name: str = ""
    ua_type: int = 0
    ua_type_name: str = ""
    uas_id: str = ""


@dataclass
class LocationMessage:
    msg_type: str = "Location"
    proto_version: int = 0
    status: int = 0
    status_name: str = ""
    height_type: int = 0
    height_type_name: str = ""
    ew_direction: int = 0
    speed_multiplier: int = 0
    direction_deg: Optional[float] = None
    speed_horizontal: Optional[float] = None
    speed_vertical: Optional[float] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    altitude_msl: Optional[float] = None   # pressure (barometric) altitude
    height_agl: Optional[float] = None     # Height field (AGL or above takeoff, see height_type)
    horiz_accuracy: Optional[int] = None
    vert_accuracy: Optional[int] = None
    baro_accuracy: Optional[int] = None
    timestamp: Optional[float] = None
    timestamp_accuracy: Optional[float] = None
    altitude_geo: Optional[float] = None   # geodetic altitude (WGS84 HAE)
    speed_accuracy: Optional[int] = None


@dataclass
class AuthMessage:
    msg_type: str = "Auth"
    proto_version: int = 0
    auth_type: int = 0
    auth_type_name: str = ""
    page_number: int = 0
    last_page_index: int = 0
    length: int = 0
    timestamp: Optional[int] = None
    auth_data: bytes = b""


@dataclass
class SelfIdMessage:
    msg_type: str = "Self-ID"
    proto_version: int = 0
    desc_type: int = 0
    desc_type_name: str = ""
    description: str = ""


@dataclass
class SystemMessage:
    msg_type: str = "System"
    proto_version: int = 0
    operator_location_type: int = 0
    operator_location_type_name: str = ""
    classification_type: int = 0
    operator_latitude: Optional[float] = None
    operator_longitude: Optional[float] = None
    area_count: int = 0
    area_radius: Optional[float] = None
    area_ceiling: Optional[float] = None
    area_floor: Optional[float] = None
    ua_category: int = 0
    ua_class: int = 0
    operator_altitude: Optional[float] = None
    timestamp: Optional[float] = None


@dataclass
class OperatorIdMessage:
    msg_type: str = "Operator ID"
    proto_version: int = 0
    operator_id_type: int = 0
    operator_id: str = ""


@dataclass
class MessagePack:
    msg_type: str = "Message Pack"
    proto_version: int = 0
    single_message_size: int = 0
    message_count: int = 0
    messages: list = field(default_factory=list)


class ODIDDecoder:
    """Stateless decoder for ODID messages.

    All methods are static. The main entry point is decode_message_byte()
    which takes a raw 25-byte ODID message (including the type/version byte).
    """

    @staticmethod
    def parse_type_version(raw_byte: int) -> tuple[int, int]:
        """Extract message type and protocol version from first byte.

        Returns (msg_type, proto_version).
        """
        msg_type = (raw_byte >> 4) & 0x0F
        proto_version = raw_byte & 0x0F
        return msg_type, proto_version

    @staticmethod
    def decode_message_byte(data: bytes):
        """Decode a single ODID message from raw bytes.

        Args:
            data: At least 25 bytes. For standard messages, only the first 25
                  bytes are consumed. For Message Pack (type 0xF), all remaining
                  bytes after the type byte are passed to the pack decoder since
                  packs span multiple 25-byte slots.

        Returns:
            Decoded dataclass or None on error.
        """
        if len(data) < ODID_MSG_SIZE:
            log.debug("Message too short: %d bytes (need %d)", len(data), ODID_MSG_SIZE)
            return None

        msg_type, proto_version = ODIDDecoder.parse_type_version(data[0])

        if msg_type == MessageType.MESSAGE_PACK:
            # Message packs span beyond a single 25-byte slot
            payload = data[1:]
        else:
            payload = data[1:ODID_MSG_SIZE]  # 24 bytes

        return ODIDDecoder.decode_message(msg_type, proto_version, payload)

    @staticmethod
    def decode_message(msg_type: int, proto_version: int, payload: bytes):
        """Decode a message given its already-extracted type, version, and 24-byte payload."""
        decoders = {
            MessageType.BASIC_ID: ODIDDecoder.decode_basic_id,
            MessageType.LOCATION: ODIDDecoder.decode_location,
            MessageType.AUTH: ODIDDecoder.decode_auth,
            MessageType.SELF_ID: ODIDDecoder.decode_self_id,
            MessageType.SYSTEM: ODIDDecoder.decode_system,
            MessageType.OPERATOR_ID: ODIDDecoder.decode_operator_id,
            MessageType.MESSAGE_PACK: ODIDDecoder.decode_message_pack,
        }

        decoder = decoders.get(msg_type)
        if decoder:
            try:
                return decoder(proto_version, payload)
            except Exception:
                log.exception("Failed to decode message type 0x%x", msg_type)
                return None

        log.debug("Unknown message type: 0x%x", msg_type)
        return None

    @staticmethod
    def decode_basic_id(proto_version: int, data: bytes) -> BasicIdMessage:
        """Decode Basic ID message.

        Payload layout (24 bytes):
          Byte 0: [id_type:4 (high nibble)][ua_type:4 (low nibble)]
          Bytes 1-20: UAS ID (20 bytes, null-padded)
          Bytes 21-23: reserved

        The UAS ID field is ASCII for id_type 1 (Serial Number) and 2 (CAA
        Registration). For id_type 3 (UTM-assigned UUID) it holds a 128-bit
        binary UUID in the first 16 bytes, rendered here in canonical UUID
        form. For id_type 4 (Specific Session ID) it is one session-ID-type
        byte followed by binary ID bytes, rendered as hex of all 20 bytes.
        Binary values are not null-stripped, as 0x00 is a valid byte.
        """
        id_type = (data[0] >> 4) & 0x0F
        ua_type = data[0] & 0x0F
        uas_id = ODIDDecoder._render_uas_id(id_type, bytes(data[1:21]))

        return BasicIdMessage(
            proto_version=proto_version,
            id_type=id_type,
            id_type_name=ID_TYPE_NAMES.get(id_type, f"Unknown({id_type})"),
            ua_type=ua_type,
            ua_type_name=UA_TYPE_NAMES.get(ua_type, f"Unknown({ua_type})"),
            uas_id=uas_id,
        )

    @staticmethod
    def _render_uas_id(id_type: int, raw: bytes) -> str:
        """Render the 20-byte UAS ID field according to its ID type."""
        if id_type == IdType.UTM_UUID:
            return str(uuid.UUID(bytes=raw[:16].ljust(16, b"\x00")))
        if id_type == IdType.SPECIFIC_SESSION_ID:
            return raw.hex()
        return _clean_text(raw.rstrip(b"\x00").decode("ascii", errors="replace"))

    @staticmethod
    def _alt(raw: int) -> Optional[float]:
        """Decode an F3411 altitude/height (0.5 m, -1000 m offset); raw 0 = unknown."""
        if raw == ALT_INVALID:
            return None
        return raw * ALT_RESOLUTION + ALT_OFFSET

    @staticmethod
    def _latlon(lat_raw: int, lon_raw: int) -> tuple[Optional[float], Optional[float]]:
        """Decode a lat/lon pair; (0, 0) or out-of-range values mean unknown."""
        if lat_raw == LAT_LON_INVALID and lon_raw == LAT_LON_INVALID:
            return None, None
        # Round to the 1e-7 deg wire resolution to drop float noise
        # (e.g. 41.754421199999996 -> 41.7544212).
        lat = round(lat_raw * LAT_LON_SCALE, 7)
        lon = round(lon_raw * LAT_LON_SCALE, 7)
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
            return None, None
        return lat, lon

    @staticmethod
    def decode_location(proto_version: int, data: bytes) -> LocationMessage:
        """Decode Location/Vector message (opendroneid-core-c ODID_Location_encoded).

        Payload layout (24 bytes, after the type/version byte):
          Byte 0:  bit0 speed_mult, bit1 ew_dir, bit2 height_type, bit3 reserved,
                   bits4-7 status
          Byte 1:  direction (integer degrees 0-179, +180 if ew_dir)
          Byte 2:  horizontal speed raw
          Byte 3:  vertical speed (int8, 0.5 m/s)
          Bytes 4-7:   latitude  (int32 LE, 1e-7 deg)
          Bytes 8-11:  longitude (int32 LE, 1e-7 deg)
          Bytes 12-13: pressure altitude (uint16 LE, 0.5 m, -1000 m offset)
          Bytes 14-15: geodetic altitude (uint16 LE, 0.5 m, -1000 m offset)
          Bytes 16-17: height (uint16 LE, 0.5 m, -1000 m offset)
          Byte 18: [vert_accuracy:4 high][horiz_accuracy:4 low]
          Byte 19: [baro_accuracy:4 high][speed_accuracy:4 low]
          Bytes 20-21: timestamp (uint16 LE, 0.1 s since the hour; 0xFFFF unknown)
          Byte 22: [reserved:4][timestamp_accuracy:4 low] (0.1 s units, 0 unknown)
          Byte 23: reserved
        """
        status = (data[0] >> 4) & 0x0F
        height_type = (data[0] >> 2) & 0x01
        ew_dir = (data[0] >> 1) & 0x01
        speed_mult = data[0] & 0x01

        direction_raw = data[1]
        speed_horiz_raw = data[2]
        speed_vert_raw = struct.unpack_from("<b", data, 3)[0]

        lat_raw = struct.unpack_from("<i", data, 4)[0]
        lon_raw = struct.unpack_from("<i", data, 8)[0]
        alt_press_raw = struct.unpack_from("<H", data, 12)[0]
        alt_geo_raw = struct.unpack_from("<H", data, 14)[0]
        height_raw = struct.unpack_from("<H", data, 16)[0]

        horiz_acc = data[18] & 0x0F
        vert_acc = (data[18] >> 4) & 0x0F
        speed_acc = data[19] & 0x0F
        baro_acc = (data[19] >> 4) & 0x0F

        ts_raw = struct.unpack_from("<H", data, 20)[0]
        ts_acc = data[22] & 0x0F

        latitude, longitude = ODIDDecoder._latlon(lat_raw, lon_raw)

        # Speed: mult=0 -> raw*0.25; mult=1 -> raw*0.75 + 63.75. 255 m/s
        # (mult=1, raw=255) is the "unknown" value.
        if speed_mult:
            if speed_horiz_raw == SPEED_INVALID:
                speed_h = None
            else:
                speed_h = speed_horiz_raw * SPEED_RESOLUTION_HI + 255 * SPEED_RESOLUTION_LO
        else:
            speed_h = speed_horiz_raw * SPEED_RESOLUTION_LO

        if speed_vert_raw == VERT_SPEED_INVALID:
            speed_v = None
        else:
            speed_v = speed_vert_raw * VERT_SPEED_RESOLUTION

        direction = direction_raw * DIRECTION_SCALE + (180.0 if ew_dir else 0.0)
        if direction > 360.0:  # 361 (raw 181 with EW set) is "unknown"
            direction = None
        elif direction == 360.0:
            direction = 0.0

        # Valid range is 0..36000 (tenths of a second since the hour);
        # 0xFFFF is "unknown" and anything else above 36000 is out of spec.
        timestamp = (ts_raw * TIMESTAMP_RESOLUTION
                     if ts_raw != LOCATION_TIMESTAMP_INVALID and ts_raw <= LOCATION_TIMESTAMP_MAX
                     else None)
        ts_accuracy = ts_acc * 0.1 if ts_acc != 0 else None

        return LocationMessage(
            proto_version=proto_version,
            status=status,
            status_name=FLIGHT_STATUS_NAMES.get(status, f"Reserved({status})"),
            height_type=height_type,
            height_type_name="AGL" if height_type == HeightType.AGL else "Above Takeoff",
            ew_direction=ew_dir,
            speed_multiplier=speed_mult,
            direction_deg=direction,
            speed_horizontal=speed_h,
            speed_vertical=speed_v,
            latitude=latitude,
            longitude=longitude,
            altitude_msl=ODIDDecoder._alt(alt_press_raw),
            height_agl=ODIDDecoder._alt(height_raw),
            horiz_accuracy=horiz_acc,
            vert_accuracy=vert_acc,
            baro_accuracy=baro_acc,
            timestamp=timestamp,
            timestamp_accuracy=ts_accuracy,
            altitude_geo=ODIDDecoder._alt(alt_geo_raw),
            speed_accuracy=speed_acc,
        )

    @staticmethod
    def decode_auth(proto_version: int, data: bytes) -> AuthMessage:
        """Decode Authentication message.

        Payload layout (24 bytes):
          Byte 0: [auth_type:4][page_number:4]
          --- Page 0 only: ---
          Byte 1: last_page_index
          Byte 2: length (total auth data bytes across all pages)
          Bytes 3-6: timestamp (uint32 LE, seconds since 2019-01-01 00:00:00)
          Bytes 7-23: auth_data (17 bytes on page 0)
          --- Pages 1+: ---
          Bytes 1-23: auth_data (23 bytes on subsequent pages)
        """
        auth_type = (data[0] >> 4) & 0x0F
        page_number = data[0] & 0x0F

        if page_number == 0:
            last_page_index = data[1]
            length = data[2]
            timestamp = struct.unpack_from("<I", data, 3)[0]
            timestamp = timestamp if timestamp != TIMESTAMP_INVALID else None
            auth_data = data[7:24]
        else:
            last_page_index = 0
            length = 0
            timestamp = None
            auth_data = data[1:24]

        return AuthMessage(
            proto_version=proto_version,
            auth_type=auth_type,
            auth_type_name=AUTH_TYPE_NAMES.get(auth_type, f"Unknown({auth_type})"),
            page_number=page_number,
            last_page_index=last_page_index,
            length=length,
            timestamp=timestamp,
            auth_data=bytes(auth_data),
        )

    @staticmethod
    def decode_self_id(proto_version: int, data: bytes) -> SelfIdMessage:
        """Decode Self-ID message.

        Payload layout (24 bytes):
          Byte 0: description type
          Bytes 1-23: description string (23 chars, null-padded)
        """
        desc_type = data[0]
        description = _clean_text(data[1:24].rstrip(b"\x00").decode("utf-8", errors="replace"))

        return SelfIdMessage(
            proto_version=proto_version,
            desc_type=desc_type,
            desc_type_name=DESC_TYPE_NAMES.get(desc_type, f"Reserved({desc_type})"),
            description=description,
        )

    @staticmethod
    def decode_system(proto_version: int, data: bytes) -> SystemMessage:
        """Decode System message.

        Payload layout (24 bytes):
          Byte 0: bits0-1 operator_loc_type, bits2-4 classification_type, bits5-7 reserved
          Bytes 1-4:   operator latitude  (int32 LE, 1e-7 deg)
          Bytes 5-8:   operator longitude (int32 LE, 1e-7 deg)
          Bytes 9-10:  area count (uint16 LE)
          Byte 11:     area radius (raw * 10m)
          Bytes 12-13: area ceiling (uint16 LE, 0.5m, -1000m offset)
          Bytes 14-15: area floor   (uint16 LE, 0.5m, -1000m offset)
          Byte 16: [ua_category:4 high][ua_class:4 low]
          Bytes 17-18: operator altitude (uint16 LE, 0.5m, -1000m offset)
          Bytes 19-22: timestamp (uint32 LE, seconds since 2019-01-01 00:00:00)
          Byte 23: reserved
        """
        op_loc_type = data[0] & 0x03
        class_type = (data[0] >> 2) & 0x07

        op_lat_raw = struct.unpack_from("<i", data, 1)[0]
        op_lon_raw = struct.unpack_from("<i", data, 5)[0]
        area_count = struct.unpack_from("<H", data, 9)[0]
        area_radius_raw = data[11]
        area_ceiling_raw = struct.unpack_from("<H", data, 12)[0]
        area_floor_raw = struct.unpack_from("<H", data, 14)[0]

        ua_category = (data[16] >> 4) & 0x0F
        ua_class = data[16] & 0x0F

        op_alt_raw = struct.unpack_from("<H", data, 17)[0]
        ts_raw = struct.unpack_from("<I", data, 19)[0]

        op_lat, op_lon = ODIDDecoder._latlon(op_lat_raw, op_lon_raw)
        area_ceiling = ODIDDecoder._alt(area_ceiling_raw)
        area_floor = ODIDDecoder._alt(area_floor_raw)
        area_radius = float(area_radius_raw * AREA_RADIUS_SCALE)
        op_alt = ODIDDecoder._alt(op_alt_raw)
        timestamp = ts_raw if ts_raw != TIMESTAMP_INVALID else None

        return SystemMessage(
            proto_version=proto_version,
            operator_location_type=op_loc_type,
            operator_location_type_name=OPERATOR_LOC_TYPE_NAMES.get(
                op_loc_type, f"Unknown({op_loc_type})"
            ),
            classification_type=class_type,
            operator_latitude=op_lat,
            operator_longitude=op_lon,
            area_count=area_count,
            area_radius=area_radius,
            area_ceiling=area_ceiling,
            area_floor=area_floor,
            ua_category=ua_category,
            ua_class=ua_class,
            operator_altitude=op_alt,
            timestamp=timestamp,
        )

    @staticmethod
    def decode_operator_id(proto_version: int, data: bytes) -> OperatorIdMessage:
        """Decode Operator ID message.

        Payload layout (24 bytes):
          Byte 0: operator_id_type
          Bytes 1-20: operator ID string (20 chars, null-padded)
          Bytes 21-23: reserved
        """
        op_id_type = data[0]
        operator_id = _clean_text(data[1:21].rstrip(b"\x00").decode("ascii", errors="replace"))

        return OperatorIdMessage(
            proto_version=proto_version,
            operator_id_type=op_id_type,
            operator_id=operator_id,
        )

    @staticmethod
    def decode_message_pack(proto_version: int, data: bytes) -> MessagePack:
        """Decode Message Pack (multiple messages in one container).

        Payload layout (24 bytes):
          Byte 0: single message size (should be 25 for standard)
          Byte 1: number of messages in pack
          Bytes 2-23: start of packed message data

        The packed messages continue beyond this single 25-byte slot.
        In WiFi framing, the full message pack spans multiple consecutive
        25-byte message slots within the frame.

        NOTE: The caller (frame.py) passes the FULL remaining payload
        after the message pack header type byte, not just 24 bytes,
        so we can unpack all contained messages.
        """
        if len(data) < 2:
            log.debug("Message pack header truncated (%d bytes)", len(data))
            return None

        single_msg_size = data[0]
        msg_count = data[1]

        if single_msg_size != ODID_MSG_SIZE or not 1 <= msg_count <= ODID_PACK_MAX_MESSAGES:
            log.debug(
                "Rejecting message pack: size=%d count=%d", single_msg_size, msg_count,
            )
            return None

        available = (len(data) - 2) // ODID_MSG_SIZE
        if available < msg_count:
            log.debug("Message pack truncated: count=%d, only %d complete", msg_count, available)

        messages = []
        for i in range(min(msg_count, available)):
            offset = 2 + i * ODID_MSG_SIZE
            msg_bytes = data[offset:offset + ODID_MSG_SIZE]
            if (msg_bytes[0] >> 4) & 0x0F == MessageType.MESSAGE_PACK:
                log.debug("Nested message pack ignored")
                continue
            decoded = ODIDDecoder.decode_message_byte(msg_bytes)
            if decoded:
                messages.append(decoded)

        return MessagePack(
            proto_version=proto_version,
            single_message_size=single_msg_size,
            message_count=msg_count,
            messages=messages,
        )
