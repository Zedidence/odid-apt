"""Web dashboard: aiohttp HTTP/WebSocket server + Leaflet.js live map.

Streams drone state as JSON delta patches over WebSocket to a Leaflet map.
Only changed fields are transmitted per update, which cuts payload 80-95% for
established drones versus broadcasting full state on every frame.

Usage::

    dashboard = WebDashboard(port=8080, observer_lat=51.5, observer_lon=-0.12,
                             tracker=tracker)   # hooks tracker.on_evict
    dashboard.start()                           # raises RuntimeError on bind failure
    tracker.on_update(dashboard.on_update)
    # … run capture …
    dashboard.stop()
"""

import asyncio
import errno
import hmac
import html
import json
import logging
import math
import os
import re
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from typing import Optional
from urllib.parse import urlsplit

log = logging.getLogger(__name__)

try:
    from aiohttp import web as _web
    from aiohttp import WSCloseCode as _WSCloseCode
    _AIOHTTP_AVAILABLE = True
except ImportError:
    _AIOHTTP_AVAILABLE = False

try:
    from odid.capture.manager import SourceStateError
except ImportError:
    SourceStateError = None

try:
    from odid.capture.manager import SOURCE_CATALOG as _MANAGER_SOURCE_IDS
except ImportError:
    _MANAGER_SOURCE_IDS = None

# ---------------------------------------------------------------------------
# Page assets (odid/web/static: HTML, CSS, JS, offline Leaflet 1.9.4)
# ---------------------------------------------------------------------------

from odid.web.assets import STATIC as _STATIC, page as _page  # noqa: E402

_INDEX_HTML = _page("index.html")
_LOGIN_HTML = _page("login.html")


# ---------------------------------------------------------------------------
# Request validation for the source-control API
# ---------------------------------------------------------------------------

_ZMQ_RE = re.compile(r"^tcp://(127\.0\.0\.1|localhost):(\d{1,5})$")
# Same syntax SourceManager enforces (manager._IFACE_RE) for both WiFi
# interfaces and Bluetooth adapters, so the web layer rejects exactly what
# the manager would reject, before any source state changes.
_IFACE_RE = re.compile(r"^[A-Za-z0-9_.-]{1,15}$")
_ADAPTER_RE = _IFACE_RE


def _v_zmq(key: str, value):
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    m = _ZMQ_RE.match(value)
    if not m or not 1 <= int(m.group(2)) <= 65535:
        raise ValueError(f"{key} must look like tcp://127.0.0.1:<port> or tcp://localhost:<port>")
    return value


def _as_int(key: str, value) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{key} must be an integer")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str) and value.strip().lstrip("-").isdigit():
        return int(value.strip())
    raise ValueError(f"{key} must be an integer")


def _v_gain(key: str, value):
    v = _as_int(key, value)
    if not 0 <= v <= 71:
        raise ValueError(f"{key} must be between 0 and 71")
    return v


def _v_channel(key: str, value):
    v = _as_int(key, value)
    if not 1 <= v <= 233:
        raise ValueError(f"{key} must be a valid channel number (1-233)")
    return v


def _v_channel_24(key: str, value):
    v = _as_int(key, value)
    if not 1 <= v <= 14:
        raise ValueError(f"{key} must be a 2.4 GHz channel number (1-14)")
    return v


def _v_bt_channel(key: str, value):
    v = _as_int(key, value)
    if v not in (37, 38, 39):
        raise ValueError(f"{key} must be a BT advertising channel (37, 38 or 39)")
    return v


def _v_bool(key: str, value):
    if not isinstance(value, bool):
        raise ValueError(f"{key} must be true or false")
    return value


def _v_iface(key: str, value):
    if (not isinstance(value, str) or not _IFACE_RE.match(value.strip())
            or value.strip() in (".", "..")):
        raise ValueError(f"{key} must be a network interface name (letters, digits, '_', '.', '-'; max 15)")
    return value.strip()


def _v_adapter(key: str, value):
    if not isinstance(value, str) or not _ADAPTER_RE.match(value.strip()):
        raise ValueError(f"{key} must be an adapter name such as hci0 (letters, digits, '_', '.', '-'; max 15)")
    return value.strip()


# Allowed config keys per source id, with their validators.  Anything else is
# rejected so arbitrary client data is never stored or rebroadcast.
_SOURCE_CONFIG_SCHEMA = {
    "bladerf-dual": {
        "zmq_addr": _v_zmq, "zmq_bt_addr": _v_zmq,
        "wifi_gain": _v_gain, "bt_gain": _v_gain,
    },
    "bladerf-wifi": {"zmq_addr": _v_zmq, "gain": _v_gain, "channel": _v_channel_24, "hop": _v_bool,
                     "monitor": _v_bool},
    "bladerf-bt":   {"zmq_addr": _v_zmq, "gain": _v_gain, "channel": _v_bt_channel,
                     "monitor": _v_bool},
    "wifi-dongle":  {"interface": _v_iface, "channel": _v_channel},
    "builtin-bt":   {"adapter": _v_adapter},
}

_EXPORT_FORMATS = {
    "kml": "application/vnd.google-earth.kml+xml",
    "gpx": "application/gpx+xml",
}

_LOOPBACK_NAMES = {"127.0.0.1", "localhost", "::1"}
# Minimum seconds between re-discoveries of local addresses after a Host miss
# (picks up DHCP / interface changes without letting a flood of bad Hosts
# trigger a subprocess per request).
_ALLOWLIST_REFRESH_S = 30.0
_SHUTDOWN_EXECUTOR_TIMEOUT_S = 2.0

# Per-client outbound queue depth, in queued WebSocket messages.  Each flush
# puts ONE "batch" message on the queue however many drones changed, so this
# bounds how many flushes (~_FLUSH_INTERVAL_S each, plus sources updates) a
# client may lag.  A client that falls this far behind is disconnected (it
# reconnects and gets a fresh snapshot) rather than stalling everyone else or
# growing memory without bound.
_CLIENT_QUEUE_MAX = 256
_FLUSH_INTERVAL_S = 0.2
_START_TIMEOUT_S = 10.0
# Password hashing (scrypt, ~16 MiB each) runs on its own small pool so a
# burst of sign-ins can't starve source control, WebSocket connects and
# health on the default executor.  Sign-ins beyond the in-flight cap get 429.
_AUTH_WORKERS = 2
_MAX_AUTH_INFLIGHT = 4
_auth_executor_obj = None
_auth_executor_lock = threading.Lock()


def _auth_executor():
    global _auth_executor_obj
    with _auth_executor_lock:
        if _auth_executor_obj is None:
            from concurrent.futures import ThreadPoolExecutor
            _auth_executor_obj = ThreadPoolExecutor(max_workers=_AUTH_WORKERS,
                                                    thread_name_prefix="odid-auth")
        return _auth_executor_obj


# ---------------------------------------------------------------------------
# Response security headers
# ---------------------------------------------------------------------------

# Every response: never framed (blocks clickjacking of the source Start/Stop
# buttons), no MIME sniffing, no Referer leaking the dashboard address.
_COMMON_SECURITY_HEADERS = {
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}
# Non-HTML responses (JSON, exports, errors) never need to load anything.
_CSP_DEFAULT = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
# The dashboard page: only its own same-origin scripts (/static/*, no inline
# script), styles (Leaflet + divIcons also use inline styles), OSM tiles, and
# same-origin fetch / WebSocket.
_CSP_INDEX_BASE = "; ".join([
    "default-src 'none'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https://tile.openstreetmap.org",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "form-action 'none'",
    "object-src 'none'",
])
_CSP_LOGIN = "; ".join([
    "default-src 'none'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "connect-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "form-action 'none'",
])
_HEALTH_PUSH_S = 5.0     # seconds between "system" WebSocket messages
# Fields of a flowgraph monitor message forwarded to browsers (sdr_monitor);
# everything else the flowgraph sends is dropped.
_SDR_MONITOR_KEYS = ("center_hz", "sample_rate", "fft_size", "gain_db", "channel", "avg", "max",
                     "peak_dbfs", "mean_dbfs", "noise_dbfs", "clip_pct", "recording")
_SESSION_COOKIE = "odid_session"
_CSRF_HEADER = "X-ODID-CSRF"
# GET routes reachable without a session (the sign-in page)
_PUBLIC_GET = {"/login", "/favicon.ico"}
# /static/<name>: page assets, public (no secrets) so the sign-in page loads
# Non-GET routes any signed-in user may call; every other one needs admin
_VIEWER_WRITE = {"/api/logout", "/api/account/password"}
# GET routes that need the admin role (they show configuration)
_ADMIN_GET = {"/api/settings", "/api/logs", "/api/sessions", "/api/users", "/api/recordings"}
_ADMIN_GET_PREFIXES = ("/api/sessions/", "/api/system/")
# Methods that change state: Origin / Content-Type / CSRF checks apply
_UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
# Index placeholder replaced with the session's CSRF token / identity
_SESSION_META = "<!--ODID_SESSION_META-->"
_CSP_HOST_RE = re.compile(r"^[A-Za-z0-9.\-]+(:\d{1,5})?$|^\[[0-9A-Fa-f:.]+\](:\d{1,5})?$")


def _index_csp(raw_host: str) -> str:
    """Index-page CSP.  connect-src names the WebSocket origin explicitly
    (older Safari does not let 'self' cover ws:/wss:)."""
    connect = ["'self'"]
    host = raw_host.strip()
    if _CSP_HOST_RE.match(host):
        connect += [f"ws://{host}", f"wss://{host}"]
    return _CSP_INDEX_BASE + "; connect-src " + " ".join(connect)


class _HTTPError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _json_response(payload, status: int = 200, headers: Optional[dict] = None):
    return _web.Response(
        content_type="application/json",
        text=json.dumps(payload, default=str),
        status=status,
        headers=headers,
    )


def _host_only(hostport: str) -> str:
    """Strip the port from a Host header value (handles [v6]:port)."""
    hp = (hostport or "").strip().lower()
    if hp.startswith("["):
        return hp[1:hp.find("]")] if "]" in hp else hp
    if hp.count(":") == 1:
        return hp.split(":", 1)[0]
    return hp


def _norm_host(name: str) -> str:
    """Normalise a hostname / IP for allowlist comparison."""
    h = _host_only(name)
    h = h.split("%", 1)[0]          # drop IPv6 zone id
    return h.rstrip(".")


def _local_addresses() -> set[str]:
    """Every IP address configured on this machine (best effort)."""
    addrs: set[str] = set()
    try:
        out = subprocess.run(
            ["ip", "-j", "addr"], capture_output=True, text=True, timeout=2.0,
        )
        if out.returncode == 0 and out.stdout.strip():
            for iface in json.loads(out.stdout):
                for ai in iface.get("addr_info", []) or []:
                    local = ai.get("local")
                    if isinstance(local, str) and local:
                        addrs.add(_norm_host(local))
    except (OSError, ValueError, subprocess.SubprocessError, AttributeError, TypeError):
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None):
            addrs.add(_norm_host(str(info[4][0])))
    except (OSError, UnicodeError):
        pass
    addrs.discard("")
    return addrs


def _local_hostnames() -> set[str]:
    """This machine's hostname, its mDNS name and its FQDN."""
    names: set[str] = set()
    try:
        hn = socket.gethostname()
    except OSError:
        hn = ""
    if hn:
        names.add(_norm_host(hn))
        names.add(_norm_host(hn.split(".", 1)[0] + ".local"))
    try:
        fq = socket.getfqdn()
        if fq:
            names.add(_norm_host(fq))
    except (OSError, UnicodeError):
        pass
    names.discard("")
    return names


def _server_time_ms() -> int:
    """Server wall clock (Unix epoch, ms) sent with drone messages."""
    return int(time.time() * 1000)


def _raw_host(request) -> str:
    """The raw ``Host`` header ('' if absent), never ``request.host``,
    which falls back to a blocking ``socket.getfqdn()``."""
    return request.headers.get("Host") or ""


def _origin_matches_host(origin: str, host: str) -> bool:
    try:
        parts = urlsplit(origin)
    except ValueError:
        return False
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return False
    return parts.netloc.lower() == (host or "").lower()


def _validate_start_body(body) -> tuple[str, dict]:
    if not isinstance(body, dict):
        raise _HTTPError(400, "request body must be a JSON object")
    source_id = body.get("source")
    if not isinstance(source_id, str) or not source_id:
        raise _HTTPError(400, "'source' is required")
    schema = _SOURCE_CONFIG_SCHEMA.get(source_id)
    if schema is None:
        raise _HTTPError(404, f"unknown source: {source_id[:64]}")
    config = {}
    for key, value in body.items():
        if key == "source":
            continue
        validator = schema.get(key)
        if validator is None:
            raise _HTTPError(400, f"unsupported option for {source_id}: {str(key)[:64]}")
        if value is None or (isinstance(value, str) and not value.strip()):
            continue  # treat blank as "use default"
        try:
            config[key] = validator(key, value)
        except ValueError as exc:
            raise _HTTPError(400, str(exc)) from None
    return source_id, config


# ---------------------------------------------------------------------------
# WebDashboard
# ---------------------------------------------------------------------------


class WebDashboard:
    """HTTP + WebSocket server that streams live drone state to a Leaflet map.

    Delta updates: only changed drone fields are transmitted, coalesced into
    one flush every ~200 ms by a single sender task (so order is preserved).
    Location history lives server-side and is available via /history/<mac>.

    Security: binds to 127.0.0.1 by default.  POSTs must be
    ``application/json`` and POST + WebSocket requests carrying an ``Origin``
    must match the ``Host`` header (blocks CSRF and cross-site WebSocket
    hijacking).  Every request's ``Host`` must also name this machine, which
    defeats DNS rebinding: when bound to loopback only loopback names are
    accepted; otherwise the bind IP, loopback names, any local interface IP,
    the hostname / ``hostname.local`` / FQDN and any ``allowed_hosts`` entry.

    Sign-in: with an ``auth`` store that has accounts (odid.web.auth), every
    route except ``/login`` needs a session cookie (HttpOnly, SameSite=Strict,
    Secure over HTTPS); writes also need the session's CSRF token in
    ``X-ODID-CSRF`` and, except sign-out, the admin role. Failed sign-ins are
    rate limited per client IP and user name. Without accounts there is no
    sign-in, so callers (odid.cli._web_security) keep every listener on
    loopback. ``tls=(host, port, ssl_context)`` adds an HTTPS listener.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8080,
        observer_lat: Optional[float] = None,
        observer_lon: Optional[float] = None,
        tracker=None,
        db=None,
        allowed_hosts: Optional[list[str]] = None,
        auth=None,
        tls: Optional[tuple] = None,
        trust_proxy: bool = False,
    ):
        if not _AIOHTTP_AVAILABLE:
            raise ImportError(
                "aiohttp is required for the web dashboard. "
                "Install it with: pip install aiohttp"
            )
        self._host = host
        self._port = port
        self._observer_lat = observer_lat
        self._observer_lon = observer_lon
        # Full latest drone state (for snapshots + export)
        self._drones: dict[str, dict] = {}
        # State as last broadcast to clients (delta baseline)
        self._last_sent: dict[str, dict] = {}
        # Ordered set of pending changes: mac -> "update" | "remove"
        self._dirty: dict[str, str] = {}
        # Location history per drone (mac -> deque of {lat, lon, alt, ts})
        self._history: dict[str, deque] = {}
        # ws -> bounded outbound asyncio.Queue (event-loop thread only)
        self._clients: dict = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._runner = None
        self._flush_task: Optional[asyncio.Task] = None
        self._thread: Optional[threading.Thread] = None
        self._startup_error: Optional[BaseException] = None
        self._stopped = False
        # Lock protecting _drones, _history, _last_sent, _dirty
        self._lock: threading.Lock = threading.Lock()
        # Signalled once the HTTP server is accepting connections (or failed)
        self._ready_event: threading.Event = threading.Event()
        # Optional SourceManager, only set when launched via `odid serve`
        self._source_manager = None
        # Optional odid.web.settings.SettingsService (`odid serve`)
        self._settings = None
        # Optional odid.web.system.SystemHealth; pushed as "system" messages
        self._health = None
        self._health_task: Optional[asyncio.Task] = None
        # Optional odid.web.actions.SystemActions (restart / reboot / update)
        self._actions = None
        # Optional odid.web.logs.LogSource and the data dir (captures)
        self._logs = None
        self._data_dir: Optional[str] = None
        # Set by begin_shutdown(): source-control POSTs are refused (503)
        self._shutting_down = False
        # Optional DroneDB: full per-drone tracks for export (positions_for)
        self._db = db
        # Host allowlist (non-loopback binds).  _allowed_static never changes;
        # _allowed_local is re-discovered lazily on a miss.
        self._extra_hosts = {
            _norm_host(h) for h in (allowed_hosts or []) if isinstance(h, str) and h.strip()
        }
        self._allowed_local: set[str] = set()
        self._allowed_refreshed_at: float = float("-inf")
        self._allowed_refresh_lock: Optional[asyncio.Lock] = None
        # sources_update ordering: get_status reads are serialised and stamped
        # with a monotonically increasing version; one coalescing task sends.
        self._sources_version = 0
        self._sources_lock: Optional[asyncio.Lock] = None
        self._sources_dirty = False
        self._sources_task: Optional[asyncio.Task] = None
        # Strong references to fire-and-forget tasks (see _spawn)
        self._bg_tasks: set = set()
        # Accounts (odid.web.auth.AuthStore). Sign-in is required whenever it
        # has users; with none, callers must keep every bind on loopback.
        self._auth = auth
        # Fixed in start(): once sign-in is required it stays required, even
        # if the accounts file later loses its last user (no fail-open).
        self._auth_required = False
        self._auth_inflight = 0      # password checks queued or running
        from odid.web.auth import LoginLimiter
        self._limiter = LoginLimiter()
        # ws -> session token, to close sockets whose session ended
        self._ws_tokens: dict = {}
        # Optional HTTPS listener: (host, port, ssl.SSLContext)
        self._tls = tls
        # Honour X-Forwarded-For/-Proto from loopback peers (a local HTTPS
        # reverse proxy such as "tailscale serve"); off by default, since any
        # local process could otherwise pick its rate-limit key.
        self._trust_proxy = trust_proxy
        if tracker is not None:
            self.attach_tracker(tracker)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def host(self) -> str:
        return self._host

    @property
    def port(self) -> int:
        """Bound port (resolved after start() when constructed with port=0)."""
        return self._port

    def attach_tracker(self, tracker) -> None:
        """Register for tracker eviction so evicted drones leave the map.

        Only hooks ``on_evict`` (if the tracker supports it); callers still
        register ``tracker.on_update(dashboard.on_update)`` themselves.
        """
        if hasattr(tracker, "on_evict"):
            tracker.on_evict(self.remove_drone)

    def set_source_manager(self, manager) -> None:
        """Attach a SourceManager so the web UI can control capture sources."""
        self._source_manager = manager

    def set_settings(self, service) -> None:
        """Attach a SettingsService for GET/PUT /api/settings."""
        self._settings = service

    def set_files(self, logs, data_dir: str) -> None:
        """Attach a LogSource (GET /api/logs) and the data directory whose
        capture sessions /api/sessions lists, serves and deletes."""
        self._logs = logs
        self._data_dir = data_dir

    def set_actions(self, actions) -> None:
        """Attach SystemActions for POST /api/system/{restart,reboot,update}."""
        self._actions = actions

    def set_health(self, health) -> None:
        """Attach a SystemHealth for GET /api/system and the WS push."""
        self._health = health

    def set_observer(self, lat: Optional[float], lon: Optional[float]) -> None:
        """Move the observer marker (thread-safe); browsers update at once."""
        self._observer_lat, self._observer_lon = lat, lon
        if not self._loop_usable():
            return
        try:
            self._loop.call_soon_threadsafe(self._broadcast_nowait, {
                "type": "observer", "observer_lat": lat, "observer_lon": lon})
        except RuntimeError:
            pass  # loop closed between the check and the call

    @property
    def shutting_down(self) -> bool:
        return self._shutting_down

    def begin_shutdown(self) -> None:
        """Stop accepting source-control requests (POST /api/sources/* → 503).

        Call before tearing capture sources down so a browser can't start a
        source that the shutdown has already passed.  Idempotent; ``stop()``
        implies it.
        """
        self._shutting_down = True

    def _loop_usable(self) -> bool:
        loop = self._loop
        return (
            not self._stopped
            and loop is not None
            and loop.is_running()
            and not loop.is_closed()
        )

    def notify_sdr_monitor(self, source_id: str, msg: dict) -> None:
        """Thread-safe: push an SDR flowgraph's spectrum/level message
        (SourceManager on_monitor) to every browser as ``sdr_monitor``."""
        if not self._loop_usable():
            return
        out = {k: msg.get(k) for k in _SDR_MONITOR_KEYS}
        out.update(type="sdr_monitor", source=source_id)
        try:
            self._loop.call_soon_threadsafe(self._broadcast_nowait, out)
        except RuntimeError:
            pass  # loop closed between the check and the call

    def notify_sources_changed(self) -> None:
        """Thread-safe callback invoked by SourceManager on any state change."""
        if not self._loop_usable():
            return
        try:
            self._loop.call_soon_threadsafe(self._schedule_sources_broadcast)
        except RuntimeError:
            pass  # loop closed between the check and the call

    def start(self) -> None:
        """Start the HTTP/WebSocket server in a background daemon thread.

        Raises RuntimeError if the server cannot start (e.g. port in use).
        """
        self._startup_error = None
        self._ready_event.clear()
        self._stopped = False
        self._shutting_down = False
        # asyncio primitives bind to a loop; each start() gets a new loop
        self._sources_lock = None
        self._allowed_refresh_lock = None
        self._allowed_refreshed_at = float("-inf")
        # A network listener, or a local proxy (tailscale serve) in front of
        # a loopback one, always needs sign-in; so does any store with users.
        self._auth_required = self._auth is not None and (
            not self._bind_is_loopback() or self._trust_proxy or self._auth.has_users())
        self._bg_tasks = set()
        self._sources_task = None
        self._sources_dirty = False

        def _thread_fn():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            try:
                try:
                    loop.run_until_complete(self._start_server())
                except BaseException as exc:  # noqa: BLE001 - surfaced via start()
                    self._startup_error = exc
                    if self._runner is not None:
                        try:
                            loop.run_until_complete(self._runner.cleanup())
                        except Exception:
                            pass
                    return
                finally:
                    self._ready_event.set()
                loop.run_forever()
            finally:
                self._close_loop(loop)

        self._thread = threading.Thread(target=_thread_fn, daemon=True, name="odid-webdash")
        self._thread.start()
        if not self._ready_event.wait(timeout=_START_TIMEOUT_S):
            self.stop()
            raise RuntimeError(
                f"Web dashboard did not start on {self._host}:{self._port} "
                f"within {_START_TIMEOUT_S:.0f}s"
            )
        if self._startup_error is not None:
            exc = self._startup_error
            self._thread.join(timeout=2.0)
            self._stopped = True
            if isinstance(exc, OSError) and exc.errno == errno.EADDRINUSE:
                msg = (f"Web dashboard port {self._port} on {self._host} is already in use. "
                       f"Stop the other process or choose a different port")
            else:
                msg = f"Web dashboard failed to start on {self._host}:{self._port}: {exc}"
            raise RuntimeError(msg) from exc
        log.info("Web dashboard: http://%s:%d", self._host, self._port)
        if self._tls is not None:
            log.info("Web dashboard: https://%s:%d", self._tls[0], self._tls[1])
        if not self._bind_is_loopback() and not self._login_required():
            log.warning(
                "Web dashboard is bound to non-loopback address %s and is "
                "UNAUTHENTICATED: anyone who can reach port %d can view it%s",
                self._host, self._port,
                " and start/stop capture sources" if self._source_manager is not None else "",
            )

    def is_responsive(self, timeout: float = 5.0) -> bool:
        """True if the dashboard's event loop runs a no-op within ``timeout``."""
        loop = self._loop
        if loop is None or loop.is_closed() or not loop.is_running():
            return False
        try:
            asyncio.run_coroutine_threadsafe(asyncio.sleep(0), loop).result(timeout=timeout)
            return True
        except Exception:
            return False

    def stop(self) -> None:
        """Close all clients, shut the server down and join the loop thread."""
        self.begin_shutdown()
        if self._stopped and (self._thread is None or not self._thread.is_alive()):
            return
        self._stopped = True
        loop = self._loop
        if loop is not None and not loop.is_closed() and loop.is_running():
            if self._runner is not None:
                try:
                    fut = asyncio.run_coroutine_threadsafe(self._runner.cleanup(), loop)
                    fut.result(timeout=5)
                except Exception as exc:
                    log.debug("Web dashboard cleanup error: %r", exc)
            try:
                loop.call_soon_threadsafe(loop.stop)
            except RuntimeError:
                pass  # already closed
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=5)

    @staticmethod
    def _close_loop(loop: asyncio.AbstractEventLoop) -> None:
        try:
            pending = [t for t in asyncio.all_tasks(loop) if not t.done()]
            for t in pending:
                t.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            loop.run_until_complete(loop.shutdown_asyncgens())
        except Exception as exc:
            log.debug("Web dashboard loop teardown error: %r", exc)
        try:
            # Join the default executor (start/stop_source, get_status, export)
            # so no worker outlives the loop, bounded so a wedged blocking
            # call can't hang shutdown.
            if sys.version_info >= (3, 12):
                loop.run_until_complete(
                    loop.shutdown_default_executor(timeout=_SHUTDOWN_EXECUTOR_TIMEOUT_S)
                )
            else:  # pragma: no cover - no timeout parameter before 3.12
                loop.run_until_complete(asyncio.wait_for(
                    loop.shutdown_default_executor(), _SHUTDOWN_EXECUTOR_TIMEOUT_S
                ))
        except Exception as exc:
            log.debug("Web dashboard loop teardown error: %r", exc)
        finally:
            loop.close()

    def on_update(self, drone, frame) -> None:
        """Callback for DroneTracker.on_update().  Thread-safe, non-blocking.

        Only records state and marks the MAC dirty; the single flush task
        computes deltas and broadcasts them in order.
        """
        if self._stopped:
            return
        try:
            full = drone.to_dict()
        except Exception as exc:  # e.g. concurrent mutation in the tracker
            log.debug("drone.to_dict() failed: %r", exc)
            return
        mac = drone.mac
        loc = drone.location

        with self._lock:
            if loc is not None and loc.latitude is not None:
                point = {
                    "ts": full.get("last_seen", ""),
                    "lat": loc.latitude,
                    "lon": loc.longitude,
                    "alt": loc.altitude_msl,
                    "alt_geo": getattr(loc, "altitude_geo", None),
                    "height_agl": getattr(loc, "height_agl", None),
                }
                hist = self._history.get(mac)
                if hist is None:
                    hist = self._history[mac] = deque(maxlen=1000)
                # Non-Location frames (Basic ID, System, ...) re-report the
                # same fix; only record a point when the position changed.
                last = hist[-1] if hist else None
                if last is None or any(
                    last.get(k) != point[k]
                    for k in ("lat", "lon", "alt", "alt_geo", "height_agl")
                ):
                    hist.append(point)
            self._drones[mac] = full
            if self._dirty.get(mac) == "remove":
                # Evicted and re-seen inside one flush window: the client
                # must still drop the old marker/track before the fresh
                # full update, or the new track is joined to the old one.
                self._dirty.pop(mac)
                self._dirty[mac] = "reset"
            self._dirty.setdefault(mac, "update")

    def remove_drone(self, mac: str) -> None:
        """Drop all server state for *mac* and tell clients to remove it.

        Suitable as a ``DroneTracker.on_evict`` callback.  Thread-safe.
        """
        with self._lock:
            had_state = self._drones.pop(mac, None) is not None
            had_hist = self._history.pop(mac, None) is not None
            was_sent = self._last_sent.pop(mac, None) is not None
            known = had_state or had_hist or was_sent or mac in self._dirty
            self._dirty.pop(mac, None)
            if known:
                self._dirty[mac] = "remove"

    # ------------------------------------------------------------------
    # Update coalescing + fan-out (event-loop thread)
    # ------------------------------------------------------------------

    def _collect_pending(self) -> list[dict]:
        """Turn the dirty set into ordered messages (call on the loop)."""
        with self._lock:
            if not self._dirty:
                return []
            dirty, self._dirty = self._dirty, {}
            msgs = []
            now_ms = _server_time_ms()
            for mac, kind in dirty.items():
                if kind == "remove":
                    msgs.append({"type": "remove", "mac": mac})
                    continue
                if kind == "reset":
                    # remove_drone already cleared _last_sent → full update
                    msgs.append({"type": "remove", "mac": mac})
                full = self._drones.get(mac)
                if full is None:
                    continue
                prev = self._last_sent.get(mac)
                if prev is None:
                    msg = {"type": "update", "full": True, "drone": full}
                else:
                    delta = {k: v for k, v in full.items() if prev.get(k) != v}
                    if not delta:
                        continue
                    delta["mac"] = mac
                    msg = {"type": "update", "drone": delta}
                msg["observer_lat"] = self._observer_lat
                msg["observer_lon"] = self._observer_lon
                # Lets the browser compute ages from last_seen without
                # trusting its own clock.
                msg["server_time"] = now_ms
                self._last_sent[mac] = full
                msgs.append(msg)
            return msgs

    async def _flush_loop(self) -> None:
        ticks = 0
        while True:
            await asyncio.sleep(_FLUSH_INTERVAL_S)
            ticks += 1
            if ticks % 150 == 0:          # ~30 s
                try:
                    self._sweep_ws_sessions()
                except Exception:
                    log.exception("WebSocket session sweep failed")
            try:
                msgs = self._collect_pending()
                if msgs:
                    # One queue entry per flush however many drones changed,
                    # so a big swarm can't overflow a healthy client's queue.
                    self._broadcast_nowait({
                        "type": "batch",
                        "server_time": _server_time_ms(),
                        "msgs": msgs,
                    })
            except Exception:
                log.exception("Web dashboard flush failed")

    def _broadcast_nowait(self, msg: dict) -> None:
        """Queue *msg* for every client; disconnect clients that can't keep up."""
        if not self._clients:
            return
        text = json.dumps(msg, default=str)
        for ws, q in list(self._clients.items()):
            try:
                q.put_nowait(text)
            except asyncio.QueueFull:
                log.warning("Web client too slow, disconnecting")
                self._drop_client(ws)

    def _drop_client(self, ws) -> None:
        if self._clients.pop(ws, None) is not None:
            self._spawn(self._close_ws(ws, _WSCloseCode.TRY_AGAIN_LATER, b"too slow"))

    def _spawn(self, coro) -> "asyncio.Task":
        """Fire-and-forget task that is kept referenced until it finishes
        (the loop only holds weak references to tasks)."""
        task = asyncio.ensure_future(coro)
        self._bg_tasks.add(task)
        task.add_done_callback(self._bg_tasks.discard)
        return task

    @staticmethod
    async def _close_ws(ws, code, message: bytes) -> None:
        try:
            await asyncio.wait_for(ws.close(code=code, message=message), timeout=2.0)
        except Exception:
            pass

    async def _client_sender(self, ws, q: "asyncio.Queue") -> None:
        try:
            while True:
                text = await q.get()
                await asyncio.wait_for(ws.send_str(text), timeout=10.0)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.debug("WebSocket send failed: %r", exc)
            self._drop_client(ws)

    async def _broadcast(self, msg: dict) -> None:
        self._broadcast_nowait(msg)

    async def _get_sources_status(self) -> tuple[list, int]:
        """SourceManager.get_status() off the loop; it takes a lock that may
        be held while a flowgraph is being killed.

        Reads are serialised and each result is stamped with a strictly
        increasing version, so a newer version always reflects a later read.
        Returns ``(sources, version)``.
        """
        manager = self._source_manager
        if manager is None:
            return [], self._sources_version
        if self._sources_lock is None:
            self._sources_lock = asyncio.Lock()
        async with self._sources_lock:
            loop = asyncio.get_running_loop()
            sources = await loop.run_in_executor(None, manager.get_status)
            self._sources_version += 1
            return sources, self._sources_version

    def _schedule_sources_broadcast(self) -> None:
        """Mark sources dirty and make sure the single sender is running
        (event-loop thread only).  Bursts of changes coalesce."""
        if self._source_manager is None or self._stopped:
            return
        self._sources_dirty = True
        if self._sources_task is None or self._sources_task.done():
            self._sources_task = asyncio.ensure_future(self._sources_sender())

    async def _sources_sender(self) -> None:
        while self._sources_dirty and not self._stopped:
            self._sources_dirty = False
            try:
                sources, version = await self._get_sources_status()
            except Exception:
                log.exception("SourceManager.get_status() failed")
                continue
            self._broadcast_nowait(
                {"type": "sources_update", "sources": sources, "version": version}
            )

    # ------------------------------------------------------------------
    # aiohttp middleware + handlers
    # ------------------------------------------------------------------

    def _bind_is_loopback(self) -> bool:
        hosts = [self._host] + ([self._tls[0]] if self._tls else [])
        return all(_norm_host(h) in _LOOPBACK_NAMES for h in hosts)

    @property
    def tls_port(self) -> Optional[int]:
        return self._tls[1] if self._tls else None

    def _login_required(self) -> bool:
        return self._auth_required or (self._auth is not None and self._auth.has_users())

    async def _run_auth(self, fn, *args):
        """Run a password-hashing call on the dedicated auth pool."""
        self._auth_inflight += 1
        try:
            return await asyncio.get_running_loop().run_in_executor(_auth_executor(), fn, *args)
        finally:
            self._auth_inflight -= 1

    def _auth_busy_response(self):
        if self._auth_inflight < _MAX_AUTH_INFLIGHT:
            return None
        return _json_response({"error": "Too many sign-ins at once. Try again in a moment"},
                              status=429, headers={"Retry-After": "1"})

    def _no_accounts_left(self) -> bool:
        """Sign-in is required but the accounts file has no users any more."""
        return self._auth_required and not self._auth.has_users()

    def _refresh_allowed_hosts(self) -> None:
        """Re-discover local interface IPs and hostnames (blocking)."""
        found = _local_addresses() | _local_hostnames()
        self._allowed_local = found
        self._allowed_refreshed_at = time.monotonic()

    def _host_allowed(self, request) -> bool:
        """Is the request's Host one of this machine's names?

        Blocks DNS-rebinding pages (Host: evil.example) from talking to the
        dashboard.  Loopback binds accept only loopback names; other binds
        accept the bind IP, loopback names, local IPs/hostnames and any
        configured ``allowed_hosts``.

        Reads the raw ``Host`` header: ``request.host`` falls back to a
        blocking ``socket.getfqdn()`` when the header is missing.
        """
        host = _norm_host(_raw_host(request))
        if not host:
            return False
        if host in _LOOPBACK_NAMES or host in self._extra_hosts:
            return True
        if self._bind_is_loopback():
            return False
        if self._tls and host == _norm_host(self._tls[0]):
            return True
        return host == _norm_host(self._host) or host in self._allowed_local

    async def _check_host(self, request) -> bool:
        if self._host_allowed(request):
            return True
        if self._bind_is_loopback() or not _raw_host(request).strip():
            return False
        # Miss on a non-loopback bind: addresses may have changed (DHCP).
        # Re-discover at most every _ALLOWLIST_REFRESH_S seconds.
        if self._allowed_refresh_lock is None:
            self._allowed_refresh_lock = asyncio.Lock()
        async with self._allowed_refresh_lock:
            if time.monotonic() - self._allowed_refreshed_at >= _ALLOWLIST_REFRESH_S:
                loop = asyncio.get_running_loop()
                try:
                    await loop.run_in_executor(None, self._refresh_allowed_hosts)
                except Exception as exc:
                    log.debug("Host allowlist refresh failed: %r", exc)
                    self._allowed_refreshed_at = time.monotonic()
        return self._host_allowed(request)

    async def _security_middleware(self, request, handler):
        # Never touch request.host here: without a Host header it calls the
        # blocking socket.getfqdn() on the event loop.
        raw_host = _raw_host(request)
        if not raw_host.strip():
            log.warning("Web dashboard: rejected request with no Host header")
            return _json_response({"error": "missing Host header"}, status=400)
        if not await self._check_host(request):
            log.warning("Web dashboard: rejected request with Host %r", raw_host[:128])
            return _json_response({"error": "forbidden host"}, status=403)
        is_ws = request.path == "/ws"
        unsafe = request.method in _UNSAFE_METHODS
        if unsafe or is_ws:
            origin = request.headers.get("Origin")
            # Missing Origin = non-browser client (curl, scripts): allowed;
            # with accounts they still need a session (and CSRF token) below.
            if origin is not None and not _origin_matches_host(origin, raw_host):
                return _json_response({"error": "cross-origin request rejected"}, status=403)
        if unsafe and request.content_type != "application/json":
            return _json_response(
                {"error": "Content-Type must be application/json"}, status=415
            )
        if self._login_required():
            if self._no_accounts_left():
                return _json_response(
                    {"error": "no accounts configured; create one with: sudo odid passwd <name>"},
                    status=503)
            denied = self._authorize(request)
            if denied is not None:
                return denied
        return await handler(request)

    def _authorize(self, request):
        """Session / role / CSRF check; None if the request may proceed."""
        path, method = request.path, request.method
        if method == "POST" and path == "/api/login":
            return None
        if method in ("GET", "HEAD") and (path in _PUBLIC_GET or path.startswith("/static/")):
            return None
        sess = self._auth.get_session(request.cookies.get(_SESSION_COOKIE))
        if sess is None:
            if method in ("GET", "HEAD") and path == "/":
                raise _web.HTTPFound("/login")
            return _json_response({"error": "sign-in required"}, status=401)
        request["odid_session"] = sess
        if (method in ("GET", "HEAD") and sess.role != "admin"
                and (path in _ADMIN_GET or path.startswith(_ADMIN_GET_PREFIXES))):
            return _json_response({"error": "admin role required"}, status=403)
        if method not in ("GET", "HEAD"):
            if path not in _VIEWER_WRITE and sess.role != "admin":
                return _json_response({"error": "admin role required"}, status=403)
            token = request.headers.get(_CSRF_HEADER, "")
            if not hmac.compare_digest(token.encode(), sess.csrf.encode()):
                return _json_response({"error": "missing or invalid CSRF token"}, status=403)
        return None

    @staticmethod
    async def _add_security_headers(request, response) -> None:
        """on_response_prepare hook: runs for every response, including
        middleware rejections, HTTPExceptions and the WebSocket handshake."""
        for k, v in _COMMON_SECURITY_HEADERS.items():
            response.headers.setdefault(k, v)
        if "Content-Security-Policy" not in response.headers:
            if request.path == "/" and response.content_type == "text/html":
                response.headers["Content-Security-Policy"] = _index_csp(_raw_host(request))
            elif request.path == "/login" and response.content_type == "text/html":
                response.headers["Content-Security-Policy"] = _CSP_LOGIN
            else:
                response.headers["Content-Security-Policy"] = _CSP_DEFAULT

    async def _on_shutdown(self, app) -> None:
        """Close every WebSocket so runner.cleanup() doesn't wait for them."""
        if self._flush_task is not None:
            self._flush_task.cancel()
        if self._health_task is not None:
            self._health_task.cancel()
        clients = list(self._clients)
        self._clients.clear()
        if clients:
            await asyncio.gather(
                *(self._close_ws(ws, _WSCloseCode.GOING_AWAY, b"server shutdown") for ws in clients),
                return_exceptions=True,
            )

    async def _handle_index(self, request):
        sess = request.get("odid_session")
        meta = ""
        if sess is not None:
            meta = (f'<meta name="odid-csrf" content="{html.escape(sess.csrf)}">'
                    f'<meta name="odid-user" content="{html.escape(sess.user)}">'
                    f'<meta name="odid-role" content="{html.escape(sess.role)}">')
        return _web.Response(content_type="text/html",
                             text=_INDEX_HTML.replace(_SESSION_META, meta, 1),
                             headers={"Cache-Control": "no-store"})

    async def _handle_static(self, request):
        asset = _STATIC.get(request.match_info.get("name", ""))
        if asset is None:
            return _json_response({"error": "not found"}, status=404)
        body, ctype = asset
        return _web.Response(body=body, content_type=ctype,
                             headers={"Cache-Control": "no-cache"})

    async def _handle_favicon(self, request):
        return _web.Response(status=204, headers={"Cache-Control": "max-age=86400"})

    async def _handle_login_page(self, request):
        if not self._login_required():
            raise _web.HTTPFound("/")
        if self._auth.get_session(request.cookies.get(_SESSION_COOKIE)) is not None:
            raise _web.HTTPFound("/")
        return _web.Response(content_type="text/html", text=_LOGIN_HTML,
                             headers={"Cache-Control": "no-store"})

    def _client_ip(self, request) -> str:
        """Peer address; behind a local reverse proxy (tailscale serve) the
        address the proxy appended to X-Forwarded-For."""
        peer = request.remote or ""
        fwd = request.headers.get("X-Forwarded-For") if self._trust_proxy else None
        if fwd and _norm_host(peer) in _LOOPBACK_NAMES:
            last = fwd.split(",")[-1].strip()
            if last:
                return last[:64]
        return peer

    def _who(self, request) -> str:
        """``user from ip`` for AUDIT lines."""
        sess = request.get("odid_session")
        return f"{sess.user if sess else '(no sign-in)'} from {self._client_ip(request)}"

    def _cookie_secure(self, request) -> bool:
        if request.secure:
            return True
        if not self._trust_proxy:
            return False
        # Plain HTTP from a loopback reverse proxy that terminated HTTPS
        peer_local = _norm_host(request.remote or "") in _LOOPBACK_NAMES
        proto = request.headers.get("X-Forwarded-Proto", "").lower()
        return peer_local and (proto == "https" or
                               _norm_host(_raw_host(request)) not in _LOOPBACK_NAMES)

    async def _handle_login(self, request):
        if not self._login_required():
            return _json_response({"error": "sign-in is not enabled"}, status=404)
        try:
            body = await self._read_json(request)
        except _HTTPError as exc:
            return _json_response({"error": exc.message}, status=exc.status)
        user = body.get("user") if isinstance(body, dict) else None
        password = body.get("password") if isinstance(body, dict) else None
        remember = bool(body.get("remember")) if isinstance(body, dict) else False
        ip = self._client_ip(request)
        keys = ["ip:" + ip] + (["user:" + user[:64]] if isinstance(user, str) else [])
        busy = self._auth_busy_response()
        if busy is not None:
            return busy
        # Counted as a failure up front; success() below clears it
        wait = self._limiter.attempt(*keys)
        if wait > 0:
            return _json_response(
                {"error": f"Too many failed sign-ins. Try again in {math.ceil(wait)} s"},
                status=429, headers={"Retry-After": str(math.ceil(wait))})
        loop = asyncio.get_running_loop()
        role = await self._run_auth(self._auth.authenticate, user, password)
        if role is None:
            log.warning("AUDIT sign-in failed for %r from %s", str(user)[:64], ip)
            return _json_response({"error": "Wrong user name or password"}, status=401)
        self._limiter.success(*keys)
        token, sess = await loop.run_in_executor(None, self._auth.create_session, user, remember)
        log.info("AUDIT sign-in: %s (%s) from %s", sess.user, sess.role, ip)
        resp = _json_response({"ok": True, "user": sess.user, "role": sess.role})
        resp.set_cookie(_SESSION_COOKIE, token, httponly=True, samesite="Strict", path="/",
                        secure=self._cookie_secure(request),
                        max_age=(30 * 24 * 3600) if remember else None)
        return resp

    async def _handle_logout(self, request):
        sess = request.get("odid_session")
        token = request.cookies.get(_SESSION_COOKIE)
        if self._auth is not None and token:
            await asyncio.get_running_loop().run_in_executor(None, self._auth.revoke, token)
            for ws, t in list(self._ws_tokens.items()):
                if t == token:
                    self._spawn(self._close_ws(ws, _WSCloseCode.POLICY_VIOLATION, b"signed out"))
        if sess is not None:
            log.info("AUDIT sign-out: %s from %s", sess.user, self._client_ip(request))
        resp = _json_response({"ok": True})
        resp.del_cookie(_SESSION_COOKIE, path="/")
        return resp

    async def _handle_session(self, request):
        sess = request.get("odid_session")
        if sess is None:
            return _json_response({"auth": False})
        return _json_response({"auth": True, "user": sess.user, "role": sess.role,
                               "csrf": sess.csrf})

    def _sweep_ws_sessions(self) -> None:
        """Close WebSockets whose session expired or was revoked."""
        if self._auth is None or not self._ws_tokens:
            return
        for ws, token in list(self._ws_tokens.items()):
            if self._auth.get_session(token) is None:
                self._ws_tokens.pop(ws, None)
                self._spawn(self._close_ws(ws, _WSCloseCode.POLICY_VIOLATION, b"session ended"))

    async def _handle_ws(self, request):
        ws = _web.WebSocketResponse(heartbeat=30.0, timeout=2.0)
        await ws.prepare(request)
        if self._stopped or self._shutting_down:
            await ws.close(code=_WSCloseCode.GOING_AWAY)
            return ws
        try:
            sources_snapshot, sources_version = await self._get_sources_status()
        except Exception:
            log.exception("SourceManager.get_status() failed")
            sources_snapshot, sources_version = [], self._sources_version
        if self._stopped or self._shutting_down:
            # _on_shutdown may have closed every client during the await
            # above; don't register a socket nothing would ever close.
            await ws.close(code=_WSCloseCode.GOING_AWAY, message=b"server shutdown")
            return ws
        q: asyncio.Queue = asyncio.Queue(maxsize=_CLIENT_QUEUE_MAX)
        # Snapshot + registration happen with no await in between, so this
        # client sees exactly the updates flushed after its snapshot.
        with self._lock:
            drones_snapshot = list(self._drones.values())
        q.put_nowait(json.dumps({
            "type": "snapshot",
            "drones": drones_snapshot,
            "server_time": _server_time_ms(),
            "observer_lat": self._observer_lat,
            "observer_lon": self._observer_lon,
            "sources": sources_snapshot,
            "sources_version": sources_version,
            # False outside `odid serve`: the UI hides the sources panel
            "source_control": self._source_manager is not None,
        }, default=str))
        self._clients[ws] = q
        if request.get("odid_session") is not None:
            self._ws_tokens[ws] = request.cookies.get(_SESSION_COOKIE)
        sender = asyncio.ensure_future(self._client_sender(ws, q))
        log.debug("WebSocket client connected (%d total)", len(self._clients))
        try:
            async for _msg in ws:
                pass
        finally:
            self._clients.pop(ws, None)
            self._ws_tokens.pop(ws, None)
            sender.cancel()
            try:
                await sender
            except (asyncio.CancelledError, Exception):
                pass
            log.debug("WebSocket client disconnected (%d total)", len(self._clients))
        return ws

    async def _handle_history(self, request):
        """Return location history for a given MAC as JSON."""
        mac = request.match_info.get("mac", "")
        with self._lock:
            history = list(self._history.get(mac, []))
        return _json_response(history)

    def _build_export(self, fmt: str) -> bytes:
        """Build a KML/GPX export (blocking; run in an executor)."""
        import tempfile
        from pathlib import Path

        with self._lock:
            drones_copy = dict(self._drones)
            history_copy = {k: list(v) for k, v in self._history.items()}

        drones = [
            self._rebuild_drone_state(mac, d, history_copy.get(mac, []))
            for mac, d in drones_copy.items()
        ]

        with tempfile.TemporaryDirectory() as tmp:
            out_path = Path(tmp) / f"export.{fmt}"
            if fmt == "kml":
                from odid.output.export import export_kml
                export_kml(drones, out_path)
            else:
                from odid.output.export import export_gpx
                export_gpx(drones, out_path)
            return out_path.read_bytes()

    def _db_positions(self, mac: str) -> Optional[list]:
        """Full stored track for *mac* from the attached DB, or None."""
        db = self._db
        if db is None or not hasattr(db, "positions_for"):
            return None
        try:
            rows = db.positions_for(mac)
        except Exception as exc:
            log.warning("DB positions_for(%s) failed, using in-memory track: %r", mac, exc)
            return None
        return list(rows) if rows else None

    def _rebuild_drone_state(self, mac: str, d: dict, history: list):
        """Turn a cached ``DroneState.to_dict()`` back into a DroneState that
        the KML/GPX exporters can consume (blocking: may query the DB)."""
        import dataclasses
        from datetime import datetime
        from odid.track.tracker import DroneState
        from odid.decode.messages import BasicIdMessage, LocationMessage
        try:
            from odid.decode.constants import ID_TYPE_NAMES, UA_TYPE_NAMES
        except ImportError:  # pragma: no cover
            ID_TYPE_NAMES, UA_TYPE_NAMES = {}, {}

        loc_fields = {f.name for f in dataclasses.fields(LocationMessage)}

        def _loc(**kw):
            return LocationMessage(**{k: v for k, v in kw.items() if k in loc_fields})

        def _ts(value):
            if isinstance(value, datetime):
                return value
            try:
                return datetime.fromisoformat(value) if value else None
            except (TypeError, ValueError):
                return None

        def _code(names: dict, name) -> int:
            for code, n in names.items():
                if n == name:
                    return code
            return 0

        ds = DroneState(mac=mac)
        ds.frame_count = d.get("frame_count", 0) or 0
        first, last = _ts(d.get("first_seen")), _ts(d.get("last_seen"))
        if last is not None:
            ds.last_seen = last
        if first is not None:
            ds.first_seen = first
        elif last is not None:
            ds.first_seen = last

        bid_d = d.get("basic_id")
        if isinstance(bid_d, dict) and (bid_d.get("uas_id") or bid_d.get("id_type")):
            id_type_name = str(bid_d.get("id_type") or "")
            ua_type_name = str(bid_d.get("ua_type") or "")
            bid = BasicIdMessage(
                id_type=_code(ID_TYPE_NAMES, id_type_name),
                id_type_name=id_type_name,
                ua_type=_code(UA_TYPE_NAMES, ua_type_name),
                ua_type_name=ua_type_name,
                uas_id=str(bid_d.get("uas_id") or ""),
            )
            basic_ids = getattr(ds, "basic_ids", None)
            if isinstance(basic_ids, dict):
                basic_ids[bid.id_type] = bid
            try:
                ds.basic_id = bid
            except AttributeError:
                pass  # read-only property derived from basic_ids

        loc_d = d.get("location")
        if loc_d:
            ds.location = _loc(
                status_name=loc_d.get("status", ""),
                latitude=loc_d.get("latitude"),
                longitude=loc_d.get("longitude"),
                altitude_msl=loc_d.get("altitude_msl"),
                altitude_geo=loc_d.get("altitude_geo"),
                height_agl=loc_d.get("height_agl"),
                speed_horizontal=loc_d.get("speed_h"),
                speed_vertical=loc_d.get("speed_v"),
                direction_deg=loc_d.get("direction"),
            )

        rows = self._db_positions(mac)
        if rows is not None:
            # The DB holds the whole flight: don't clip it to the tracker cap
            ds.location_history = deque()
            for row in rows:
                if not isinstance(row, dict):
                    continue
                pt = _loc(
                    status_name="",
                    latitude=row.get("latitude"),
                    longitude=row.get("longitude"),
                    altitude_msl=row.get("altitude_msl"),
                    altitude_geo=row.get("altitude_geo"),
                    height_agl=row.get("height_agl"),
                    speed_horizontal=row.get("speed_horizontal"),
                    speed_vertical=row.get("speed_vertical"),
                    direction_deg=row.get("direction_deg"),
                )
                ds.location_history.append((_ts(row.get("ts")) or ds.last_seen, pt))
        else:
            for pt in history:
                loc_pt = _loc(
                    status_name="",
                    latitude=pt.get("lat"),
                    longitude=pt.get("lon"),
                    altitude_msl=pt.get("alt"),
                    altitude_geo=pt.get("alt_geo"),
                    height_agl=pt.get("height_agl"),
                )
                ds.location_history.append((_ts(pt.get("ts")) or ds.last_seen, loc_pt))
        return ds

    async def _handle_export(self, request):
        """Serve a KML or GPX export of current drone tracks."""
        fmt = request.match_info.get("fmt", "")
        content_type = _EXPORT_FORMATS.get(fmt)
        if content_type is None:
            raise _web.HTTPNotFound(text="unknown export format (use kml or gpx)")
        loop = asyncio.get_running_loop()
        try:
            body = await loop.run_in_executor(None, self._build_export, fmt)
        except Exception:
            log.exception("Web export (%s) failed", fmt)
            return _json_response({"error": "export failed"}, status=500)
        return _web.Response(
            body=body,
            content_type=content_type,
            headers={"Content-Disposition": f'attachment; filename="odid_export.{fmt}"'},
        )

    async def _handle_sources_list(self, request):
        if self._source_manager is None:
            return _json_response({"error": "source manager not active"}, status=503)
        try:
            sources, version = await self._get_sources_status()
            resp = _json_response(sources)
            resp.headers["X-Sources-Version"] = str(version)
            return resp
        except Exception:
            log.exception("SourceManager.get_status() failed")
            return _json_response({"error": "internal error"}, status=500)

    @staticmethod
    def _error_response(exc: BaseException, action: str):
        # Unknown source ids are rejected (404) before the manager is called,
        # so a KeyError here is an internal bug and falls through to 500.
        if isinstance(exc, _HTTPError):
            return _json_response({"error": exc.message}, status=exc.status)
        if SourceStateError is not None and isinstance(exc, SourceStateError):
            return _json_response({"error": str(exc)}, status=409)
        if isinstance(exc, ValueError):
            return _json_response({"error": str(exc)}, status=400)
        log.error("Source %s failed: %r", action, exc, exc_info=exc)
        return _json_response(
            {"error": f"internal error while trying to {action} the source; see server log"},
            status=500,
        )

    async def _read_json(self, request):
        try:
            return await request.json()
        except (ValueError, UnicodeDecodeError, RecursionError):
            # RecursionError: deeply nested arrays/objects ('[' * 100000)
            raise _HTTPError(400, "invalid JSON body") from None

    def _control_unavailable(self):
        """503 response when source control can't be used, else None."""
        if self._source_manager is None:
            return _json_response({"error": "source manager not active"}, status=503)
        if self._shutting_down or self._stopped:
            return _json_response({"error": "server is shutting down"}, status=503)
        return None

    @staticmethod
    def _check_known_source(source_id: str) -> None:
        """404 unless *source_id* is one the web schema and SourceManager know."""
        if source_id not in _SOURCE_CONFIG_SCHEMA or (
            _MANAGER_SOURCE_IDS is not None and source_id not in _MANAGER_SOURCE_IDS
        ):
            raise _HTTPError(404, f"unknown source: {source_id[:64]}")

    async def _handle_sources_start(self, request):
        unavailable = self._control_unavailable()
        if unavailable is not None:
            return unavailable
        try:
            source_id, config = _validate_start_body(await self._read_json(request))
            self._check_known_source(source_id)
            loop = asyncio.get_running_loop()
            try:
                await loop.run_in_executor(
                    None, self._source_manager.start_source, source_id, config
                )
            except (ImportError, RuntimeError, OSError) as exc:
                # Expected, user-fixable start failures (missing optional
                # dependency, flowgraph missing / exited, Popen / permission
                # errors).  SourceManager stores the same text in the
                # source's error.
                log.warning("Source %s failed to start: %s", source_id, exc)
                log.info("AUDIT source %s start by %s failed", source_id, self._who(request))
                return _json_response(
                    {"error": str(exc) or f"failed to start {source_id}"}, status=503
                )
            log.info("AUDIT source %s started by %s%s", source_id, self._who(request),
                     " (" + ", ".join(f"{k}={v}" for k, v in config.items()) + ")"
                     if config else "")
            return _json_response({"ok": True})
        except Exception as exc:
            return self._error_response(exc, "start")

    async def _handle_sources_stop(self, request):
        unavailable = self._control_unavailable()
        if unavailable is not None:
            return unavailable
        try:
            body = await self._read_json(request)
            source_id = body.get("source") if isinstance(body, dict) else None
            if not isinstance(source_id, str) or not source_id:
                raise _HTTPError(400, "'source' is required")
            self._check_known_source(source_id)
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None, self._source_manager.stop_source, source_id
            )
            log.info("AUDIT source %s stopped by %s", source_id, self._who(request))
            return _json_response({"ok": True})
        except Exception as exc:
            return self._error_response(exc, "stop")

    async def _sdr_control(self, request, verb: str, audit: str, call) -> "_web.Response":
        """Shared body for POST /api/sources/{record,record_stop,gain}:
        validate {"source": ...}, run ``call(manager, source_id, body)``.
        ``verb`` completes "trying to <verb> the source" in a 500 error."""
        unavailable = self._control_unavailable()
        if unavailable is not None:
            return unavailable
        try:
            body = await self._read_json(request)
            source_id = body.get("source") if isinstance(body, dict) else None
            if not isinstance(source_id, str) or not source_id:
                raise _HTTPError(400, "'source' is required")
            self._check_known_source(source_id)
            loop = asyncio.get_running_loop()
            detail = await loop.run_in_executor(None, call, self._source_manager, source_id, body)
            log.info("AUDIT source %s %s by %s%s", source_id, audit, self._who(request),
                     f" ({detail})" if detail else "")
            return _json_response({"ok": True})
        except Exception as exc:
            return self._error_response(exc, verb)

    async def _handle_sources_record(self, request):
        def call(m, sid, body):
            m.record_iq(sid, body.get("seconds"))
            return f"{body.get('seconds')} s"
        return await self._sdr_control(request, "start recording on", "IQ recording requested", call)

    async def _handle_sources_record_stop(self, request):
        return await self._sdr_control(request, "stop recording on", "IQ recording stopped",
                                       lambda m, sid, _b: m.stop_record(sid))

    async def _handle_sources_gain(self, request):
        def call(m, sid, body):
            try:
                gain = _v_gain("gain", body.get("gain"))
            except ValueError as e:
                raise _HTTPError(400, str(e)) from None
            m.set_gain(sid, gain)
            return f"gain {gain} dB"
        return await self._sdr_control(request, "change the gain of", "gain changed", call)

    async def _handle_settings_get(self, request):
        if self._settings is None:
            return _json_response({"error": "settings are only editable in odid serve"},
                                  status=503)
        loop = asyncio.get_running_loop()
        try:
            return _json_response(await loop.run_in_executor(None, self._settings.get))
        except Exception:
            log.exception("Reading settings failed")
            return _json_response({"error": "could not read settings; see server log"},
                                  status=500)

    async def _handle_settings_put(self, request):
        if self._settings is None:
            return _json_response({"error": "settings are only editable in odid serve"},
                                  status=503)
        if self._shutting_down or self._stopped:
            return _json_response({"error": "server is shutting down"}, status=503)
        from odid.web.settings import SettingsError
        loop = asyncio.get_running_loop()
        try:
            body = await self._read_json(request)
            snapshot, changed = await loop.run_in_executor(None, self._settings.put, body)
        except _HTTPError as exc:
            return _json_response({"error": exc.message}, status=exc.status)
        except SettingsError as exc:
            return _json_response({"error": str(exc)}, status=400)
        except Exception:
            log.exception("Saving settings failed")
            return _json_response({"error": "could not save settings; see server log"},
                                  status=500)
        if changed:
            log.info("AUDIT settings changed by %s: %s", self._who(request),
                     ", ".join(f"{k}={v!r}" for k, v in changed.items()))
        return _json_response(snapshot)

    async def _health_snapshot(self) -> dict:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._health.snapshot)

    async def _handle_system(self, request):
        if self._health is None:
            return _json_response({"error": "health is only available in odid serve"},
                                  status=503)
        try:
            return _json_response(await self._health_snapshot())
        except Exception:
            log.exception("Health snapshot failed")
            return _json_response({"error": "internal error"}, status=500)

    async def _handle_logs(self, request):
        if self._logs is None:
            return _json_response({"error": "logs are only available in odid serve"}, status=503)
        q = request.query
        try:
            n = int(q.get("n", "500"))
        except ValueError:
            return _json_response({"error": "n must be a number"}, status=400)
        loop = asyncio.get_running_loop()
        try:
            return _json_response(await loop.run_in_executor(
                None, self._logs.get, n, q.get("level", "info")))
        except ValueError as exc:
            return _json_response({"error": str(exc)}, status=400)

    def _captures_unavailable(self):
        if self._data_dir is None:
            return _json_response({"error": "captures are only available in odid serve"},
                                  status=503)
        return None

    async def _handle_sessions(self, request):
        unavailable = self._captures_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web import captures
        loop = asyncio.get_running_loop()
        return _json_response(await loop.run_in_executor(
            None, captures.list_sessions, self._data_dir))

    async def _handle_session_download(self, request):
        unavailable = self._captures_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web import captures
        name = request.match_info.get("name", "")
        loop = asyncio.get_running_loop()
        try:
            fd, size = await loop.run_in_executor(None, captures.open_file, self._data_dir, name)
        except OSError:
            return _json_response({"error": "no such capture file"}, status=404)
        try:
            resp = _web.StreamResponse(headers={
                "Content-Type": captures.content_type(name),
                "Content-Disposition": f'attachment; filename="{name}"',
                "Cache-Control": "no-store",
            })
            resp.content_length = size
            await resp.prepare(request)
            left = size     # a file still being written: send what existed at open
            while left > 0:
                chunk = await loop.run_in_executor(None, os.read, fd, min(left, 256 * 1024))
                if not chunk:
                    break
                left -= len(chunk)
                await resp.write(chunk)
            await resp.write_eof()
            return resp
        finally:
            os.close(fd)

    async def _handle_session_delete(self, request):
        unavailable = self._captures_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web import captures
        sid = request.match_info.get("sid", "")
        loop = asyncio.get_running_loop()
        try:
            removed = await loop.run_in_executor(
                None, captures.delete_session, self._data_dir, sid)
        except captures.SessionBusy:
            return _json_response({"error": "this session is still being recorded"}, status=409)
        except FileNotFoundError:
            return _json_response({"error": "no such session"}, status=404)
        log.info("AUDIT capture session %s deleted by %s: %s", sid, self._who(request),
                 ", ".join(removed))
        return _json_response({"ok": True, "removed": removed})

    def _recording_busy(self) -> frozenset:
        m = self._source_manager
        try:
            return frozenset(m.recording_files()) if m is not None else frozenset()
        except Exception:
            log.exception("recording_files() failed")
            return frozenset()

    async def _handle_recordings(self, request):
        unavailable = self._captures_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web import captures
        loop = asyncio.get_running_loop()
        return _json_response(await loop.run_in_executor(
            None, captures.list_recordings, self._data_dir, self._recording_busy()))

    async def _handle_recording_delete(self, request):
        unavailable = self._captures_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web import captures
        rid = request.match_info.get("rid", "")
        loop = asyncio.get_running_loop()
        try:
            removed = await loop.run_in_executor(
                None, captures.delete_recording, self._data_dir, rid, self._recording_busy())
        except captures.SessionBusy:
            return _json_response({"error": "this recording is still being written"}, status=409)
        except FileNotFoundError:
            return _json_response({"error": "no such recording"}, status=404)
        log.info("AUDIT IQ recording %s deleted by %s: %s", rid, self._who(request),
                 ", ".join(removed))
        return _json_response({"ok": True, "removed": removed})

    async def _handle_update_status(self, request):
        if self._actions is None:
            return _json_response({"available": False, "running": False, "result": None})
        loop = asyncio.get_running_loop()
        return _json_response(await loop.run_in_executor(None, self._actions.update_status))

    async def _handle_system_action(self, request):
        from odid.web.actions import ACTIONS, ActionError
        action = request.match_info.get("action", "")
        if action not in ACTIONS:
            return _json_response({"error": "unknown action"}, status=404)
        if self._actions is None or not self._actions.available:
            return _json_response(
                {"error": "only available when running as the odid service"}, status=503)
        try:
            body = await self._read_json(request)
        except _HTTPError as exc:
            return _json_response({"error": exc.message}, status=exc.status)
        if not isinstance(body, dict) or body.get("confirm") is not True:
            return _json_response({"error": 'send {"confirm": true} to ' + action}, status=400)
        who = self._who(request)
        # Logged first: a restart or reboot may stop us right after systemctl
        log.warning("AUDIT system %s requested by %s", action, who)
        loop = asyncio.get_running_loop()
        try:
            message = await loop.run_in_executor(None, self._actions.run, action)
        except ActionError as exc:
            log.warning("AUDIT system %s failed: %s", action, exc)
            return _json_response({"error": str(exc)}, status=502)
        return _json_response({"ok": True, "message": message})

    # -- accounts ---------------------------------------------------------
    # Everyone may change their own password. Admins manage *viewers* only:
    # admin accounts need a shell (sudo odid passwd), so a stolen admin
    # session can't create another admin.

    def _accounts_unavailable(self):
        if not self._login_required():
            return _json_response({"error": "sign-in is not enabled"}, status=404)
        return None

    async def _handle_change_password(self, request):
        unavailable = self._accounts_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web.auth import AuthError
        sess = request["odid_session"]
        body = await self._read_json_or_none(request)
        current = body.get("current") if body else None
        new = body.get("new") if body else None
        if not isinstance(current, str) or not isinstance(new, str):
            return _json_response({"error": "'current' and 'new' are required"}, status=400)
        ip = self._client_ip(request)
        keys = ["ip:" + ip, "user:" + sess.user]
        busy = self._auth_busy_response()
        if busy is not None:
            return busy
        wait = self._limiter.attempt(*keys)
        if wait > 0:
            return _json_response(
                {"error": f"Too many wrong passwords. Try again in {math.ceil(wait)} s"},
                status=429, headers={"Retry-After": str(math.ceil(wait))})
        if await self._run_auth(self._auth.authenticate, sess.user, current) is None:
            log.warning("AUDIT password change for %s from %s: wrong current password",
                        sess.user, ip)
            return _json_response({"error": "The current password is wrong"}, status=403)
        self._limiter.success(*keys)
        keep = request.cookies.get(_SESSION_COOKIE)
        try:
            await self._run_auth(lambda: self._auth.set_user(
                sess.user, new, create=False, keep_token=keep))
        except AuthError as exc:
            return _json_response({"error": str(exc)}, status=400)
        log.info("AUDIT password changed: %s from %s (other sessions signed out)", sess.user, ip)
        return _json_response({"ok": True})

    async def _read_json_or_none(self, request):
        try:
            body = await self._read_json(request)
        except _HTTPError:
            return None
        return body if isinstance(body, dict) else None

    async def _handle_users(self, request):
        unavailable = self._accounts_unavailable()
        if unavailable is not None:
            return unavailable
        loop = asyncio.get_running_loop()
        return _json_response({"me": request["odid_session"].user,
                               "users": await loop.run_in_executor(None, self._auth.accounts)})

    def _viewer_target(self, name: str):
        """Error response unless *name* is an existing viewer, else None."""
        role = self._auth.role_of(name) if isinstance(name, str) else None
        if role is None:
            return _json_response({"error": "no such user"}, status=404)
        if role != "viewer":
            return _json_response({"error": "admin accounts are managed on the sensor: "
                                            "sudo odid passwd <name>"}, status=403)
        return None

    async def _handle_user_add(self, request):
        unavailable = self._accounts_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web.auth import AuthError
        body = await self._read_json_or_none(request)
        name = body.get("name") if body else None
        password = body.get("password") if body else None
        if not isinstance(name, str) or not isinstance(password, str):
            return _json_response({"error": "'name' and 'password' are required"}, status=400)
        if self._auth.role_of(name) is not None:
            return _json_response({"error": f"{name} already exists"}, status=409)
        try:
            await self._run_auth(self._auth.add_user, name, password, "viewer")
        except AuthError as exc:
            return _json_response({"error": str(exc)}, status=400)
        log.info("AUDIT viewer %s added by %s from %s", name, request["odid_session"].user,
                 self._client_ip(request))
        return _json_response({"ok": True})

    async def _handle_user_password(self, request):
        unavailable = self._accounts_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web.auth import AuthError
        name = request.match_info.get("name", "")
        denied = self._viewer_target(name)
        if denied is not None:
            return denied
        body = await self._read_json_or_none(request)
        password = body.get("password") if body else None
        if not isinstance(password, str):
            return _json_response({"error": "'password' is required"}, status=400)
        try:
            await self._run_auth(lambda: self._auth.set_user(
                name, password, create=False, only_role="viewer"))
        except AuthError as exc:
            return _json_response({"error": str(exc)}, status=400)
        log.info("AUDIT password of viewer %s reset by %s from %s", name,
                 request["odid_session"].user, self._client_ip(request))
        return _json_response({"ok": True})

    async def _handle_user_delete(self, request):
        unavailable = self._accounts_unavailable()
        if unavailable is not None:
            return unavailable
        from odid.web.auth import AuthError
        name = request.match_info.get("name", "")
        denied = self._viewer_target(name)
        if denied is not None:
            return denied
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, lambda: self._auth.remove_user(name, "viewer"))
        except AuthError as exc:
            return _json_response({"error": str(exc)}, status=400)
        log.info("AUDIT viewer %s removed by %s from %s", name, request["odid_session"].user,
                 self._client_ip(request))
        return _json_response({"ok": True})

    async def _health_loop(self) -> None:
        """Push a health snapshot every _HEALTH_PUSH_S while anyone watches.
        Snapshots also feed the frames/s window, so keep sampling."""
        while not self._stopped:
            try:
                snap = await self._health_snapshot()
                if self._clients:
                    self._broadcast_nowait({"type": "system", "system": snap})
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Health snapshot failed")
            await asyncio.sleep(_HEALTH_PUSH_S)

    async def _start_server(self) -> None:
        @_web.middleware
        async def _security(request, handler):
            return await self._security_middleware(request, handler)

        app = _web.Application(middlewares=[_security])
        app.on_response_prepare.append(self._add_security_headers)
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/login", self._handle_login_page)
        app.router.add_get("/favicon.ico", self._handle_favicon)
        app.router.add_get("/static/{name}", self._handle_static)
        app.router.add_post("/api/login", self._handle_login)
        app.router.add_post("/api/logout", self._handle_logout)
        app.router.add_get("/api/session", self._handle_session)
        app.router.add_get("/ws", self._handle_ws)
        app.router.add_get("/history/{mac}", self._handle_history)
        app.router.add_get("/export/{fmt}", self._handle_export)
        app.router.add_get("/api/sources", self._handle_sources_list)
        app.router.add_post("/api/sources/start", self._handle_sources_start)
        app.router.add_post("/api/sources/stop", self._handle_sources_stop)
        app.router.add_post("/api/sources/record", self._handle_sources_record)
        app.router.add_post("/api/sources/record_stop", self._handle_sources_record_stop)
        app.router.add_post("/api/sources/gain", self._handle_sources_gain)
        app.router.add_get("/api/settings", self._handle_settings_get)
        app.router.add_put("/api/settings", self._handle_settings_put)
        app.router.add_get("/api/system", self._handle_system)
        app.router.add_post("/api/account/password", self._handle_change_password)
        app.router.add_get("/api/users", self._handle_users)
        app.router.add_post("/api/users", self._handle_user_add)
        app.router.add_post("/api/users/{name}/password", self._handle_user_password)
        app.router.add_delete("/api/users/{name}", self._handle_user_delete)
        app.router.add_get("/api/system/update", self._handle_update_status)
        app.router.add_post("/api/system/{action}", self._handle_system_action)
        app.router.add_get("/api/logs", self._handle_logs)
        app.router.add_get("/api/sessions", self._handle_sessions)
        app.router.add_get("/api/sessions/{name}/download", self._handle_session_download)
        app.router.add_delete("/api/sessions/{sid}", self._handle_session_delete)
        app.router.add_get("/api/recordings", self._handle_recordings)
        app.router.add_delete("/api/recordings/{rid}", self._handle_recording_delete)
        app.on_shutdown.append(self._on_shutdown)
        self._runner = _web.AppRunner(app, access_log=None, shutdown_timeout=2.0)
        await self._runner.setup()
        site = _web.TCPSite(self._runner, self._host, self._port)
        await site.start()
        if not self._port:
            # port=0 → OS-assigned; report the real one
            for addr in self._runner.addresses:
                if isinstance(addr, tuple) and len(addr) >= 2:
                    self._port = addr[1]
                    break
        if self._tls is not None:
            tls_host, tls_port, ssl_ctx = self._tls
            before = set(map(repr, self._runner.addresses))
            tls_site = _web.TCPSite(self._runner, tls_host, tls_port, ssl_context=ssl_ctx)
            await tls_site.start()
            if not tls_port:
                for addr in self._runner.addresses:
                    if repr(addr) not in before and isinstance(addr, tuple) and len(addr) >= 2:
                        self._tls = (tls_host, addr[1], ssl_ctx)
                        break
        self._flush_task = asyncio.ensure_future(self._flush_loop())
        if self._health is not None:
            self._health_task = asyncio.ensure_future(self._health_loop())
        if not self._bind_is_loopback():
            # Discover the Host allowlist only AFTER binding and without
            # blocking start-up: `ip` / getaddrinfo / getfqdn can stall on a
            # broken resolver and must not count against _START_TIMEOUT_S.
            # A request that arrives first waits on the same lock (or runs
            # the refresh itself) in _check_host.
            self._spawn(self._initial_allowlist_refresh())

    async def _initial_allowlist_refresh(self) -> None:
        if self._allowed_refresh_lock is None:
            self._allowed_refresh_lock = asyncio.Lock()
        async with self._allowed_refresh_lock:
            if self._allowed_refreshed_at != float("-inf"):
                return  # a request already ran it
            loop = asyncio.get_running_loop()
            try:
                await loop.run_in_executor(None, self._refresh_allowed_hosts)
            except Exception as exc:
                log.warning("Could not determine local addresses for Host allowlist: %r", exc)
                self._allowed_refreshed_at = time.monotonic()
