"""JSONL streaming output for ODID frames."""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from odid.decode.frame import ODIDFrame
from odid.track.tracker import DroneState

log = logging.getLogger(__name__)


def _to_jsonable(value):
    """Recursively convert decoded messages to JSON-safe values.

    Dataclass messages become dicts (private fields dropped), bytes become hex
    strings, sets become sorted lists; Message Pack sub-messages are handled
    by the same function.
    """
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).hex()
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted(_to_jsonable(v) for v in value)
    if hasattr(value, "__dict__") and not isinstance(value, type):
        return {
            k: _to_jsonable(v) for k, v in vars(value).items() if not k.startswith("_")
        }
    return value


class JSONLWriter:
    """Append-only JSONL writer for frame data.

    One JSON object per line, easy to stream process with jq, etc.
    """

    def __init__(self, output_dir: str | Path = "logs", session_ts: Optional[str] = None):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        ts = session_ts or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_file = self.output_dir / f"odid_session_{ts}.jsonl"
        self._fh = open(self.session_file, "a")
        log.info("JSONL output: %s", self.session_file)

    def write_frame(self, frame: ODIDFrame, drone: "DroneState | dict | None" = None):
        """Write a single frame as one JSON line.

        ``drone`` is either a snapshot dict ``{"uas_id": ..., "frame_count": ...}``
        captured when the frame was processed, or (for backward compatibility)
        a DroneState, whose live values are read now. The record timestamp is
        the frame's capture time when known.
        """
        if self._fh is None:
            return
        ts = frame.timestamp or datetime.now(timezone.utc)
        record = {
            "timestamp": ts.isoformat(),
            "mac": frame.source_mac,
            "signal_dbm": frame.signal_dbm,
            "channel": frame.channel,
            "frame_type": frame.frame_type,
            "counter": frame.message_counter,
            "proto_version": frame.proto_version,
            "messages": [],
        }

        for msg in frame.messages:
            record["messages"].append(_to_jsonable(msg))

        if isinstance(drone, dict):
            if "uas_id" in drone:
                record["uas_id"] = drone.get("uas_id")
            if "frame_count" in drone:
                record["frame_count"] = drone.get("frame_count")
        elif drone is not None:
            record["uas_id"] = drone.uas_id
            record["frame_count"] = drone.frame_count
        if frame.snr_db is not None:
            record["snr_db"] = frame.snr_db

        self._fh.write(json.dumps(record, default=str) + "\n")
        self._fh.flush()

    def close(self):
        if self._fh:
            self._fh.close()
            self._fh = None
            log.info("JSONL closed: %s", self.session_file)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
