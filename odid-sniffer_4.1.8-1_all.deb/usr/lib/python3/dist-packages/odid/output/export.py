"""KML and GPX flight-path export from DroneState location history."""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from odid.track.tracker import DroneState

log = logging.getLogger(__name__)

ODID_GPX_NS = "https://github.com/opendroneid/odid-sniffer/gpx-ext/1"
ET.register_namespace("odid", ODID_GPX_NS)


# ---------------------------------------------------------------------------
# Douglas-Peucker path simplification (plan item 2.6)
# ---------------------------------------------------------------------------

def _perp_dist_sq(p, a, b):
    """Squared perpendicular distance from point p to line a→b (lon, lat coords)."""
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    if dx == 0.0 and dy == 0.0:
        return (px - ax) ** 2 + (py - ay) ** 2
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return (px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2


def _simplify_track(points, epsilon=0.00005):
    """Douglas-Peucker path simplification.

    Args:
        points: list of (timestamp, LocationMessage) tuples.
        epsilon: perpendicular distance threshold in degrees (~5 m at equator).

    Returns:
        Simplified list, preserving first and last points.
    """
    if len(points) <= 2:
        return list(points)

    epsilon_sq = epsilon * epsilon
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]

    while stack:
        start, end = stack.pop()
        a = (points[start][1].longitude, points[start][1].latitude)
        b = (points[end][1].longitude, points[end][1].latitude)
        max_d, max_i = 0.0, start
        for i in range(start + 1, end):
            d = _perp_dist_sq((points[i][1].longitude, points[i][1].latitude), a, b)
            if d > max_d:
                max_d, max_i = d, i
        if max_d > epsilon_sq:
            keep[max_i] = True
            stack.append((start, max_i))
            stack.append((max_i, end))

    result = [pt for i, pt in enumerate(points) if keep[i]]
    log.debug(
        "Douglas-Peucker: %d → %d points (%.0f%% reduction)",
        len(points), len(result),
        100.0 * (1 - len(result) / len(points)) if points else 0,
    )
    return result


# Altitude datum for exported tracks
# ----------------------------------
# KML ``altitudeMode=absolute`` is "relative to sea level", and GPX 1.1
# ``<ele>`` ("Elevation (in meters) of the point") is by convention height
# above mean sea level (GPS receivers record geoid/MSL height there). F3411
# carries two altitudes:
#   * pressure altitude (``altitude_msl``) - barometric, standard atmosphere
#     (29.92 inHg), so an approximation of MSL;
#   * geodetic altitude (``altitude_geo``) - WGS-84 height above the
#     ellipsoid (HAE), which differs from MSL by the local geoid undulation
#     (about -105 m to +85 m worldwide).
# Pressure altitude is therefore preferred. When it is missing, geodetic
# altitude is used as-is (no geoid correction) and the export says so.
ALT_SOURCE_LABELS = {
    "altitude_msl": "pressure altitude (approx. MSL)",
    "altitude_geo": "WGS-84 ellipsoid height (HAE, not MSL; no geoid correction)",
    "mixed": "pressure altitude where available, else WGS-84 ellipsoid height (HAE)",
}


def _altitude(loc, source: Optional[str] = None) -> Optional[float]:
    """Altitude for a track point from ``source``.

    With no (or "mixed") source: pressure altitude, else geodetic (HAE).
    """
    if source in ("altitude_msl", "altitude_geo"):
        return getattr(loc, source, None)
    alt = getattr(loc, "altitude_msl", None)
    return alt if alt is not None else getattr(loc, "altitude_geo", None)


def _altitude_source(locs) -> Optional[str]:
    """Pick one altitude source for a whole track so points are comparable.

    "altitude_msl" if every point has pressure altitude, else "altitude_geo"
    if every point has geodetic altitude, else "mixed" if some point has
    either, else None.
    """
    locs = list(locs)
    if not locs:
        return None
    for src in ("altitude_msl", "altitude_geo"):
        if all(getattr(loc, src, None) is not None for loc in locs):
            return src
    if any(_altitude(loc) is not None for loc in locs):
        return "mixed"
    return None


def _kml_coords(locs, source: Optional[str] = None) -> tuple[str, str]:
    """Return (altitudeMode, coordinates) for KML geometry.

    With an altitude for every point the geometry is ``absolute``. If any
    point's altitude is unknown, altitudes are left out and the geometry is
    ``clampToGround`` rather than drawing unknown fixes at 0 m (sea level).
    ``source`` defaults to the track's :func:`_altitude_source`.
    """
    if source is None:
        source = _altitude_source(locs)
    alts = [_altitude(loc, source) for loc in locs]
    if locs and all(a is not None for a in alts):
        return "absolute", " ".join(
            f"{loc.longitude:.7f},{loc.latitude:.7f},{a:.1f}" for loc, a in zip(locs, alts)
        )
    return "clampToGround", " ".join(
        f"{loc.longitude:.7f},{loc.latitude:.7f}" for loc in locs
    )


def _utc_iso(ts: datetime) -> str:
    """Format a timestamp as ISO-8601 UTC with a 'Z' suffix.

    Naive datetimes (e.g. from older records) are taken as local time.
    """
    return ts.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _valid_points(history) -> list:
    return [
        (ts, loc) for ts, loc in list(history)
        if loc.latitude is not None and loc.longitude is not None
    ]


# ---------------------------------------------------------------------------
# KML export
# ---------------------------------------------------------------------------

def export_kml(drones: list[DroneState], out_path: Path) -> Path:
    """Write a KML file with one LineString per drone track.

    Args:
        drones: List of DroneState objects (must have location_history).
        out_path: Destination .kml file path.

    Returns:
        out_path (for caller convenience).
    """
    kml = ET.Element("kml", xmlns="http://www.opengis.net/kml/2.2")
    doc = ET.SubElement(kml, "Document")
    ET.SubElement(doc, "name").text = f"ODID Flight Tracks {datetime.now().strftime('%Y-%m-%d %H:%M')}"

    # Style definitions
    for style_id, color in (("airborne", "ff0000ff"), ("ground", "ff00ff00"), ("default", "ff00ffff")):
        style = ET.SubElement(doc, "Style", id=style_id)
        ls = ET.SubElement(style, "LineStyle")
        ET.SubElement(ls, "color").text = color
        ET.SubElement(ls, "width").text = "2"
        ps = ET.SubElement(style, "PolyStyle")
        ET.SubElement(ps, "fill").text = "0"

    written = 0
    skipped = 0
    for drone in drones:
        history = drone.location_history
        if not history:
            log.debug("Skipping drone %s: no location history", drone.mac)
            skipped += 1
            continue

        # Filter points with valid coordinates
        points = _valid_points(history)
        if not points:
            log.debug("Skipping drone %s: no valid coordinates in history", drone.mac)
            skipped += 1
            continue

        # Simplify path before export (plan item 2.6)
        if len(points) > 10:
            points = _simplify_track(points)

        label = drone.uas_id or drone.mac
        pm = ET.SubElement(doc, "Placemark")
        ET.SubElement(pm, "name").text = label
        ET.SubElement(pm, "styleUrl").text = "#default"

        # Description with metadata
        desc_lines = [
            f"MAC: {drone.mac}",
            f"UAS ID: {drone.uas_id or 'N/A'}",
            f"Frames: {drone.frame_count}",
            f"Duration: {drone.duration_seconds:.1f}s",
            f"Points: {len(points)}",
        ]
        if drone.basic_id:
            desc_lines.append(f"UA Type: {drone.basic_id.ua_type_name}")
        track_locs = [loc for _, loc in points]
        alt_src = _altitude_source(track_locs)
        alt_mode, coords_str = _kml_coords(track_locs, alt_src)
        if alt_mode == "absolute":
            desc_lines.append(f"Altitude: {ALT_SOURCE_LABELS[alt_src]}")
        ET.SubElement(pm, "description").text = "\n".join(desc_lines)

        if len(points) >= 2:
            geom = ET.SubElement(pm, "LineString")
            ET.SubElement(geom, "tessellate").text = "1"
        else:
            # A LineString needs at least two coordinates
            geom = ET.SubElement(pm, "Point")
        ET.SubElement(geom, "altitudeMode").text = alt_mode
        ET.SubElement(geom, "coordinates").text = coords_str

        # First-point placemark
        first_loc = points[0][1]
        fp = ET.SubElement(doc, "Placemark")
        ET.SubElement(fp, "name").text = f"{label} [start]"
        ET.SubElement(fp, "styleUrl").text = "#airborne"
        pt = ET.SubElement(fp, "Point")
        first_mode, first_coords = _kml_coords([first_loc], alt_src)
        ET.SubElement(pt, "altitudeMode").text = first_mode
        ET.SubElement(pt, "coordinates").text = first_coords

        written += 1

    tree = ET.ElementTree(kml)
    ET.indent(tree, space="  ")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(str(out_path), xml_declaration=True, encoding="utf-8")
    log.info("KML export: %d tracks → %s", written, out_path)
    if skipped:
        log.warning("KML export: skipped %d drone(s) with no valid location data", skipped)
    return out_path


# ---------------------------------------------------------------------------
# GPX export
# ---------------------------------------------------------------------------

def export_gpx(drones: list[DroneState], out_path: Path) -> Path:
    """Write a GPX file with one <trk> per drone.

    Args:
        drones: List of DroneState objects (must have location_history).
        out_path: Destination .gpx file path.

    Returns:
        out_path (for caller convenience).
    """
    gpx = ET.Element(
        "gpx",
        version="1.1",
        creator="ODID Sniffer",
        xmlns="http://www.topografix.com/GPX/1/1",
    )

    written = 0
    skipped = 0
    for drone in drones:
        history = drone.location_history
        if not history:
            skipped += 1
            continue

        points = _valid_points(history)
        if not points:
            skipped += 1
            continue

        # Simplify path before export (plan item 2.6)
        if len(points) > 10:
            points = _simplify_track(points)

        label = drone.uas_id or drone.mac
        trk = ET.SubElement(gpx, "trk")
        ET.SubElement(trk, "name").text = label
        alt_src = _altitude_source(loc for _, loc in points)
        cmt = f"MAC:{drone.mac} frames:{drone.frame_count} dur:{drone.duration_seconds:.1f}s"
        if alt_src is not None:
            cmt += f" ele:{ALT_SOURCE_LABELS[alt_src]}"
        ET.SubElement(trk, "cmt").text = cmt

        seg = ET.SubElement(trk, "trkseg")
        for ts, loc in points:
            trkpt = ET.SubElement(
                seg, "trkpt",
                lat=f"{loc.latitude:.7f}",
                lon=f"{loc.longitude:.7f}",
            )
            alt = _altitude(loc, alt_src)
            if alt is not None:
                ET.SubElement(trkpt, "ele").text = f"{alt:.1f}"
            ET.SubElement(trkpt, "time").text = _utc_iso(ts)
            if loc.speed_horizontal is not None:
                # <speed> is not part of GPX 1.1 trkpt; carry it as an extension
                ext = ET.SubElement(trkpt, "extensions")
                ET.SubElement(ext, f"{{{ODID_GPX_NS}}}speed").text = f"{loc.speed_horizontal:.2f}"

        written += 1

    tree = ET.ElementTree(gpx)
    ET.indent(tree, space="  ")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(str(out_path), xml_declaration=True, encoding="utf-8")
    log.info("GPX export: %d tracks → %s", written, out_path)
    if skipped:
        log.warning("GPX export: skipped %d drone(s) with no valid location data", skipped)
    return out_path
