"""CSV export for ODID location data.

Writes one row per Location message with key fields for
spreadsheet analysis, mapping tools, or further processing.
"""

import csv
import time
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from odid.decode.frame import ODIDFrame
from odid.decode.messages import LocationMessage, MessagePack

log = logging.getLogger(__name__)

CSV_FIELDS = [
    "timestamp",
    "mac",
    "uas_id",
    "signal_dbm",
    "channel",
    "status",
    "latitude",
    "longitude",
    "altitude_msl",
    "altitude_geo",
    "height_agl",
    "height_type",
    "speed_horizontal",
    "speed_vertical",
    "direction",
]


_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _safe_text(value) -> str:
    """Neutralise spreadsheet formula injection in an untrusted text cell.

    Per OWASP, a cell starting with = + - @ TAB or CR is prefixed with a
    single quote so Excel/LibreOffice treat it as text, not a formula.
    """
    if value is None:
        return ""
    s = str(value)
    return "'" + s if s.startswith(_FORMULA_PREFIXES) else s


class CSVWriter:
    """Writes location data to CSV file."""

    def __init__(self, output_dir: str | Path = "logs", session_ts: Optional[str] = None):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        ts = session_ts or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.csv_file = self.output_dir / f"odid_locations_{ts}.csv"
        self._fh = open(self.csv_file, "w", newline="")
        self._writer = csv.DictWriter(self._fh, fieldnames=CSV_FIELDS, extrasaction="ignore")
        self._writer.writeheader()
        self._fh.flush()
        self._count = 0
        self._unflushed = 0
        self._FLUSH_EVERY = 10
        # Also flush at least this often, so a hard kill loses only a
        # bounded window of rows.
        self._FLUSH_INTERVAL_SECS = 2.0
        self._last_flush = time.monotonic()
        log.info("CSV output: %s", self.csv_file)

    @staticmethod
    def _iter_locations(messages):
        """Yield LocationMessages, descending into Message Packs."""
        for msg in messages:
            if isinstance(msg, LocationMessage):
                yield msg
            elif isinstance(msg, MessagePack):
                yield from CSVWriter._iter_locations(msg.messages)

    def write_frame(self, frame: ODIDFrame, uas_id: Optional[str] = ""):
        """Write location messages from a frame (including inside packs) to CSV.

        ``uas_id`` should be the value captured when the frame was processed.
        The row timestamp is the frame's capture time when known.
        """
        if self._fh is None:
            return
        ts = (frame.timestamp or datetime.now(timezone.utc)).isoformat()
        written = 0
        for msg in self._iter_locations(frame.messages):
            row = {
                "timestamp": ts,
                "mac": _safe_text(frame.source_mac),
                "uas_id": _safe_text(uas_id),
                "signal_dbm": frame.signal_dbm,
                "channel": frame.channel,
                "status": msg.status_name,
                "latitude": msg.latitude,
                "longitude": msg.longitude,
                "altitude_msl": msg.altitude_msl,
                "altitude_geo": msg.altitude_geo,
                "height_agl": msg.height_agl,
                "height_type": msg.height_type_name,
                "speed_horizontal": msg.speed_horizontal,
                "speed_vertical": msg.speed_vertical,
                "direction": msg.direction_deg,
            }
            self._writer.writerow(row)
            written += 1

        if written:
            self._count += written
            self._unflushed += written
            if (self._unflushed >= self._FLUSH_EVERY
                    or time.monotonic() - self._last_flush >= self._FLUSH_INTERVAL_SECS):
                self._flush()

    def _flush(self):
        self._fh.flush()
        self._unflushed = 0
        self._last_flush = time.monotonic()

    def flush_if_due(self, force: bool = False) -> bool:
        """Flush buffered rows if the flush interval has passed (or ``force``).

        For idle ticks, so the tail is written even when frames stop arriving.
        Returns True if a flush happened.
        """
        if self._fh is None or self._unflushed == 0:
            return False
        if not force and time.monotonic() - self._last_flush < self._FLUSH_INTERVAL_SECS:
            return False
        self._flush()
        return True

    @property
    def row_count(self) -> int:
        return self._count

    def close(self):
        if self._fh:
            self._fh.close()
            self._fh = None
            log.info("CSV closed: %s (%d rows)", self.csv_file, self._count)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
