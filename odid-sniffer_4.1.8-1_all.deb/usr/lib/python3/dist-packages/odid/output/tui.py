"""Live TUI dashboard using rich: shows all active drones in a live table."""

import contextlib
import logging
import threading
from datetime import datetime

from rich.markup import escape

from odid.track.tracker import as_utc, utcnow
from typing import Optional

log = logging.getLogger(__name__)

try:
    from rich import box
    from rich.console import Console
    from rich.live import Live
    from rich.table import Table

    _RICH_AVAILABLE = True
except ImportError:
    _RICH_AVAILABLE = False


def _signal_markup(dbm: Optional[int]) -> str:
    if dbm is None:
        return "-"
    if dbm >= -60:
        return f"[green]{dbm} dBm[/green]"
    if dbm >= -75:
        return f"[yellow]{dbm} dBm[/yellow]"
    return f"[red]{dbm} dBm[/red]"


# F3411 flight status codes: 1 ground, 2 airborne, 3 emergency,
# 4 Remote ID system failure
_STATUS_ALERT = (3, 4)


def _status_markup(status: Optional[str], code: Optional[int] = None) -> str:
    if not status:
        return "-"
    s = status.lower()
    status = escape(status)
    if code in _STATUS_ALERT or "emergency" in s or "failure" in s:
        return f"[bold magenta]{status}[/bold magenta]"
    if code == 2 or "airborne" in s:
        return f"[bold red]{status}[/bold red]"
    if code == 1 or "ground" in s:
        return f"[green]{status}[/green]"
    return status


def _altitude_text(loc) -> str:
    """Pressure altitude, falling back to geodetic (e.g. DJI sends no baro)."""
    if loc is None:
        return "-"
    if loc.altitude_msl is not None:
        return f"{loc.altitude_msl:.0f}m"
    geo = getattr(loc, "altitude_geo", None)
    if geo is not None:
        return f"{geo:.0f}m geo"
    return "-"


def _last_seen_markup(drone, now: Optional[datetime] = None) -> str:
    if now is None:
        now = utcnow()
    elapsed = (now - as_utc(drone.last_seen)).total_seconds()
    s = f"{elapsed:.0f}s ago"
    if elapsed < 10:
        return f"[green]{s}[/green]"
    if elapsed < 60:
        return f"[yellow]{s}[/yellow]"
    return f"[red]{s}[/red]"


class TUIDisplay:
    """Live rich table showing all detected drones.

    Use as a context manager and register ``update`` as a DroneTracker
    ``on_update`` callback::

        with TUIDisplay(observer_lat, observer_lon, tracker=tracker) as tui:
            tracker.on_update(tui.update)
            capture.sniff(channel=6)

    With ``tracker`` the table is rendered from the tracker's snapshot, so
    evicted drones disappear. Without it, the TUI keeps its own map and prunes
    drones not heard for ``ttl_seconds``. The table is rebuilt by rich's
    refresh timer, not on every frame.
    """

    def __init__(
        self,
        observer_lat: Optional[float] = None,
        observer_lon: Optional[float] = None,
        tracker=None,
        ttl_seconds: float = 300.0,
    ):
        if not _RICH_AVAILABLE:
            raise ImportError(
                "rich is required for TUI mode. Install it with: pip install rich"
            )
        self._observer_lat = observer_lat
        self._observer_lon = observer_lon
        self._tracker = tracker
        self._ttl = ttl_seconds
        self._drones: dict = {}  # mac -> DroneState (only used without a tracker)
        self._total_frames = 0
        self._lock = threading.Lock()
        self._console = Console()
        self._live: Optional[Live] = None

    def update(self, drone, frame) -> None:
        """Callback for DroneTracker.on_update(). Cheap: rendering happens on refresh."""
        with self._lock:
            if self._tracker is None:
                self._drones[drone.mac] = drone
            self._total_frames += 1

    def __rich__(self) -> "Table":
        return self._build_table()

    def _current_drones(self) -> list:
        if self._tracker is not None:
            drones = list(self._tracker.drones.values())
        else:
            now = utcnow()
            with self._lock:
                stale = [
                    mac for mac, d in self._drones.items()
                    if (now - as_utc(d.last_seen)).total_seconds() >= self._ttl
                ]
                for mac in stale:
                    del self._drones[mac]
                drones = list(self._drones.values())
        return sorted(drones, key=lambda d: d.last_seen, reverse=True)

    def _build_table(self) -> Table:
        # Hold the tracker lock while reading DroneState fields so capture
        # threads don't mutate them mid-render.
        guard = self._tracker.lock if self._tracker is not None else contextlib.nullcontext()
        with guard:
            return self._build_table_locked()

    def _build_table_locked(self) -> Table:
        drones = self._current_drones()
        count = len(drones)
        if self._tracker is not None:
            total = self._tracker.total_frames
        else:
            with self._lock:
                total = self._total_frames

        table = Table(
            title=(
                f"[bold cyan]OpenDroneID Live Dashboard[/bold cyan]  "
                f"[dim]{datetime.now().strftime('%H:%M:%S')}  "
                f"Drones: {count}  Frames: {total}[/dim]"
            ),
            box=box.ROUNDED,
            header_style="bold white",
            expand=True,
            show_lines=False,
        )

        now = self._tracker.now() if self._tracker is not None else utcnow()
        has_observer = self._observer_lat is not None and self._observer_lon is not None

        table.add_column("#", style="dim", width=3, justify="right")
        table.add_column("UAS ID", min_width=16)
        table.add_column("MAC", min_width=17, style="dim")
        table.add_column("UA Type", min_width=11)
        table.add_column("Status", min_width=10)
        table.add_column("Latitude", min_width=10, justify="right")
        table.add_column("Longitude", min_width=11, justify="right")
        table.add_column("Altitude", min_width=8, justify="right")
        table.add_column("Speed H", min_width=8, justify="right")
        table.add_column("Signal", min_width=9, justify="right")
        if has_observer:
            table.add_column("Distance", min_width=9, justify="right")
        table.add_column("Frames", min_width=6, justify="right")
        table.add_column("Last Seen", min_width=9)

        if not drones:
            placeholder = ["-"] * (12 + (1 if has_observer else 0))
            table.add_row(*placeholder)
            return table

        for i, drone in enumerate(drones, 1):
            # Decoded fields come over the air; never let them act as rich markup
            uas_id = escape(drone.uas_id) if drone.uas_id else "-"
            ua_type = escape(drone.basic_id.ua_type_name) if drone.basic_id else "-"

            loc = drone.location
            # Position: last valid fix, so a brief GPS loss keeps the last point
            pos = drone.last_valid_location or loc
            status = _status_markup(loc.status_name if loc else None,
                                    loc.status if loc else None)
            lat = f"{pos.latitude:.6f}" if pos and pos.latitude is not None else "-"
            lon = f"{pos.longitude:.6f}" if pos and pos.longitude is not None else "-"
            alt = _altitude_text(loc)
            spd = (
                f"{loc.speed_horizontal:.1f} m/s"
                if loc and loc.speed_horizontal is not None
                else "-"
            )

            signal = _signal_markup(drone.signal.current)
            last = _last_seen_markup(drone, now)

            warn = " [bold yellow]⚠[/bold yellow]" if drone.anomalies else ""

            row = [
                str(i),
                uas_id + warn,
                escape(drone.mac),
                ua_type,
                status,
                lat,
                lon,
                alt,
                spd,
                signal,
            ]

            if has_observer:
                if pos and pos.latitude is not None and pos.longitude is not None:
                    from odid.output.console import haversine_m

                    dist = haversine_m(
                        self._observer_lat,
                        self._observer_lon,
                        pos.latitude,
                        pos.longitude,
                    )
                    dist_str = f"{dist:.0f}m" if dist < 1000 else f"{dist / 1000:.2f}km"
                else:
                    dist_str = "-"
                row.append(dist_str)

            row.append(str(drone.frame_count))
            row.append(last)

            table.add_row(*row)

        return table

    def __enter__(self) -> "TUIDisplay":
        self._live = Live(
            self,
            console=self._console,
            refresh_per_second=2,
            screen=False,
        )
        self._live.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._live is not None:
            self._live.__exit__(exc_type, exc_val, exc_tb)
            self._live = None
