"""Console output for ODID frames and drone state."""

from contextlib import nullcontext
from datetime import datetime
from typing import Optional

from odid import __version__
from odid.decode.frame import ODIDFrame
from odid.decode.messages import (
    BasicIdMessage,
    LocationMessage,
    AuthMessage,
    SelfIdMessage,
    SystemMessage,
    OperatorIdMessage,
    MessagePack,
)
from odid.track.tracker import DroneState, DroneTracker

WIDTH = 80
SEP = "=" * WIDTH
THIN = "-" * WIDTH

# --- Color support (colorama optional) ---
try:
    from colorama import Fore, Style, init as _colorama_init
    _colorama_init(autoreset=True)
    _COLORS = True
except ImportError:
    _COLORS = False
    class Fore:  # type: ignore
        RED = GREEN = YELLOW = CYAN = MAGENTA = WHITE = RESET = ""
    class Style:  # type: ignore
        BRIGHT = DIM = RESET_ALL = ""


def _c(text: str, *codes: str) -> str:
    """Wrap text in ANSI codes (no-op if colorama unavailable)."""
    if not _COLORS:
        return text
    return "".join(codes) + text + Style.RESET_ALL


def _signal_color(dbm: Optional[int]) -> str:
    """Return color string for a signal strength value."""
    if dbm is None:
        return Fore.WHITE
    if dbm >= -60:
        return Fore.GREEN
    if dbm >= -75:
        return Fore.YELLOW
    return Fore.RED


# F3411 flight status codes: 1 ground, 2 airborne, 3 emergency,
# 4 Remote ID system failure
_STATUS_ALERT = (3, 4)


def _status_color(status_name: str, status: Optional[int] = None) -> str:
    """Return color for flight status (numeric code preferred, name as fallback)."""
    s = (status_name or "").lower()
    if status in _STATUS_ALERT or "emergency" in s or "failure" in s:
        return Fore.MAGENTA + Style.BRIGHT
    if status == 2 or "airborne" in s:
        return Fore.RED + Style.BRIGHT
    if status == 1 or "ground" in s:
        return Fore.GREEN
    return Fore.WHITE


def print_banner(interface: str, mode: str, channel: Optional[int] = None):
    """Print startup banner."""
    print(f"""
{SEP}
  OpenDroneID Sniffer & Decoder v{__version__}
  ASTM F3411 Compliant
{SEP}

  Interface : {interface}
  Mode      : {mode}
  Channel   : {channel or 'scanning'}
  Started   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

  Listening for OpenDroneID frames (WiFi NAN + Beacon)...
  Press Ctrl+C to stop
{SEP}
""")


def print_frame(
    frame: ODIDFrame,
    drone: Optional[DroneState] = None,
    observer_lat: Optional[float] = None,
    observer_lon: Optional[float] = None,
):
    """Print a single decoded ODID frame to console.

    ``drone`` may be a live DroneState shared with capture threads: the
    fields printed are read under its tracker's lock (when it has one) so
    they are consistent and no dict is iterated while another thread
    changes it.
    """
    when = frame.timestamp.astimezone() if frame.timestamp is not None else datetime.now()
    ts = when.strftime("%H:%M:%S.%f")[:-3]

    dbm = frame.signal_dbm
    signal_str = f"{dbm} dBm" if dbm is not None else "N/A"
    signal_colored = _c(signal_str, _signal_color(dbm))
    ch_str = f"ch{frame.channel}" if frame.channel else "?"

    snap = _drone_snapshot(drone) if drone is not None else None
    is_new = snap is not None and snap["frame_count"] == 1
    new_tag = _c(" [NEW]", Fore.CYAN + Style.BRIGHT) if is_new else ""

    print(f"\n{SEP}")
    print(f"[{ts}] ODID Frame [{frame.frame_type}] {ch_str}{new_tag}")
    print(f"  MAC: {frame.source_mac}  Signal: {signal_colored}  Counter: {frame.message_counter}")

    if snap is not None:
        id_str = snap["uas_id"] or ""
        print(f"  UAS ID: {id_str}  Frames: {snap['frame_count']}  Duration: {snap['duration']:.0f}s")

        # Distance from observer
        lat, lon = snap["lat"], snap["lon"]
        if observer_lat is not None and observer_lon is not None:
            if lat is not None and lon is not None:
                dist = haversine_m(observer_lat, observer_lon, lat, lon)
                dist_str = f"{dist:.0f}m" if dist < 1000 else f"{dist/1000:.2f}km"
                print(f"  Distance: {_c(dist_str, Fore.CYAN)}")

        # Anomaly warnings
        for warn in snap["anomalies"]:
            print(_c(f"  [WARN] {warn}", Fore.YELLOW + Style.BRIGHT))

    print(THIN)

    for msg in frame.messages:
        _print_message(msg)

    print(SEP)


def _drone_snapshot(drone: DroneState) -> dict:
    """Copy the DroneState fields print_frame shows, under the tracker lock."""
    lock = getattr(drone, "_tracker_lock", None) or nullcontext()
    with lock:
        pos = drone.last_valid_location or drone.location
        return {
            "uas_id": drone.uas_id,
            "frame_count": drone.frame_count,
            "duration": drone.duration_seconds,
            "lat": getattr(pos, "latitude", None) if pos else None,
            "lon": getattr(pos, "longitude", None) if pos else None,
            "anomalies": drone.anomaly_list if drone.anomalies else [],
        }


def _print_message(msg, indent: int = 2):
    """Print a decoded message."""
    pad = " " * indent

    if isinstance(msg, BasicIdMessage):
        print(f"{pad}[Basic ID]")
        print(f"{pad}  ID Type  : {msg.id_type_name}")
        print(f"{pad}  UA Type  : {msg.ua_type_name}")
        print(f"{pad}  UAS ID   : {msg.uas_id}")

    elif isinstance(msg, LocationMessage):
        status_str = _c(msg.status_name, _status_color(msg.status_name, msg.status))
        print(f"{pad}[Location]")
        print(f"{pad}  Status   : {status_str}")
        if msg.latitude is not None and msg.longitude is not None:
            print(f"{pad}  Lat/Lon  : {msg.latitude:.7f}, {msg.longitude:.7f}")
        else:
            print(f"{pad}  Lat/Lon  : N/A")
        print(f"{pad}  Alt Baro : {_fmt_m(msg.altitude_msl)}")
        print(f"{pad}  Alt Geo  : {_fmt_m(getattr(msg, 'altitude_geo', None))}")
        print(f"{pad}  Height   : {_fmt_m(msg.height_agl)} ({msg.height_type_name})")
        print(f"{pad}  Heading  : {_fmt_deg(msg.direction_deg)}")
        print(f"{pad}  Speed H  : {_fmt_ms(msg.speed_horizontal)}")
        print(f"{pad}  Speed V  : {_fmt_ms(msg.speed_vertical)}")
        if msg.timestamp is not None:
            print(f"{pad}  TS(hour) : {msg.timestamp:.1f}s")

    elif isinstance(msg, AuthMessage):
        print(f"{pad}[Auth]")
        print(f"{pad}  Type     : {msg.auth_type_name}")
        print(f"{pad}  Page     : {msg.page_number}/{msg.last_page_index}")
        print(f"{pad}  Length   : {msg.length} bytes")
        if msg.auth_data:
            print(f"{pad}  Data     : {msg.auth_data[:16].hex()}...")

    elif isinstance(msg, SelfIdMessage):
        print(f"{pad}[Self-ID]")
        print(f"{pad}  Type     : {msg.desc_type_name}")
        print(f"{pad}  Text     : {msg.description}")

    elif isinstance(msg, SystemMessage):
        print(f"{pad}[System]")
        print(f"{pad}  Op Loc   : {msg.operator_location_type_name}")
        if msg.operator_latitude is not None and msg.operator_longitude is not None:
            print(f"{pad}  Op Pos   : {msg.operator_latitude:.7f}, {msg.operator_longitude:.7f}")
        if msg.operator_altitude is not None:
            print(f"{pad}  Op Alt   : {msg.operator_altitude:.1f}m")
        print(f"{pad}  Area     : radius={_fmt_m(msg.area_radius)} "
              f"ceil={_fmt_m(msg.area_ceiling)} floor={_fmt_m(msg.area_floor)}")
        print(f"{pad}  Count    : {msg.area_count}")

    elif isinstance(msg, OperatorIdMessage):
        print(f"{pad}[Operator ID]")
        print(f"{pad}  ID       : {msg.operator_id}")

    elif isinstance(msg, MessagePack):
        print(f"{pad}[Message Pack] ({msg.message_count} messages, {msg.single_message_size}B each)")
        for sub in msg.messages:
            _print_message(sub, indent + 2)


def print_summary(tracker: DroneTracker, packet_counts: dict[int | str, int] | None = None):
    """Print session summary."""
    print(f"\n\n{SEP}")
    print("SESSION SUMMARY")
    print(SEP)

    stats = tracker.get_stats()
    print(f"\n  Drones detected : {stats['total_drones']}")
    print(f"  Total frames    : {stats['total_frames']}")

    drones = tracker.drones  # snapshot
    for mac, drone in drones.items():
        print(f"\n  {THIN}")
        print(f"  MAC      : {mac}")
        if drone.uas_id:
            print(f"  UAS ID   : {drone.uas_id}")
        if drone.basic_id:
            print(f"  UA Type  : {drone.basic_id.ua_type_name}")
        print(f"  Frames   : {drone.frame_count}")
        print(f"  Duration : {drone.duration_seconds:.1f}s")
        avg_str = f"avg={drone.signal.average:.0f}" if drone.signal.average is not None else "avg=N/A"
        print(f"  Signal   : {drone.signal.current} dBm "
              f"(min={drone.signal.min_dbm}, max={drone.signal.max_dbm}, {avg_str})")
        print(f"  Channels : {sorted(drone.channels_seen)}")
        print(f"  Types    : {sorted(drone.frame_types_seen)}")

        pos = drone.last_valid_location
        if pos is not None:
            print(f"  Last Pos : {pos.latitude:.7f}, {pos.longitude:.7f}")
            print(f"  Last Alt : {_fmt_m(pos.altitude_msl)} baro, "
                  f"{_fmt_m(getattr(pos, 'altitude_geo', None))} geo, "
                  f"{_fmt_m(pos.height_agl)} height ({pos.height_type_name})")
        elif drone.location:
            print("  Last Pos : N/A (no valid fix)")

        if drone.operator_id:
            print(f"  Operator : {drone.operator_id.operator_id}")

        if drone.anomalies:
            print(_c(f"  Warnings : {'; '.join(drone.anomaly_list)}", Fore.YELLOW))

    if not drones:
        print("\n  No drones detected.")
        print("\n  Possible reasons:")
        print("    - No drones nearby with Remote ID enabled")
        print("    - Drone using Bluetooth Remote ID (not WiFi)")
        print("    - DJI drone not in flight-ready mode")
        print("    - Adapter issue (check with: iw dev)")

    if packet_counts:
        print(f"\n  {THIN}")
        print("  Channel Activity:")
        # Keys are channel numbers, or labels (e.g. "BT") for sources without one
        for ch in sorted(packet_counts, key=lambda k: (not isinstance(k, int), str(k))):
            count = packet_counts[ch]
            marker = " *" if ch == 6 else ""
            bar = "#" * min(50, count // 10)
            label = f"Ch {ch:2d}" if isinstance(ch, int) else f"{ch:>5}"
            print(f"    {label}{marker}: {count:6d}  {bar}")

    print(f"\n{SEP}\n")


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return distance in metres between two WGS-84 coordinates."""
    import math
    R = 6_371_000.0  # Earth radius metres
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _fmt_m(val) -> str:
    return f"{val:.1f}m" if val is not None else "N/A"

def _fmt_ms(val) -> str:
    return f"{val:.2f} m/s" if val is not None else "N/A"

def _fmt_deg(val) -> str:
    return f"{val:.1f} deg" if val is not None else "N/A"
