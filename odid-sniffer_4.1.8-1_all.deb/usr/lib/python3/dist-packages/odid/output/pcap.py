"""pcapng export for Wireshark analysis.

Writes raw 802.11 frames to pcapng so you can open them in Wireshark
with full dissection (RadioTap + 802.11 + Action/Beacon + ODID payload).
"""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from scapy.layers.dot11 import RadioTap
from scapy.utils import PcapWriter

log = logging.getLogger(__name__)


class PcapExporter:
    """Writes raw packets to pcap/pcapng file.

    Only ODID frames are written (not all traffic), keeping files small.
    Open the output in Wireshark for full protocol dissection.
    """

    def __init__(self, output_dir: str | Path = "logs", linktype: int = 127,
                 session_ts: Optional[str] = None):
        """Initialize pcap writer.

        Args:
            output_dir: Directory for output files.
            linktype: pcap link type. 127 = IEEE 802.11 with RadioTap.
            session_ts: Session timestamp (%Y%m%d_%H%M%S) for the file name;
                defaults to now.
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.linktype = linktype

        ts = session_ts or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.pcap_file = self.output_dir / f"odid_capture_{ts}.pcap"
        # sync=False: we manage flushing ourselves in 64 KB batches,
        # which is critical for SD card performance on Raspberry Pi.
        self._writer = PcapWriter(str(self.pcap_file), linktype=linktype, sync=False)
        self._count = 0
        self._buffer_bytes = 0
        self._FLUSH_THRESHOLD = 65536  # 64 KB
        # Also flush at least this often, so a hard kill (SIGKILL, power
        # loss) loses only a bounded window of packets.
        self._FLUSH_INTERVAL_SECS = 2.0
        self._last_flush = time.monotonic()
        log.info("pcap output: %s", self.pcap_file)

    def write_packet(self, pkt):
        """Write a raw scapy packet, flushing every 64 KB or every ~2 s."""
        if self._writer is None:
            return
        if self.linktype == 127 and not pkt.haslayer(RadioTap):
            # Bare 802.11 (e.g. from the SDR receiver): the file is declared
            # as RadioTap, so give it a minimal RadioTap header.
            wrapped = RadioTap() / pkt
            wrapped.time = getattr(pkt, "time", wrapped.time)
            pkt = wrapped
        self._writer.write(pkt)
        self._count += 1
        try:
            self._buffer_bytes += len(bytes(pkt))
        except Exception:
            self._buffer_bytes += 256  # conservative estimate on serialisation error
        if (self._buffer_bytes >= self._FLUSH_THRESHOLD
                or time.monotonic() - self._last_flush >= self._FLUSH_INTERVAL_SECS):
            self._flush()

    def _flush(self):
        self._writer.flush()
        self._buffer_bytes = 0
        self._last_flush = time.monotonic()
        log.debug("pcap flushed at %d packets", self._count)

    def flush_if_due(self, force: bool = False) -> bool:
        """Flush buffered packets if the flush interval has passed (or ``force``).

        For idle ticks, so the tail is written even when packets stop arriving.
        Returns True if a flush happened.
        """
        if self._writer is None or self._buffer_bytes == 0:
            return False
        if not force and time.monotonic() - self._last_flush < self._FLUSH_INTERVAL_SECS:
            return False
        self._flush()
        return True

    @property
    def packet_count(self) -> int:
        return self._count

    def close(self):
        if self._writer:
            self._writer.close()
            self._writer = None
            log.info("pcap closed: %s (%d packets)", self.pcap_file, self._count)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
