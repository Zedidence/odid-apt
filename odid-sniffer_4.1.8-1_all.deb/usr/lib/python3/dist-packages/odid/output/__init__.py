"""Output backends - console, JSONL, pcap, CSV."""
