#!/usr/bin/env python3
"""GNU Radio flowgraph: Bluetooth LE ODID capture via BladeRF.

Demodulates BLE legacy advertising packets from the BladeRF, filters for
ODID service data (UUID 0xFFFA, app code 0x0D), and emits the service data
payload bytes over a ZMQ PUSH socket.  Run this alongside `odid bladerf`.

Receive chain
-------------
    BladeRF (2 MSPS) -> quadrature demod (GFSK, 250 kHz deviation)
      -> M&M clock recovery (2 samples/symbol) -> binary slicer
      -> _BLECorrelatorSink: numpy access-address search, dewhitening,
         CRC-24 check (flowgraphs/ble_dsp.py) -> ZMQ PUSH

Limitations: only BT4 *legacy* advertising on the primary channels is
decoded.  BT5 Long Range / extended advertising (AUX_ADV_IND on secondary
channels, Coded PHY) is not supported.

Dependencies
------------
    sudo apt install gnuradio gr-osmosdr
    pip install pyzmq

Usage
-----
    python flowgraphs/odid_bt_bladerf.py [--gain 40] [--device SERIAL] \\
           [--zmq tcp://127.0.0.1:5556] [--dwell 0.5 | --channel 37]
           [--no-monitor] [--iq-dir DIR] [--control-stdin]

    # Offline: replay an IQ recording (SigMF, 2 MS/s, one adv channel)
    python flowgraphs/odid_bt_bladerf.py --iq-file REC.sigmf-meta --stats 60

The signal monitor, IQ recording (needs --channel) and live gain work as in
odid_wifi_bladerf.py; see sdr_monitor.py.

Channel hopping
---------------
BT LE uses three fixed advertising channels:
    Ch 37 -> 2402 MHz
    Ch 38 -> 2426 MHz
    Ch 39 -> 2480 MHz

Each advertising event is sent on all three, so a single channel
(``--channel 37``) already sees every legacy advertiser.  By default the
flowgraph hops every --dwell seconds (default 0.5 s); bits still buffered
from the previous channel fail the CRC after a hop and are dropped.

ZMQ message format
------------------
JSON UTF-8:
    {"source": "bt", "mac": "aa:bb:cc:dd:ee:ff",
     "rssi": null, "payload": "<hex-encoded service data starting at 0x0D>"}

Messages with a ``kind`` key (monitor, record, gain, control_error) are not
frames; see sdr_monitor.py.
"""

import argparse
import json
import math
import os
import re
import signal
import sys
import threading
import traceback

import numpy

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ble_dsp  # noqa: E402  (pure numpy helpers, unit-tested)
import sdr_monitor  # noqa: E402  (spectrum/level monitor, IQ recorder, control)

# ---------------------------------------------------------------------------
# Dependency checks
# ---------------------------------------------------------------------------

try:
    import zmq
except ImportError:
    sys.exit("ERROR: pyzmq not installed.  Run: pip install pyzmq")

try:
    from gnuradio import gr, analog, digital
except ImportError:
    sys.exit("ERROR: gnuradio not installed.  Run: sudo apt install gnuradio")

# ---------------------------------------------------------------------------
# BT LE advertising channel -> centre frequency map
# ---------------------------------------------------------------------------

BT_ADV_CHANNELS = {
    37: 2402,  # MHz
    38: 2426,
    39: 2480,
}
BT_CHANNELS = sorted(BT_ADV_CHANNELS.keys())

SAMPLE_RATE = 2e6    # 2 MSPS, 2 samples/symbol for 1 Msym/s BT LE
BT_SYMBOL_RATE = 1e6
BT_FREQ_DEV = 250e3  # GFSK modulation index 0.5 -> +/-250 kHz

# Backwards-compatible names
_parse_ble_adv_pdu = ble_dsp.parse_adv_pdu


GAIN_MIN, GAIN_MAX = 0, 71      # BladeRF 2.0 RX gain range (dB)
MAX_HOP_FAILURES = 5            # consecutive failed hops before giving up


# gain_arg / run_hopper mirror odid_wifi_bladerf.py (not imported from there:
# that module exits when gr-ieee802-11 is missing, which BT doesn't need).
def gain_arg(value: str) -> int:
    """argparse type: BladeRF RX gain in dB, 0-71."""
    try:
        gain = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid gain {value!r} (integer dB)")
    if not GAIN_MIN <= gain <= GAIN_MAX:
        raise argparse.ArgumentTypeError(
            f"gain {gain} out of range ({GAIN_MIN}-{GAIN_MAX} dB)")
    return gain


def run_hopper(step, dwell: float, stop: threading.Event, name: str,
               on_fatal=None) -> None:
    """Call ``step()`` every ``dwell`` seconds until ``stop`` is set.

    Error policy: a failing hop is logged to stderr (with traceback) and the
    hopper continues.  After MAX_HOP_FAILURES consecutive failures it calls
    ``on_fatal()`` and returns; main() then exits non-zero so SourceManager's
    watchdog reports the failure.
    """
    failures = 0
    while not stop.is_set():
        try:
            step()
            failures = 0
        except Exception:
            failures += 1
            print(f"[{name}] channel hop failed ({failures}/{MAX_HOP_FAILURES}):",
                  file=sys.stderr, flush=True)
            traceback.print_exc()
            if failures >= MAX_HOP_FAILURES:
                print(f"[{name}] ERROR: channel hopping keeps failing; stopping",
                      file=sys.stderr, flush=True)
                if on_fatal is not None:
                    on_fatal()
                return
        stop.wait(dwell)


def osmosdr_args(device: str) -> str:
    """Build the gr-osmosdr device string for a BladeRF (optional serial)."""
    device = (device or "").strip()
    if not device:
        return "bladerf=0"
    if not re.fullmatch(r"[0-9A-Fa-f]{1,32}", device):
        raise ValueError("--device must be a BladeRF serial number (hex digits)")
    return f"bladerf={device}"


# ---------------------------------------------------------------------------
# GNU Radio BLE correlator / framer
# ---------------------------------------------------------------------------

class _BLECorrelatorSink(gr.sync_block):
    """Finds BLE advertising packets in a demodulated bit stream and pushes
    ODID service data to the ZMQ PUSH socket.

    Input: uint8 stream, one bit per byte (0 or 1) from binary_slicer_fb.
    The heavy lifting (vectorised access-address search, dewhitening,
    CRC-24) is in :class:`ble_dsp.BLEFramer`.
    """

    def __init__(self, zmq_push_sock, channel: int = 37):
        gr.sync_block.__init__(
            self, name="BLE Correlator Sink",
            in_sig=[numpy.uint8],
            out_sig=[],
        )
        self._sock = zmq_push_sock
        self._framer = ble_dsp.BLEFramer(channel=channel)
        self._pending_channel = None   # set by set_channel(), applied in work()
        self._ch_lock = threading.Lock()
        self.packets = 0

    def set_channel(self, ch: int) -> None:
        # Called from the hopper thread; work() applies it to avoid races.
        with self._ch_lock:
            self._pending_channel = ch

    def _take_pending_channel(self):
        """Atomically fetch and clear the pending channel (None if none)."""
        with self._ch_lock:
            ch, self._pending_channel = self._pending_channel, None
        return ch

    def work(self, input_items, output_items):
        ch = self._take_pending_channel()
        if ch is not None:
            self._framer.set_channel(ch)
        for pdu in self._framer.feed(input_items[0]):
            result = ble_dsp.parse_adv_pdu(pdu)
            if result is None:
                continue
            mac, svc_data = result
            self.packets += 1
            envelope = {"source": "bt", "mac": mac, "rssi": None,
                        "payload": svc_data.hex()}
            try:
                self._sock.send(json.dumps(envelope).encode(), zmq.NOBLOCK)
            except zmq.Again:
                pass
        return len(input_items[0])


# ---------------------------------------------------------------------------
# Flowgraph
# ---------------------------------------------------------------------------

class ODIDBTFlowgraph(gr.top_block):
    """BLE advertising receiver.

    ``source`` may be any complex-stream block (tests pass a vector source,
    --iq-file a recording); by default a BladeRF is opened through
    gr-osmosdr.  ``monitor`` / ``record`` add the sdr_monitor tap.
    """

    def __init__(self, gain: int, zmq_addr: str, device: str = "",
                 channel: int = 37, source=None, monitor: bool = False,
                 record: bool = False):
        super().__init__("ODID BT BladeRF")
        self._zmq_ctx = None
        self._zmq_sock = None
        self.sender = None
        self._current_channel = channel
        self.gain = gain

        # Open the SDR *before* binding ZMQ so a missing/busy device leaks nothing.
        if source is None:
            try:
                import osmosdr
            except ImportError:
                sys.exit("ERROR: gr-osmosdr not installed.  Run: sudo apt install gr-osmosdr")
            source = osmosdr.source(args=osmosdr_args(device))
            source.set_sample_rate(SAMPLE_RATE)
            source.set_center_freq(BT_ADV_CHANNELS[channel] * 1e6)
            source.set_freq_corr(0)
            source.set_gain_mode(False)
            source.set_gain(gain)
            source.set_bandwidth(1.5e6)
            self._tunable = source
        else:
            self._tunable = None
        self.src = source

        try:
            self._zmq_ctx = zmq.Context()
            self._zmq_sock = self._zmq_ctx.socket(zmq.PUSH)
            self._zmq_sock.setsockopt(zmq.LINGER, 0)
            self._zmq_sock.bind(zmq_addr)
            self.sender = sdr_monitor.LockedSender(self._zmq_sock)
            self._build_chain(channel)
            self.tap = None
            if monitor or record:
                self.tap = sdr_monitor.SdrTap(SAMPLE_RATE, record=record)
                self.connect(self.src, self.tap)
        except BaseException:
            self.close_zmq()
            raise

    def _build_chain(self, channel: int) -> None:
        # GFSK demodulator: output = phase difference scaled to +/-1 at +/-fdev
        self.demod = analog.quadrature_demod_cf(SAMPLE_RATE / (2 * math.pi * BT_FREQ_DEV))

        # Clock recovery (2 samples/symbol)
        omega = SAMPLE_RATE / BT_SYMBOL_RATE
        gain_mu = 0.175
        self.clock_recovery = digital.clock_recovery_mm_ff(
            omega, 0.25 * gain_mu * gain_mu, 0.5, gain_mu, 0.005
        )
        self.slicer = digital.binary_slicer_fb()
        self.correlator = _BLECorrelatorSink(self.sender, channel)

        self.connect(self.src, self.demod, self.clock_recovery,
                     self.slicer, self.correlator)

    def set_channel(self, channel: int) -> None:
        self._current_channel = channel
        if self._tunable is not None:
            self._tunable.set_center_freq(BT_ADV_CHANNELS[channel] * 1e6)
        self.correlator.set_channel(channel)

    def set_gain(self, gain: int) -> None:
        self._tunable.set_gain(gain)
        self.gain = gain

    def close_zmq(self) -> None:
        for obj, close in ((self._zmq_sock, lambda o: o.close(0)),
                           (self._zmq_ctx, lambda o: o.term())):
            if obj is not None:
                try:
                    close(obj)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Channel hopper
# ---------------------------------------------------------------------------

def _channel_hopper(fg: ODIDBTFlowgraph, dwell: float, stop: threading.Event,
                    on_fatal=None) -> None:
    """Rotate through the advertising channels (see run_hopper)."""
    idx = [0]

    def _step():
        ch = BT_CHANNELS[idx[0] % len(BT_CHANNELS)]
        idx[0] += 1
        fg.set_channel(ch)

    run_hopper(_step, dwell, stop, "odid_bt_bladerf", on_fatal)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--gain", type=gain_arg, default=40,
                   help="BladeRF RX gain in dB (0-71, default: 40)")
    p.add_argument("--device", default="", metavar="SERIAL",
                   help="BladeRF serial number (default: first BladeRF found)")
    p.add_argument("--zmq", default="tcp://127.0.0.1:5556", metavar="ADDR",
                   help="ZMQ PUSH bind address (default: tcp://127.0.0.1:5556)")
    p.add_argument("--dwell", type=float, default=0.5, metavar="SECS",
                   help="Seconds per BT advertising channel when hopping (default: 0.5)")
    p.add_argument("--channel", type=int, choices=BT_CHANNELS, default=None,
                   help="Stay on one advertising channel instead of hopping")
    p.add_argument("--stats", type=float, default=0.0, metavar="SECS",
                   help="Print receiver counters every SECS seconds (0=off). Any BLE advertiser "
                        "(phones, earbuds) counts as 'crc_ok', so this verifies the demodulator "
                        "without an ODID transmitter.")
    sdr_monitor.add_cli_args(p)
    return p.parse_args()


def _stats_printer(fg: "ODIDBTFlowgraph", every: float, stop: threading.Event) -> None:
    framer = fg.correlator._framer
    prev = (0, 0, 0, 0)
    while not stop.wait(every):
        cur = (framer.aa_hits, framer.crc_ok, framer.crc_failures, fg.correlator.packets)
        d = [c - p for c, p in zip(cur, prev)]
        prev = cur
        print(f"[odid_bt_bladerf] stats ch{fg._current_channel}: aa_hits={d[0]} crc_ok={d[1]} "
              f"crc_fail={d[2]} odid={d[3]}  (totals: crc_ok={cur[1]} odid={cur[3]})", flush=True)


def main() -> None:
    args = _parse_args()
    try:
        osmosdr_args(args.device)
    except ValueError as e:
        sys.exit(f"ERROR: {e}")

    replay = None
    if args.iq_file:
        try:
            replay, rate, rec_freq = sdr_monitor.iq_file_source(args.iq_file, args.realtime)
        except (ValueError, OSError) as e:
            sys.exit(f"ERROR: --iq-file: {e}")
        if abs(rate - SAMPLE_RATE) > 1:
            sys.exit(f"ERROR: --iq-file was recorded at {rate / 1e6:g} MS/s; "
                     f"this receiver needs {SAMPLE_RATE / 1e6:g} MS/s")
        ch = next((c for c, f in BT_ADV_CHANNELS.items()
                   if rec_freq is not None and abs(f * 1e6 - rec_freq) < 1e5), None)
        if ch is None:
            sys.exit("ERROR: --iq-file was not recorded on a BT advertising channel")
        args.channel = ch          # no hopping while replaying

    start_ch = args.channel or 37
    fg = ODIDBTFlowgraph(gain=args.gain, zmq_addr=args.zmq, device=args.device,
                         channel=start_ch, source=replay, monitor=not args.no_monitor,
                         record=bool(args.iq_dir) and replay is None)
    stop = threading.Event()
    hop_failed = threading.Event()

    def _on_sigterm(signum, frame):
        stop.set()
        fg.stop()

    def _on_hop_fatal():
        hop_failed.set()
        stop.set()
        fg.stop()

    signal.signal(signal.SIGTERM, _on_sigterm)

    if args.channel is None:
        threading.Thread(target=_channel_hopper,
                         args=(fg, max(args.dwell, 0.01), stop, _on_hop_fatal),
                         daemon=True).start()

    if args.stats > 0:
        threading.Thread(target=_stats_printer, args=(fg, args.stats, stop), daemon=True).start()

    recorder = sdr_monitor.start_services(
        tap=fg.tap, sender=fg.sender, source="bladerf-bt", sample_rate=SAMPLE_RATE,
        freq_hz=lambda: BT_ADV_CHANNELS[fg._current_channel] * 1e6,
        gain_db=lambda: None if replay is not None else fg.gain,
        set_gain=None if replay is not None else fg.set_gain,
        gain_range=(GAIN_MIN, GAIN_MAX), iq_dir=args.iq_dir or None,
        control_stdin=args.control_stdin, stop=stop, hopping=args.channel is None,
        extra_info=lambda: {"channel": fg._current_channel},
        log_name="odid_bt_bladerf")

    fg.start()
    where = f"channel {args.channel}" if args.channel else "adv channels 37/38/39"
    print(f"[odid_bt_bladerf] Listening on {where}, ZMQ push at {args.zmq}", flush=True)
    print("[odid_bt_bladerf] Press Ctrl+C to stop", flush=True)
    try:
        fg.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if recorder is not None:
            recorder.close()
        stop.set()
        fg.stop()
        fg.wait()
        if args.stats > 0:
            framer = fg.correlator._framer
            print(f"[odid_bt_bladerf] totals: crc_ok={framer.crc_ok} "
                  f"odid={fg.correlator.packets}", flush=True)
        fg.close_zmq()
        print("[odid_bt_bladerf] Stopped", flush=True)
    if hop_failed.is_set():
        sys.exit("ERROR: channel hopping failed repeatedly (see errors above)")


if __name__ == "__main__":
    main()
