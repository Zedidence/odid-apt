"""Signal monitor, IQ recorder and stdin control for the BladeRF flowgraphs.

Shared by ``odid_wifi_bladerf.py`` and ``odid_bt_bladerf.py``.  Three parts:

Monitor (spectrum + level)
    A subsampled copy of the IQ stream goes through a windowed FFT.  Every
    PUBLISH_SECS the flowgraph sends one ``{"kind": "monitor"}`` message on
    its ZMQ socket with the average and peak-hold spectrum (dBFS per bin),
    the peak sample level, the mean power and the fraction of clipped
    samples.  The dashboard draws the waterfall and the level/clipping
    indicator from it.  The peak-hold spectrum keeps short bursts visible
    (an ODID NAN frame lasts ~0.2 ms).  Only 1 vector in ``keep`` is
    analysed (about PROBE_RATE samples/s) so the cost stays small next to
    the decoder; persistent clipping still shows up statistically.
    Measured on the Pi 5 (BT flowgraph): the Python probe block cost ~32% of
    a core at 0.5 MS/s, mostly per-call overhead (~300 calls/s of ~6
    vectors).  Vectors are now packed PACK_CALLS_PER_S-fold in C++ first
    (~30 calls/s of 64 vectors): +12%.  scipy's complex64 FFT is used when
    available.

IQ recorder
    Records the raw stream as SigMF (``.sigmf-data`` + ``.sigmf-meta``),
    interleaved int16 (``ci16_le``, BladeRF full scale = 2048), for offline
    tuning and replay (``--iq-file``).  The write branch sits behind a
    disabled ``copy`` block, so it costs almost nothing while idle.

Control
    With ``--control-stdin`` the flowgraph reads one JSON command per line
    from stdin (SourceManager writes them):
        {"cmd": "record", "seconds": 5}
        {"cmd": "record_stop"}
        {"cmd": "gain", "db": 30}
    Results come back on the ZMQ socket as ``{"kind": "record", ...}`` /
    ``{"kind": "gain", ...}`` messages.

The DSP and SigMF helpers are plain numpy (tested without GNU Radio).
"""

from __future__ import annotations

import json
import math
import os
import shutil
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

import numpy as np

try:                         # complex64 FFT, ~2.5x faster than numpy's complex128 one
    from scipy.fft import fft as _fft
except ImportError:
    _fft = np.fft.fft

FFT_SIZE = 256
PROBE_RATE = 0.5e6           # samples/s analysed (the rest is skipped)
PACK_CALLS_PER_S = 30        # target Python work() calls per second (see above)
MAX_PACK = 64
PUBLISH_SECS = 0.25          # monitor message period
FULL_SCALE = 2048.0          # BladeRF 12-bit ADC counts per 1.0 in gr-osmosdr
CLIP_LEVEL = 2047.0 / 2048.0  # |I| or |Q| at or above this counts as clipped
FLOOR_DB = -150.0            # stand-in for log10(0)

IQ_DATATYPE = "ci16_le"
IQ_BYTES_PER_SAMPLE = 4
MAX_RECORD_SECS = 60.0
RECORD_FREE_MARGIN = 512 * 2**20   # keep this much disk free after a recording
IQ_FILE_PREFIX = "odid_iq_"
# All branches read one SDR buffer, so when the decoder can't keep up the
# BladeRF drops whole buffers and the recording has the same gaps.  A
# recording missing more than this share of its wall-clock samples is flagged.
GAP_WARN_PCT = 2.0


# ---------------------------------------------------------------------------
# DSP (pure numpy)
# ---------------------------------------------------------------------------

def blackman_harris(n: int) -> np.ndarray:
    """4-term Blackman-Harris window (-92 dB sidelobes)."""
    k = np.arange(n)
    a0, a1, a2, a3 = 0.35875, 0.48829, 0.14128, 0.01168
    x = 2 * np.pi * k / (n - 1)
    return (a0 - a1 * np.cos(x) + a2 * np.cos(2 * x) - a3 * np.cos(3 * x)).astype(np.float32)


def bin_power(vectors: np.ndarray, window: np.ndarray) -> np.ndarray:
    """Per-vector power spectrum, DC centred, normalised so that a complex
    tone of amplitude 1.0 (full scale) on a bin centre reads 1.0 (0 dBFS).

    vectors: (n, FFT_SIZE) complex; returns (n, FFT_SIZE) float.
    """
    spec = _fft(vectors * window, axis=1)
    p = (spec.real ** 2 + spec.imag ** 2) / float(window.sum()) ** 2
    return np.fft.fftshift(p, axes=1)


def to_db(p) -> np.ndarray:
    return 10.0 * np.log10(np.maximum(p, 10 ** (FLOOR_DB / 10)))


def keep_one_in(sample_rate: float, fft_size: int = FFT_SIZE,
                probe_rate: float = PROBE_RATE) -> int:
    """How many FFT vectors to skip per analysed one at ``sample_rate``."""
    return max(1, int(round(sample_rate / probe_rate)))


def pack_size(sample_rate: float, fft_size: int = FFT_SIZE) -> int:
    """Analysed vectors handed to Python per work() call."""
    per_s = sample_rate / fft_size / keep_one_in(sample_rate, fft_size)
    return max(1, min(MAX_PACK, int(round(per_s / PACK_CALLS_PER_S))))


class MonitorAccumulator:
    """Collects spectra and level statistics between two snapshots.

    ``add()`` runs in the GNU Radio work thread, ``snapshot()`` in the
    publisher thread.
    """

    def __init__(self, fft_size: int = FFT_SIZE):
        self.fft_size = fft_size
        self.window = blackman_harris(fft_size)
        self._lock = threading.Lock()
        self._reset()

    def _reset(self) -> None:
        self._sum = np.zeros(self.fft_size)
        self._max = np.zeros(self.fft_size)
        self._vectors = 0
        self._samples = 0
        self._peak = 0.0
        self._power = 0.0
        self._clipped = 0

    def add(self, vectors: np.ndarray) -> None:
        if len(vectors) == 0:
            return
        p = bin_power(vectors, self.window)
        vectors = np.ascontiguousarray(vectors, dtype=np.complex64)
        iq = np.abs(vectors.view(np.float32)).reshape(-1, 2).max(axis=1)   # max(|I|, |Q|)
        clipped = int(np.count_nonzero(iq >= CLIP_LEVEL))
        peak = float(iq.max())
        power = float(np.vdot(vectors, vectors).real)
        psum, pmax = p.sum(axis=0), p.max(axis=0)
        with self._lock:
            self._sum += psum
            np.maximum(self._max, pmax, out=self._max)
            self._vectors += len(vectors)
            self._samples += vectors.size
            self._peak = max(self._peak, peak)
            self._power += power
            self._clipped += clipped

    def snapshot(self) -> Optional[dict]:
        """Statistics since the last snapshot (None if nothing arrived)."""
        with self._lock:
            if not self._vectors:
                return None
            avg = self._sum / self._vectors
            mx, samples = self._max.copy(), self._samples
            peak, power, clipped = self._peak, self._power, self._clipped
            self._reset()
        return {
            "avg": [round(float(v), 1) for v in to_db(avg)],
            "max": [round(float(v), 1) for v in to_db(mx)],
            "peak_dbfs": round(float(to_db(peak ** 2)), 1),
            "mean_dbfs": round(float(to_db(power / samples)), 1),
            "noise_dbfs": round(float(np.median(to_db(avg))), 1),
            "clip_pct": round(100.0 * clipped / samples, 3),
        }


# ---------------------------------------------------------------------------
# SigMF (pure Python)
# ---------------------------------------------------------------------------

def iq_basename(source: str, freq_hz: float, when: Optional[datetime] = None) -> str:
    """``odid_iq_<source>_<YYYYmmdd_HHMMSS>_<MHz>`` (no extension)."""
    when = when or datetime.now(timezone.utc)
    return f"{IQ_FILE_PREFIX}{source}_{when:%Y%m%d_%H%M%S}_{freq_hz / 1e6:.0f}"


def sigmf_meta(sample_rate: float, freq_hz: float, start: datetime, *,
               gain_db=None, source: str = "", description: str = "",
               extra: Optional[dict] = None) -> dict:
    """SigMF 1.0 metadata for a ci16_le recording."""
    glob = {
        "core:datatype": IQ_DATATYPE,
        "core:sample_rate": float(sample_rate),
        "core:version": "1.0.0",
        "core:hw": "Nuand bladeRF 2.0 (gr-osmosdr), full scale 2048",
        "core:recorder": "ODID Sniffer",
        "core:description": description or f"ODID Sniffer {source} IQ recording",
    }
    if gain_db is not None:
        glob["odid:gain_db"] = gain_db
    if source:
        glob["odid:source"] = source
    if extra:
        glob.update(extra)
    return {
        "global": glob,
        "captures": [{
            "core:sample_start": 0,
            "core:frequency": float(freq_hz),
            "core:datetime": start.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        }],
        "annotations": [],
    }


def write_meta(path: Path, meta: dict) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(meta, indent=2) + "\n")
    os.replace(tmp, path)


def resolve_iq_file(path: str) -> tuple[Path, dict]:
    """(data path, metadata) for a ``.sigmf-meta``/``.sigmf-data`` path or base.

    Raises ValueError for a missing file or an unsupported recording.
    """
    p = Path(path)
    base = p.with_suffix("") if p.suffix in (".sigmf-meta", ".sigmf-data") else p
    meta_path, data_path = base.with_suffix(".sigmf-meta"), base.with_suffix(".sigmf-data")
    if not meta_path.is_file() or not data_path.is_file():
        raise ValueError(f"need both {meta_path.name} and {data_path.name}")
    meta = json.loads(meta_path.read_text())
    dtype = meta.get("global", {}).get("core:datatype")
    if dtype != IQ_DATATYPE:
        raise ValueError(f"unsupported SigMF datatype {dtype!r} (expected {IQ_DATATYPE})")
    return data_path, meta


def meta_rate_freq(meta: dict) -> tuple[float, Optional[float]]:
    rate = float(meta["global"]["core:sample_rate"])
    caps = meta.get("captures") or [{}]
    freq = caps[0].get("core:frequency")
    return rate, (float(freq) if freq is not None else None)


# ---------------------------------------------------------------------------
# Thread-safe ZMQ sending
# ---------------------------------------------------------------------------

class LockedSender:
    """Serialises ``send`` on one ZMQ socket (sockets are not thread-safe;
    the frame sink, the monitor publisher and the recorder all send)."""

    def __init__(self, sock):
        self._sock = sock
        self._lock = threading.Lock()

    def send(self, data: bytes, flags: int = 0):
        with self._lock:
            return self._sock.send(data, flags)

    def send_json(self, obj: dict) -> bool:
        """Non-blocking JSON send; False if the consumer is behind."""
        import zmq
        try:
            self.send(json.dumps(obj).encode(), zmq.NOBLOCK)
            return True
        except zmq.Again:
            return False


# ---------------------------------------------------------------------------
# GNU Radio blocks
# ---------------------------------------------------------------------------

try:
    from gnuradio import gr, blocks
except ImportError:          # pure-numpy parts stay importable for tests
    gr = blocks = None


if gr is not None:

    class SpectrumProbe(gr.sync_block):
        """Sink feeding a MonitorAccumulator; each item is ``pack`` FFT vectors."""

        def __init__(self, acc: MonitorAccumulator, pack: int = 1):
            gr.sync_block.__init__(self, name="ODID spectrum probe",
                                   in_sig=[(np.complex64, acc.fft_size * pack)], out_sig=None)
            self.acc = acc

        def work(self, input_items, output_items):
            self.acc.add(input_items[0].reshape(-1, self.acc.fft_size))
            return len(input_items[0])

    class SdrTap(gr.hier_block2):
        """Monitor + recorder branch hung off the SDR source.

            in ─┬─ stream_to_vector(N) ─ keep_one_in_n(k) ─ stream_to_vector(pack) ─ SpectrumProbe
                └─ copy (valve, off) ─ complex_to_interleaved_short ─ file_sink
        """

        def __init__(self, sample_rate: float, fft_size: int = FFT_SIZE,
                     record: bool = True):
            gr.hier_block2.__init__(self, "ODID SDR tap",
                                    gr.io_signature(1, 1, gr.sizeof_gr_complex),
                                    gr.io_signature(0, 0, 0))
            self.acc = MonitorAccumulator(fft_size)
            self.s2v = blocks.stream_to_vector(gr.sizeof_gr_complex, fft_size)
            self.keep = blocks.keep_one_in_n(gr.sizeof_gr_complex * fft_size,
                                             keep_one_in(sample_rate, fft_size))
            pack = pack_size(sample_rate, fft_size)
            self.pack = blocks.stream_to_vector(gr.sizeof_gr_complex * fft_size, pack)
            self.probe = SpectrumProbe(self.acc, pack)
            self.connect(self, self.s2v, self.keep, self.pack, self.probe)
            self.valve = self.file_sink = None
            if record:
                self.valve = blocks.copy(gr.sizeof_gr_complex)
                self.valve.set_enabled(False)
                self.to_short = blocks.complex_to_interleaved_short(False, FULL_SCALE)
                self.file_sink = blocks.file_sink(gr.sizeof_short, os.devnull, False)
                self.file_sink.set_unbuffered(False)
                self.connect(self, self.valve, self.to_short, self.file_sink)

        def recording_supported(self) -> bool:
            return self.file_sink is not None

        def start_writing(self, path: Path) -> None:
            if not self.file_sink.open(str(path)):
                raise OSError(f"cannot open {path}")
            self.valve.set_enabled(True)

        def stop_writing(self) -> None:
            self.valve.set_enabled(False)
            # Let the samples already past the valve reach the file first.
            time.sleep(0.2)
            self.file_sink.close()


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------

class Recorder:
    """Timed SigMF recordings through an SdrTap's write branch.

    ``writer`` needs ``start_writing(path)`` / ``stop_writing()``;
    ``state()`` returns the running recording (or None) for the monitor
    messages, and ``notify(dict)`` reports start/finish/failure.
    """

    def __init__(self, writer, out_dir: Optional[str], source: str,
                 sample_rate: float, freq_hz: Callable[[], float],
                 gain_db: Callable[[], Optional[float]], notify: Callable[[dict], None],
                 clock=time.monotonic):
        self._writer = writer
        self._dir = Path(out_dir) if out_dir else None
        self._source = source
        self._rate = sample_rate
        self._freq = freq_hz
        self._gain = gain_db
        self._notify = notify
        self._clock = clock
        self._lock = threading.Lock()
        self._cur: Optional[dict] = None
        self._stop = threading.Event()

    def bytes_for(self, seconds: float) -> int:
        return int(seconds * self._rate) * IQ_BYTES_PER_SAMPLE

    def state(self) -> Optional[dict]:
        with self._lock:
            cur = self._cur
            if cur is None:
                return None
            return {"file": cur["base"], "seconds": cur["seconds"],
                    "elapsed": round(self._clock() - cur["t0"], 1)}

    def start(self, seconds) -> None:
        """Begin a recording of ``seconds``; reports problems via notify."""
        try:
            seconds = float(seconds)
        except (TypeError, ValueError):
            seconds = float("nan")
        err = None
        if self._writer is None or self._dir is None:
            err = "IQ recording is not enabled for this source"
        elif not (0 < seconds <= MAX_RECORD_SECS) or math.isnan(seconds):
            err = f"recording length must be 0-{MAX_RECORD_SECS:.0f} s"
        if err is None:
            try:
                self._dir.mkdir(parents=True, exist_ok=True)
                free = shutil.disk_usage(self._dir).free
            except OSError as e:
                err, free = f"recording directory unusable: {e}", 0
            need = self.bytes_for(seconds) + RECORD_FREE_MARGIN
            if err is None and free < need:
                err = (f"not enough disk space: {seconds:g} s needs {need / 1e9:.1f} GB "
                       f"(with margin), {free / 1e9:.1f} GB free")
        with self._lock:
            if err is None and self._cur is not None:
                err = "a recording is already running"
            if err is not None:
                self._notify({"kind": "record", "state": "error", "error": err})
                return
            start = datetime.now(timezone.utc)
            freq = self._freq()
            base = iq_basename(self._source, freq, start)
            data_path = self._dir / f"{base}.sigmf-data"
            meta = sigmf_meta(self._rate, freq, start, gain_db=self._gain(),
                              source=self._source)
            try:
                write_meta(self._dir / f"{base}.sigmf-meta", meta)
                self._writer.start_writing(data_path)
            except OSError as e:
                self._notify({"kind": "record", "state": "error",
                              "error": f"could not start recording: {e}"})
                return
            self._stop.clear()
            self._cur = {"base": base, "seconds": seconds, "t0": self._clock(),
                         "data": data_path}
        self._notify({"kind": "record", "state": "started", "file": base, "seconds": seconds})
        threading.Thread(target=self._timer, args=(seconds,), daemon=True,
                         name="odid-iq-record").start()

    def _timer(self, seconds: float) -> None:
        self._stop.wait(seconds)
        self._finish()

    def stop(self) -> None:
        self._stop.set()

    def _finish(self) -> None:
        with self._lock:
            cur, self._cur = self._cur, None
        if cur is None:
            return
        wall = self._clock() - cur["t0"]
        try:
            self._writer.stop_writing()
        except Exception as e:                       # noqa: BLE001 - report, don't die
            self._notify({"kind": "record", "state": "error", "file": cur["base"],
                          "error": f"stopping the recording failed: {e}"})
            return
        try:
            size = cur["data"].stat().st_size
        except OSError:
            size = 0
        samples = size // IQ_BYTES_PER_SAMPLE
        expected = wall * self._rate
        dropped = max(0.0, 100.0 * (1 - samples / expected)) if expected > 0 else 0.0
        msg = {"kind": "record", "state": "done", "file": cur["base"], "bytes": size,
               "seconds": round(samples / self._rate, 2), "wall_seconds": round(wall, 2),
               "dropped_pct": round(dropped, 1)}
        if dropped > GAP_WARN_PCT:
            msg["warning"] = (f"{dropped:.0f}% of the samples were dropped while recording "
                              "(the receiver could not keep up); the recording has gaps")
            # Say so in the SigMF metadata too, for whoever replays it later.
            meta_path = cur["data"].with_suffix(".sigmf-meta")
            try:
                meta = json.loads(meta_path.read_text())
                meta["global"]["odid:dropped_pct"] = msg["dropped_pct"]
                meta["global"]["core:description"] += f" (gaps: {dropped:.0f}% of samples dropped)"
                write_meta(meta_path, meta)
            except (OSError, ValueError, KeyError, TypeError):
                pass
        self._notify(msg)

    def close(self) -> None:
        """Finish a running recording now (flowgraph shutdown)."""
        self._stop.set()
        self._finish()


# ---------------------------------------------------------------------------
# Publisher + stdin control
# ---------------------------------------------------------------------------

def run_publisher(acc: MonitorAccumulator, send: Callable[[dict], bool],
                  info: Callable[[], dict], stop: threading.Event,
                  every: float = PUBLISH_SECS) -> None:
    """Send one monitor message every ``every`` seconds until ``stop``."""
    while not stop.wait(every):
        snap = acc.snapshot()
        if snap is None:
            continue
        msg = {"kind": "monitor", "fft_size": acc.fft_size, **info(), **snap}
        send(msg)


def run_control(handlers: dict, stream=None, on_error=None) -> None:
    """Read JSON command lines from ``stream`` (stdin) until EOF.

    ``handlers`` maps a command name to ``fn(cmd_dict)``.
    """
    stream = stream or sys.stdin
    for line in stream:
        line = line.strip()
        if not line:
            continue
        try:
            cmd = json.loads(line)
            fn = handlers.get(cmd.get("cmd")) if isinstance(cmd, dict) else None
        except ValueError:
            fn, cmd = None, line
        if fn is None:
            if on_error:
                on_error(f"unknown control command: {str(cmd)[:80]}")
            continue
        try:
            fn(cmd)
        except Exception as e:                       # noqa: BLE001 - keep reading
            if on_error:
                on_error(f"control command {cmd.get('cmd')!r} failed: {e}")


def iq_file_source(path: str, throttle: bool):
    """(source block, sample_rate, freq_hz) replaying a ci16_le SigMF file."""
    data_path, meta = resolve_iq_file(path)
    rate, freq = meta_rate_freq(meta)
    src = blocks.file_source(gr.sizeof_short, str(data_path), False)
    conv = blocks.interleaved_short_to_complex(False, False, FULL_SCALE)
    hb = gr.hier_block2("ODID IQ file", gr.io_signature(0, 0, 0),
                        gr.io_signature(1, 1, gr.sizeof_gr_complex))
    if throttle:
        thr = blocks.throttle(gr.sizeof_gr_complex, rate)
        hb.connect(src, conv, thr, hb)
        hb._blocks = (src, conv, thr)
    else:
        hb.connect(src, conv, hb)
        hb._blocks = (src, conv)
    return hb, rate, freq


def start_services(*, tap, sender: LockedSender, source: str, sample_rate: float,
                   freq_hz: Callable[[], float], gain_db: Callable[[], Optional[float]],
                   set_gain: Optional[Callable[[int], None]], gain_range: tuple,
                   iq_dir: Optional[str], control_stdin: bool, stop: threading.Event,
                   hopping: bool = False, extra_info: Callable[[], dict] = dict,
                   log_name: str = "odid") -> Optional[Recorder]:
    """Start the monitor publisher and (optionally) the stdin control reader.

    Returns the Recorder (None when the tap has no write branch, or while
    hopping: a recording has one centre frequency), which main() must
    ``close()`` on shutdown.
    """
    no_record = ("IQ recording needs a fixed channel (channel hopping is on)" if hopping
                 else "IQ recording is not enabled for this source")
    def notify(msg: dict) -> None:
        if msg.get("state") == "error" or msg.get("kind") == "control_error":
            print(f"[{log_name}] {msg.get('error')}", file=sys.stderr, flush=True)
        else:
            print(f"[{log_name}] {msg}", flush=True)
        sender.send_json(msg)

    recorder = None
    if tap is not None and tap.recording_supported() and iq_dir and not hopping:
        recorder = Recorder(tap, iq_dir, source, sample_rate, freq_hz, gain_db, notify)

    if tap is not None:
        def info() -> dict:
            return {"center_hz": freq_hz(), "sample_rate": sample_rate,
                    "gain_db": gain_db(),
                    "recording": recorder.state() if recorder else None,
                    "can_record": recorder is not None,
                    "record_note": None if recorder else no_record, **extra_info()}

        threading.Thread(target=run_publisher, args=(tap.acc, sender.send_json, info, stop),
                         daemon=True, name="odid-monitor").start()

    if control_stdin:
        def _record(cmd):
            if recorder is None:
                notify({"kind": "record", "state": "error", "error": no_record})
            else:
                recorder.start(cmd.get("seconds"))

        def _record_stop(_cmd):
            if recorder is not None:
                recorder.stop()

        def _gain(cmd):
            lo, hi = gain_range
            db = cmd.get("db")
            if set_gain is None:
                err = "gain can't be changed on this source"
            elif isinstance(db, bool) or not isinstance(db, int) or not lo <= db <= hi:
                err = f"gain must be a whole number of dB, {lo}-{hi}"
            else:
                set_gain(db)
                notify({"kind": "gain", "gain_db": db})
                return
            notify({"kind": "control_error", "error": err})

        handlers = {"record": _record, "record_stop": _record_stop, "gain": _gain}
        threading.Thread(
            target=run_control,
            kwargs={"handlers": handlers,
                    "on_error": lambda e: notify({"kind": "control_error", "error": e})},
            daemon=True, name="odid-control").start()
    return recorder


def add_cli_args(p) -> None:
    """argparse options shared by the BladeRF flowgraphs."""
    p.add_argument("--no-monitor", action="store_true",
                   help="Don't compute the spectrum / signal level for the dashboard")
    p.add_argument("--iq-dir", default="", metavar="DIR",
                   help="Directory for IQ recordings (enables the 'record' control command)")
    p.add_argument("--control-stdin", action="store_true",
                   help="Read JSON control commands from stdin (used by odid serve)")
    p.add_argument("--iq-file", default="", metavar="SIGMF",
                   help="Replay a ci16_le SigMF recording instead of opening the BladeRF "
                        "(as fast as possible unless --realtime); exits at end of file")
    p.add_argument("--realtime", action="store_true",
                   help="With --iq-file: replay at the recorded sample rate")
