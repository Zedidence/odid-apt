"""GNU Radio flowgraphs for BladeRF capture.

These are standalone scripts launched as subprocesses by
:class:`odid.capture.manager.SourceManager` (or run by hand); they are not
imported by the ``odid`` package. They live inside the package so a wheel or
.deb install ships them.
"""
