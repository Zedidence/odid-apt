#!/usr/bin/env python3
"""GNU Radio dual-channel flowgraph: WiFi + BT LE on one BladeRF 2.0.

*** DISABLED: kept for reference only ***
=========================================
This design assumed RX0 and RX1 of the bladeRF 2.0 micro can be tuned
independently.  They cannot: the AD9361 has a **single RX LO shared by both
RX channels**, so ``set_center_freq(..., 1)`` for BT also retunes the WiFi
channel (and vice versa).  With the two hoppers running, neither chain stays
on its intended frequency.

`odid serve` marks the "bladerf-dual" source unavailable and this script
refuses to start unless ``--force`` is given (for experiments only).

Ways forward if dual capture is ever needed:
  * Two SDRs: run ``odid_wifi_bladerf.py --device <serial-1>`` and
    ``odid_bt_bladerf.py --device <serial-2>`` side by side.
  * One SDR, one LO: tune the shared LO once (e.g. ~2426 MHz at >= 56 MSPS)
    and select the WiFi and BT channels in DSP with frequency-translating
    FIR filters.  Not implemented (and too heavy for a Pi).

The RX chains below reuse the fixed single-protocol implementations
(``WiFiRxChain`` from odid_wifi_bladerf.py, ``_BLECorrelatorSink`` from
odid_bt_bladerf.py), so they are only wrong because of the shared LO.

Usage (experimental)
--------------------
    python flowgraphs/odid_dual_bladerf.py --force [--wifi-gain 40] [--bt-gain 40]
"""

import argparse
import itertools
import math
import os
import signal
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import zmq
except ImportError:
    sys.exit("ERROR: pyzmq not installed.  Run: pip install pyzmq")

try:
    from gnuradio import gr, analog, digital
    from gnuradio.filter import firdes
    from gnuradio import filter as grfilter
except ImportError:
    sys.exit("ERROR: gnuradio not installed.  Run: sudo apt install gnuradio")

import odid_wifi_bladerf as wifi_fg  # noqa: E402  (exits if gr-ieee802-11 missing)
import odid_bt_bladerf as bt_fg      # noqa: E402

DISABLED_REASON = (
    "Dual mode is disabled: the bladeRF 2.0 (AD9361) shares one RX LO between "
    "RX0 and RX1, so WiFi and BT cannot be tuned independently. Run "
    "odid_wifi_bladerf.py and odid_bt_bladerf.py on two separate SDRs "
    "(--device <serial>) instead."
)

WIFI_SAMPLE_RATE = 20e6
BT_SAMPLE_RATE   = 2e6
BT_SYMBOL_RATE   = 1e6
BT_DECIMATION    = int(WIFI_SAMPLE_RATE / BT_SAMPLE_RATE)  # 10

WIFI_CHANNELS = wifi_fg.CHANNEL_FREQ_MHZ
WIFI_CHANNEL_LIST = list(wifi_fg.CHANNELS)   # hop set 1-11
BT_ADV_CHANNELS = bt_fg.BT_ADV_CHANNELS
BT_CHANNEL_LIST = sorted(BT_ADV_CHANNELS)


class ODIDDualFlowgraph(gr.top_block):
    def __init__(self, wifi_gain: int, bt_gain: int, zmq_wifi: str, zmq_bt: str,
                 device: str = ""):
        super().__init__("ODID Dual BladeRF")
        import osmosdr
        self._zmq_ctx = None
        self._wifi_sock = None
        self._bt_sock = None

        # Open the SDR first; ZMQ is bound only once the device is up.
        self.src = osmosdr.source(args=wifi_fg.osmosdr_args(device) + ",nchan=2")
        self.src.set_sample_rate(WIFI_SAMPLE_RATE)
        for ch in range(2):
            self.src.set_freq_corr(0, ch)
            self.src.set_gain_mode(False, ch)
        self.src.set_center_freq(WIFI_CHANNELS[6] * 1e6, 0)
        self.src.set_gain(wifi_gain, 0)
        self.src.set_bandwidth(20e6, 0)
        self.src.set_center_freq(BT_ADV_CHANNELS[37] * 1e6, 1)   # retunes RX0 too!
        self.src.set_gain(bt_gain, 1)
        self.src.set_bandwidth(1.5e6, 1)

        try:
            self._zmq_ctx = zmq.Context()
            self._wifi_sock = self._zmq_ctx.socket(zmq.PUSH)
            self._wifi_sock.setsockopt(zmq.LINGER, 0)
            self._wifi_sock.bind(zmq_wifi)
            self._bt_sock = self._zmq_ctx.socket(zmq.PUSH)
            self._bt_sock.setsockopt(zmq.LINGER, 0)
            self._bt_sock.bind(zmq_bt)
            self._build_chains()
        except BaseException:
            self.close_zmq()
            raise

    def _build_chains(self) -> None:
        # WiFi (RX0)
        self.wifi_rx = wifi_fg.WiFiRxChain(WIFI_CHANNELS[6] * 1e6, WIFI_SAMPLE_RATE)
        self.wifi_sink = wifi_fg._ODIDSink(self._wifi_sock, channel=6)
        self.connect((self.src, 0), self.wifi_rx)
        self.msg_connect((self.wifi_rx, "out"), (self.wifi_sink, "pdus"))

        # BT LE (RX1): decimate 20 -> 2 MSPS, GFSK demod, framer
        self.bt_lpf = grfilter.fir_filter_ccf(
            BT_DECIMATION, firdes.low_pass(1, WIFI_SAMPLE_RATE, 1e6, 200e3))
        self.bt_demod = analog.quadrature_demod_cf(
            BT_SAMPLE_RATE / (2 * math.pi * bt_fg.BT_FREQ_DEV))
        self.bt_clock = digital.clock_recovery_mm_ff(
            BT_SAMPLE_RATE / BT_SYMBOL_RATE, 0.25 * 0.175 * 0.175, 0.5, 0.175, 0.005)
        self.bt_slicer = digital.binary_slicer_fb()
        self.bt_correlator = bt_fg._BLECorrelatorSink(self._bt_sock, channel=37)
        self.connect((self.src, 1), self.bt_lpf, self.bt_demod, self.bt_clock,
                     self.bt_slicer, self.bt_correlator)

    def set_wifi_channel(self, ch: int) -> None:
        freq_hz = WIFI_CHANNELS[ch] * 1e6
        self.src.set_center_freq(freq_hz, 0)
        self.wifi_rx.set_frequency(freq_hz)
        self.wifi_sink.channel = ch

    def set_bt_channel(self, ch: int) -> None:
        self.src.set_center_freq(BT_ADV_CHANNELS[ch] * 1e6, 1)
        self.bt_correlator.set_channel(ch)

    def close_zmq(self) -> None:
        for sock in (self._wifi_sock, self._bt_sock):
            try:
                if sock is not None:
                    sock.close(0)
            except Exception:
                pass
        try:
            if self._zmq_ctx is not None:
                self._zmq_ctx.term()
        except Exception:
            pass


def _hopper(setter, channels, dwell: float, stop: threading.Event,
            on_fatal=None) -> None:
    """Cycle ``setter`` through ``channels`` (error policy: wifi_fg.run_hopper)."""
    order = itertools.cycle(channels)
    wifi_fg.run_hopper(lambda: setter(next(order)), dwell, stop,
                       "odid_dual_bladerf", on_fatal)


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--force", action="store_true",
                   help="Run anyway despite the shared-LO limitation (experiments only)")
    p.add_argument("--device", default="", metavar="SERIAL",
                   help="BladeRF serial number (default: first BladeRF found)")
    p.add_argument("--wifi-gain", type=wifi_fg.gain_arg, default=40, metavar="dB")
    p.add_argument("--bt-gain", type=wifi_fg.gain_arg, default=40, metavar="dB")
    p.add_argument("--gain", type=wifi_fg.gain_arg, default=None, metavar="dB",
                   help="Set both --wifi-gain and --bt-gain")
    p.add_argument("--zmq", default="tcp://127.0.0.1:5555", metavar="ADDR")
    p.add_argument("--zmq-bt", default="tcp://127.0.0.1:5556", metavar="ADDR")
    p.add_argument("--wifi-dwell", type=float, default=3.0, metavar="SECS")
    p.add_argument("--bt-dwell", type=float, default=0.5, metavar="SECS")
    p.add_argument("--no-wifi-hop", action="store_true")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    if not args.force:
        sys.exit(f"ERROR: {DISABLED_REASON}")

    wifi_gain = args.gain if args.gain is not None else args.wifi_gain
    bt_gain = args.gain if args.gain is not None else args.bt_gain
    fg = ODIDDualFlowgraph(wifi_gain, bt_gain, args.zmq, args.zmq_bt, args.device)
    stop = threading.Event()
    hop_failed = threading.Event()

    def _on_sigterm(signum, frame):
        stop.set()
        fg.stop()

    def _on_hop_fatal():
        hop_failed.set()
        stop.set()
        fg.stop()

    signal.signal(signal.SIGTERM, _on_sigterm)

    if not args.no_wifi_hop:
        threading.Thread(target=_hopper, daemon=True,
                         args=(fg.set_wifi_channel, WIFI_CHANNEL_LIST,
                               max(args.wifi_dwell, 0.05), stop, _on_hop_fatal)).start()
    threading.Thread(target=_hopper, daemon=True,
                     args=(fg.set_bt_channel, BT_CHANNEL_LIST,
                           max(args.bt_dwell, 0.01), stop, _on_hop_fatal)).start()

    fg.start()
    print(f"[odid_dual_bladerf] WARNING: {DISABLED_REASON}", flush=True)
    print(f"[odid_dual_bladerf] RX0 WiFi -> {args.zmq}; RX1 BT LE -> {args.zmq_bt}", flush=True)
    try:
        fg.wait()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        try:
            fg.stop()
            fg.wait()
        finally:
            fg.close_zmq()
        print("[odid_dual_bladerf] Stopped", flush=True)
    if hop_failed.is_set():
        sys.exit("ERROR: channel hopping failed repeatedly (see errors above)")


if __name__ == "__main__":
    main()
