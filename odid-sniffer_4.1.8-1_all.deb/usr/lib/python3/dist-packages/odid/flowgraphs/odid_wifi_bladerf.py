#!/usr/bin/env python3
"""GNU Radio flowgraph: WiFi ODID capture via BladeRF.

Demodulates 802.11a/g OFDM frames from the BladeRF with gr-ieee802-11 and
emits the bare 802.11 MAC frames that look like ODID over a ZMQ PUSH socket.
Run this alongside `odid bladerf`.

Receive chain (mirrors gr-ieee802-11 examples/wifi_phy_hier.grc)
----------------------------------------------------------------
::

    src ─┬─ delay(16) ─┬──────────────────────────────── sync_short[0]
         │             └─ conj ─┐
         ├──────────────────── multiply ─ moving_avg_cc(48) ─┬─ sync_short[1]
         │                                                  └─ |.| ─ divide[0]
         └─ |.|^2 ─ moving_avg_ff(64) ─────────────────────────────── divide[1]
                                                        divide ─ sync_short[2]
    sync_short ─┬───────────── sync_long[0]
                └─ delay(320) ─ sync_long[1]
    sync_long ─ stream_to_vector(64) ─ FFT(64, shift) ─ frame_equalizer
              ─ decode_mac ─(msg)─ _ODIDSink ─ ZMQ PUSH

Limitations
-----------
* OFDM only.  ODID *beacons* in 2.4 GHz are often sent at 1 Mb/s DSSS
  (802.11b), which gr-ieee802-11 cannot demodulate; NAN action frames and
  OFDM-rate beacons are decodable.  A DSSS receiver is deferred (see
  BLADERF.md); use a monitor-mode WiFi dongle for DSSS beacons.
* The decoder is only verified in simulation (tests/test_flowgraphs.py);
  sync threshold / gain need checking against real hardware.

Dependencies
------------
    sudo apt install gnuradio gr-osmosdr
    # gr-ieee802-11 built from source (maint-3.10)
    pip install pyzmq

Usage
-----
    python flowgraphs/odid_wifi_bladerf.py [--freq 2437] [--gain 40] \\
           [--device SERIAL] [--zmq tcp://127.0.0.1:5555] [--dwell 3.0] [--no-hop]
           [--sync-threshold 0.56] [--no-monitor] [--iq-dir DIR] [--control-stdin]

    # Offline: replay an IQ recording (SigMF, 20 MS/s) and count decodes
    python flowgraphs/odid_wifi_bladerf.py --iq-file REC.sigmf-meta --stats 60 \\
           [--sync-threshold 0.5]

Signal monitor, IQ recording, live gain
---------------------------------------
See sdr_monitor.py: a subsampled spectrum / level tap ("monitor" messages
on the ZMQ socket, off with --no-monitor), SigMF IQ recording into --iq-dir
and JSON control commands on stdin (--control-stdin, used by odid serve).
Recording needs a fixed channel (no hopping).

Channel hopping
---------------
The flowgraph starts on --freq (default ch6 = 2437 MHz) and hops across
2.4 GHz channels 1-11 every --dwell seconds, starting from --freq.  Pass
--no-hop to stay on --freq (``odid serve`` does this by default, because
ODID NAN and most beacons are on channel 6).

Frame filtering
---------------
Only MAC frames containing the ODID beacon vendor OUI (FA:0B:BC) or the
Wi-Fi Alliance NAN OUI+type (50:6F:9A:13) are forwarded.

ZMQ message format
------------------
JSON UTF-8:
    {"source": "wifi", "mac": "aa:bb:cc:dd:ee:ff", "channel": 6,
     "rssi": null, "snr": 23.5, "payload": "<hex bare 802.11 frame, no FCS>"}

``channel`` is the 2.4 GHz channel the receiver was tuned to when the frame
was sent (null if the centre frequency is not a 2.4 GHz channel).

Messages with a ``kind`` key (monitor, record, gain, control_error) are not
frames; see sdr_monitor.py.
"""

import argparse
import json
import os
import re
import itertools
import signal
import sys
import threading
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# Dependency checks: fail fast with actionable messages
# ---------------------------------------------------------------------------

try:
    import zmq
except ImportError:
    sys.exit("ERROR: pyzmq not installed.  Run: pip install pyzmq")

try:
    from gnuradio import gr, blocks, fft
    from gnuradio.fft import window
    import pmt
except ImportError:
    sys.exit(
        "ERROR: gnuradio not installed.  Install with:\n"
        "  sudo apt install gnuradio"
    )

try:
    try:
        from gnuradio import ieee802_11  # installed under gnuradio namespace
    except ImportError:
        import ieee802_11                # installed as standalone package
except ImportError:
    sys.exit(
        "ERROR: gr-ieee802-11 not installed.  Build from source:\n"
        "  https://github.com/bastibl/gr-ieee802-11  (branch maint-3.10)"
    )

import sdr_monitor  # noqa: E402  (spectrum/level monitor, IQ recorder, control)

# ---------------------------------------------------------------------------
# 2.4 GHz channel -> centre frequency map (MHz)
# ---------------------------------------------------------------------------

CHANNEL_FREQ_MHZ = {
    1: 2412, 2: 2417, 3: 2422, 4: 2427, 5: 2432,
    6: 2437, 7: 2442, 8: 2447, 9: 2452, 10: 2457, 11: 2462,
    12: 2467, 13: 2472, 14: 2484,
}
CHANNELS = list(range(1, 12))   # hop set: channels 1-11 (legal everywhere)

SAMPLE_RATE = 20e6   # 20 MSPS, full 20 MHz 802.11 channel
SYNC_LENGTH = 320
WINDOW_SIZE = 48
SYNC_THRESHOLD = 0.56

_ODID_MARKERS = (b"\xfa\x0b\xbc", b"\x50\x6f\x9a\x13")


GAIN_MIN, GAIN_MAX = 0, 71      # BladeRF 2.0 RX gain range (dB)
MAX_HOP_FAILURES = 5            # consecutive failed hops before giving up

# Dropped-sample check.  gr-osmosdr's bladeRF source does not report RX
# overruns (libbladeRF only logs them at DEBUG), so count the samples that
# reach the receiver instead: when the CPU can't keep up, libbladeRF drops
# whole buffers and fewer than SAMPLE_RATE samples/s arrive.  libbladeRF
# buffers ~100 ms, so a transient stall that later catches up can shift at
# most ~1% of a window; DROP_TOLERANCE stays above that.
DROP_CHECK_SECS = 10.0
DROP_TOLERANCE = 0.02


def gain_arg(value: str) -> int:
    """argparse type: BladeRF RX gain in dB, 0-71."""
    try:
        gain = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid gain {value!r} (integer dB)")
    if not GAIN_MIN <= gain <= GAIN_MAX:
        raise argparse.ArgumentTypeError(
            f"gain {gain} out of range ({GAIN_MIN}-{GAIN_MAX} dB)")
    return gain


def run_hopper(step, dwell: float, stop: threading.Event, name: str,
               on_fatal=None) -> None:
    """Call ``step()`` every ``dwell`` seconds until ``stop`` is set.

    Error policy: a failing hop (e.g. a transient USB/SDR error while
    retuning) is logged to stderr with its traceback and the hopper carries
    on with the next hop.  After MAX_HOP_FAILURES consecutive failures it
    calls ``on_fatal()`` and returns; main() then stops the flowgraph and
    exits non-zero, so SourceManager's watchdog reports the source as failed
    instead of it silently staying parked on one channel.
    """
    failures = 0
    while not stop.is_set():
        try:
            step()
            failures = 0
        except Exception:
            failures += 1
            print(f"[{name}] channel hop failed ({failures}/{MAX_HOP_FAILURES}):",
                  file=sys.stderr, flush=True)
            traceback.print_exc()
            if failures >= MAX_HOP_FAILURES:
                print(f"[{name}] ERROR: channel hopping keeps failing; stopping",
                      file=sys.stderr, flush=True)
                if on_fatal is not None:
                    on_fatal()
                return
        stop.wait(dwell)


def run_drop_monitor(count, rate: float, every: float, stop: threading.Event,
                     clock=time.monotonic) -> None:
    """Every ``every`` seconds, compare ``count()`` (samples received so far)
    with ``rate`` and report a shortfall on stderr until ``stop`` is set.

    The "SDR sample overflow" prefix is what SourceManager counts as an
    overflow, which raises the dashboard's Status alarm.
    """
    last_t, last_n = clock(), count()
    while not stop.wait(every):
        t, n = clock(), count()
        expected = (t - last_t) * rate
        missing = expected - (n - last_n)
        if expected > 0 and missing > expected * DROP_TOLERANCE:
            print(f"SDR sample overflow: {100 * missing / expected:.0f}% of samples dropped "
                  f"in the last {t - last_t:.0f} s (CPU not keeping up)",
                  file=sys.stderr, flush=True)
        last_t, last_n = t, n


def osmosdr_args(device: str) -> str:
    """Build the gr-osmosdr device string for a BladeRF (optional serial)."""
    device = (device or "").strip()
    if not device:
        return "bladerf=0"
    if not re.fullmatch(r"[0-9A-Fa-f]{1,32}", device):
        raise ValueError("--device must be a BladeRF serial number (hex digits)")
    return f"bladerf={device}"


# ---------------------------------------------------------------------------
# ZMQ frame sink
# ---------------------------------------------------------------------------

def _extract_src_mac(frame: bytes) -> str:
    """Extract source MAC (Addr2, bytes 10–15) from a raw 802.11 frame."""
    if len(frame) < 16:
        return "00:00:00:00:00:00"
    return ":".join(f"{b:02x}" for b in frame[10:16])


def freq_to_channel(freq_mhz: float):
    """2.4 GHz channel for a centre frequency (MHz), or None if not one."""
    for ch, f in CHANNEL_FREQ_MHZ.items():
        if abs(f - freq_mhz) < 1.0:
            return ch
    return None


def _looks_like_odid(frame: bytes) -> bool:
    return any(m in frame for m in _ODID_MARKERS)


class _ODIDSink(gr.basic_block):
    """Message-only block: receives decode_mac PDUs and pushes ODID-looking
    frames to a ZMQ PUSH socket.

    decode_mac publishes ``(meta_dict . u8vector)`` where the vector is the
    bare MAC frame without FCS and meta carries ``snr`` from the equalizer.
    """

    def __init__(self, zmq_push_sock, channel=None):
        gr.basic_block.__init__(self, name="ODID ZMQ Sink", in_sig=None, out_sig=None)
        self._sock = zmq_push_sock
        # Current tuned channel; updated by the flowgraph on every retune
        # (a plain attribute write/read is atomic under the GIL).
        self.channel = channel
        self.frames_seen = 0   # every MAC frame decode_mac produced
        self.frames_odid = 0   # frames that look like ODID
        self.frames_sent = 0   # ODID frames handed to ZMQ
        self.message_port_register_in(pmt.intern("pdus"))
        self.set_msg_handler(pmt.intern("pdus"), self._handle_pdu)

    def _handle_pdu(self, msg):
        try:
            meta = pmt.to_python(pmt.car(msg))
            data = bytes(pmt.u8vector_elements(pmt.cdr(msg)))
        except Exception:
            return
        self.frames_seen += 1
        if not _looks_like_odid(data):
            return
        self.frames_odid += 1

        snr = None
        if isinstance(meta, dict):
            v = meta.get("snr")
            if isinstance(v, (int, float)):
                snr = round(float(v), 1)

        envelope = {
            "source": "wifi",
            "mac": _extract_src_mac(data),
            "channel": self.channel,
            "rssi": None,          # not available from gr-ieee802-11
            "snr": snr,
            "payload": data.hex(),
        }
        try:
            self._sock.send(json.dumps(envelope).encode(), zmq.NOBLOCK)
            self.frames_sent += 1
        except zmq.Again:
            pass  # drop if consumer is behind


# ---------------------------------------------------------------------------
# Flowgraph
# ---------------------------------------------------------------------------

class WiFiRxChain(gr.hier_block2):
    """gr-ieee802-11 OFDM receiver: complex samples in, MAC PDUs out (msg "out").

    Reused by the (disabled) dual flowgraph.
    """

    def __init__(self, freq_hz: float, samp_rate: float = SAMPLE_RATE,
                 sync_threshold: float = SYNC_THRESHOLD):
        gr.hier_block2.__init__(
            self, "ODID WiFi RX",
            gr.io_signature(1, 1, gr.sizeof_gr_complex),
            gr.io_signature(0, 0, 0),
        )
        self.message_port_register_hier_out("out")

        # --- packet detection (Schmidl & Cox on the short training field) ---
        self.delay16    = blocks.delay(gr.sizeof_gr_complex, 16)
        self.conj       = blocks.conjugate_cc()
        self.mult       = blocks.multiply_cc()
        self.avg_corr   = blocks.moving_average_cc(WINDOW_SIZE, 1, 4000)
        self.corr_mag   = blocks.complex_to_mag()
        self.pwr        = blocks.complex_to_mag_squared()
        self.avg_pwr    = blocks.moving_average_ff(WINDOW_SIZE + 16, 1, 4000)
        self.norm       = blocks.divide_ff()

        # --- gr-ieee802-11 receive chain ---
        self.sync_short = ieee802_11.sync_short(sync_threshold, 2, False, False)
        self.delay_long = blocks.delay(gr.sizeof_gr_complex, SYNC_LENGTH)
        self.sync_long  = ieee802_11.sync_long(SYNC_LENGTH, False, False)
        self.s2v        = blocks.stream_to_vector(gr.sizeof_gr_complex, 64)
        self.fft        = fft.fft_vcc(64, True, window.rectangular(64), True, 1)
        self.frame_eq   = ieee802_11.frame_equalizer(
            ieee802_11.LS, freq_hz, samp_rate, False, False)
        self.decode_mac = ieee802_11.decode_mac(False, False)

        c = self.connect
        c(self, self.delay16)
        c(self, (self.mult, 0))
        c(self, self.pwr)
        c(self.delay16, self.conj, (self.mult, 1))
        c(self.mult, self.avg_corr)
        c(self.avg_corr, self.corr_mag, (self.norm, 0))
        c(self.pwr, self.avg_pwr, (self.norm, 1))
        c(self.delay16,  (self.sync_short, 0))
        c(self.avg_corr, (self.sync_short, 1))
        c(self.norm,     (self.sync_short, 2))
        c(self.sync_short, (self.sync_long, 0))
        c(self.sync_short, self.delay_long, (self.sync_long, 1))
        c(self.sync_long, self.s2v, self.fft, self.frame_eq, self.decode_mac)
        self.msg_connect((self.decode_mac, "out"), (self, "out"))

    def set_frequency(self, freq_hz: float) -> None:
        self.frame_eq.set_frequency(freq_hz)

    def samples_received(self) -> int:
        """Input samples consumed so far (any first-stage block will do)."""
        return self.pwr.nitems_read(0)


class ODIDWiFiFlowgraph(gr.top_block):
    """802.11 OFDM receiver -> ODID ZMQ sink.

    ``source`` may be any complex-stream block (tests pass a vector source,
    --iq-file a recording); by default a BladeRF is opened through
    gr-osmosdr.  ``monitor`` / ``record`` add the sdr_monitor tap.
    """

    def __init__(self, freq_mhz: float, gain: int, zmq_addr: str,
                 device: str = "", source=None, monitor: bool = False,
                 record: bool = False, sync_threshold: float = SYNC_THRESHOLD):
        super().__init__("ODID WiFi BladeRF")
        self._zmq_ctx = None
        self._zmq_sock = None
        self.sender = None
        self.freq_mhz = freq_mhz
        self.gain = gain

        # Open the SDR *before* binding ZMQ: if the device is missing or busy
        # nothing has been bound yet, so there is nothing to leak.
        if source is None:
            try:
                import osmosdr  # BladeRF exposed via gr-osmosdr
            except ImportError:
                sys.exit("ERROR: gr-osmosdr not installed.  Run: sudo apt install gr-osmosdr")
            source = osmosdr.source(args=osmosdr_args(device))
            source.set_sample_rate(SAMPLE_RATE)
            source.set_center_freq(freq_mhz * 1e6)
            source.set_freq_corr(0)
            source.set_gain_mode(False)
            source.set_gain(gain)
            source.set_bandwidth(20e6)
            self._tunable = source
        else:
            self._tunable = None
        self.src = source

        try:
            self._zmq_ctx = zmq.Context()
            self._zmq_sock = self._zmq_ctx.socket(zmq.PUSH)
            self._zmq_sock.setsockopt(zmq.LINGER, 0)
            self._zmq_sock.bind(zmq_addr)
            self.sender = sdr_monitor.LockedSender(self._zmq_sock)

            self.rx = WiFiRxChain(freq_mhz * 1e6, SAMPLE_RATE, sync_threshold)
            self.odid_sink = _ODIDSink(self.sender, channel=freq_to_channel(freq_mhz))
            self.connect(self.src, self.rx)
            self.msg_connect((self.rx, "out"), (self.odid_sink, "pdus"))
            self.tap = None
            if monitor or record:
                self.tap = sdr_monitor.SdrTap(SAMPLE_RATE, record=record)
                self.connect(self.src, self.tap)
        except BaseException:
            self.close_zmq()
            raise

    def set_freq(self, freq_mhz: float) -> None:
        if self._tunable is not None:
            self._tunable.set_center_freq(freq_mhz * 1e6)
        # The equalizer uses the centre frequency for its pilot/phase tracking
        self.rx.set_frequency(freq_mhz * 1e6)
        self.odid_sink.channel = freq_to_channel(freq_mhz)
        self.freq_mhz = freq_mhz

    def set_gain(self, gain: int) -> None:
        self._tunable.set_gain(gain)
        self.gain = gain

    def close_zmq(self) -> None:
        for obj, close in ((self._zmq_sock, lambda o: o.close(0)),
                           (self._zmq_ctx, lambda o: o.term())):
            if obj is not None:
                try:
                    close(obj)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Channel hopper
# ---------------------------------------------------------------------------

def _hop_order(start_freq_mhz: float) -> list:
    """Channel list rotated so hopping starts at the channel nearest --freq."""
    nearest = min(CHANNELS, key=lambda ch: abs(CHANNEL_FREQ_MHZ[ch] - start_freq_mhz))
    i = CHANNELS.index(nearest)
    return CHANNELS[i:] + CHANNELS[:i]


def _channel_hopper(fg: ODIDWiFiFlowgraph, channels: list, dwell: float,
                    stop: threading.Event, on_fatal=None) -> None:
    """Rotate through channels in a background thread (see run_hopper)."""
    order = itertools.cycle(channels)
    run_hopper(lambda: fg.set_freq(CHANNEL_FREQ_MHZ[next(order)]), dwell, stop,
               "odid_wifi_bladerf", on_fatal)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--freq", type=float, default=2437.0, metavar="MHz",
                   help="Start centre frequency in MHz (default: 2437 = ch6)")
    p.add_argument("--gain", type=gain_arg, default=40,
                   help="BladeRF RX gain in dB (0-71, default: 40)")
    p.add_argument("--device", default="", metavar="SERIAL",
                   help="BladeRF serial number (default: first BladeRF found)")
    p.add_argument("--zmq", default="tcp://127.0.0.1:5555", metavar="ADDR",
                   help="ZMQ PUSH bind address (default: tcp://127.0.0.1:5555)")
    p.add_argument("--dwell", type=float, default=3.0, metavar="SECS",
                   help="Seconds per channel when hopping (default: 3.0)")
    p.add_argument("--no-hop", action="store_true",
                   help="Stay on --freq instead of hopping channels")
    p.add_argument("--stats", type=float, default=0.0, metavar="SECS",
                   help="Print receiver counters every SECS seconds (0=off). 'frames' counts every "
                        "OFDM 802.11 frame decoded (any network), so this verifies the receiver "
                        "without an ODID transmitter.")
    p.add_argument("--sync-threshold", type=float, default=SYNC_THRESHOLD, metavar="X",
                   help=f"Short-preamble detection threshold, 0-1 (default: {SYNC_THRESHOLD}); "
                        "tune it offline with --iq-file and --stats")
    sdr_monitor.add_cli_args(p)
    return p.parse_args()


def _stats_printer(fg: "ODIDWiFiFlowgraph", every: float, stop: threading.Event) -> None:
    sink = fg.odid_sink
    prev = (0, 0, 0)
    while not stop.wait(every):
        cur = (sink.frames_seen, sink.frames_odid, sink.frames_sent)
        d = [c - p for c, p in zip(cur, prev)]
        prev = cur
        print(f"[odid_wifi_bladerf] stats ch{sink.channel}: frames={d[0]} odid={d[1]} sent={d[2]}  "
              f"(totals: frames={cur[0]} odid={cur[1]})", flush=True)


def main() -> None:
    args = _parse_args()
    try:
        osmosdr_args(args.device)
    except ValueError as e:
        sys.exit(f"ERROR: {e}")

    if not 0.0 < args.sync_threshold < 1.0:
        sys.exit("ERROR: --sync-threshold must be between 0 and 1")

    replay = None
    if args.iq_file:
        try:
            replay, rate, rec_freq = sdr_monitor.iq_file_source(args.iq_file, args.realtime)
        except (ValueError, OSError) as e:
            sys.exit(f"ERROR: --iq-file: {e}")
        if abs(rate - SAMPLE_RATE) > 1:
            sys.exit(f"ERROR: --iq-file was recorded at {rate / 1e6:g} MS/s; "
                     f"this receiver needs {SAMPLE_RATE / 1e6:g} MS/s")
        if rec_freq is not None:
            args.freq = rec_freq / 1e6
        args.no_hop = True

    fg = ODIDWiFiFlowgraph(freq_mhz=args.freq, gain=args.gain, zmq_addr=args.zmq,
                           device=args.device, source=replay,
                           monitor=not args.no_monitor,
                           record=bool(args.iq_dir) and replay is None,
                           sync_threshold=args.sync_threshold)
    stop = threading.Event()
    hop_failed = threading.Event()

    def _on_sigterm(signum, frame):
        stop.set()
        fg.stop()

    def _on_hop_fatal():
        hop_failed.set()
        stop.set()
        fg.stop()

    signal.signal(signal.SIGTERM, _on_sigterm)

    if not args.no_hop:
        threading.Thread(
            target=_channel_hopper,
            args=(fg, _hop_order(args.freq), max(args.dwell, 0.05), stop, _on_hop_fatal),
            daemon=True,
        ).start()

    if args.stats > 0:
        threading.Thread(target=_stats_printer, args=(fg, args.stats, stop), daemon=True).start()

    recorder = sdr_monitor.start_services(
        tap=fg.tap, sender=fg.sender, source="bladerf-wifi", sample_rate=SAMPLE_RATE,
        freq_hz=lambda: fg.freq_mhz * 1e6,
        gain_db=lambda: None if replay is not None else fg.gain,
        set_gain=None if replay is not None else fg.set_gain,
        gain_range=(GAIN_MIN, GAIN_MAX), iq_dir=args.iq_dir or None,
        control_stdin=args.control_stdin, stop=stop, hopping=not args.no_hop,
        extra_info=lambda: {"channel": fg.odid_sink.channel},
        log_name="odid_wifi_bladerf")

    fg.start()
    if replay is None:
        threading.Thread(target=run_drop_monitor,
                         args=(fg.rx.samples_received, SAMPLE_RATE, DROP_CHECK_SECS, stop),
                         daemon=True).start()
    else:
        print(f"[odid_wifi_bladerf] Replaying {args.iq_file}", flush=True)
    print(f"[odid_wifi_bladerf] Listening, ZMQ push at {args.zmq}", flush=True)
    print("[odid_wifi_bladerf] Press Ctrl+C to stop", flush=True)
    try:
        fg.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if recorder is not None:
            recorder.close()
        stop.set()
        fg.stop()
        fg.wait()
        if args.stats > 0:
            sink = fg.odid_sink
            print(f"[odid_wifi_bladerf] totals: frames={sink.frames_seen} "
                  f"odid={sink.frames_odid} sent={sink.frames_sent}", flush=True)
        fg.close_zmq()
        print("[odid_wifi_bladerf] Stopped", flush=True)
    if hop_failed.is_set():
        sys.exit("ERROR: channel hopping failed repeatedly (see errors above)")


if __name__ == "__main__":
    main()
