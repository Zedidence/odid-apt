"""BLE advertising-channel link-layer DSP helpers (pure Python + numpy).

Used by ``odid_bt_bladerf.py`` (and the disabled dual flowgraph).  Kept free
of GNU Radio imports so it can be unit-tested anywhere
(see ``tests/test_ble_dsp.py``).

Conventions (Bluetooth Core Spec Vol 6 Part B)
----------------------------------------------
* Bits are transmitted LSB-first; a bit stream is a numpy uint8 array of 0/1
  in air order, and bytes are packed LSB-first (``bitorder="little"``).
* Air packet: preamble(8) | access address(32) | PDU(16 + 8*len) | CRC(24).
* Whitening covers PDU + CRC.  7-bit LFSR x^7 + x^4 + 1, initialised with
  ``channel | 0x40`` in the right-shifting form used below.
* CRC-24 polynomial x^24+x^10+x^9+x^6+x^4+x^3+x+1, preset 0x555555 for
  advertising channels, computed reflected (register preset 0xAAAAAA,
  mask 0x5A6000).  The returned integer, encoded little-endian in 3 bytes,
  is exactly the CRC as packed from the air bits, i.e. reveng's
  CRC-24/BLE (check("123456789") == 0xC25A56).
"""

from __future__ import annotations

from typing import Optional

import numpy as np

ADV_ACCESS_ADDRESS = 0x8E89BED6
ADV_CRC_INIT = 0x555555          # spec (non-reflected) form
MAX_ADV_PDU_LEN = 37             # legacy advertising PDU payload limit

# AD type for Service Data (16-bit UUID)
AD_TYPE_SERVICE_DATA = 0x16
# ODID service UUID 0xFFFA (little-endian on air)
ODID_UUID_LE = b"\xfa\xff"
ODID_APP_CODE = 0x0D

# Legacy advertising PDU types that may carry ODID (BT4 legacy adverts)
_ADV_IND = 0x0
_ADV_NONCONN_IND = 0x2
_ADV_SCAN_IND = 0x6


# ---------------------------------------------------------------------------
# Bit helpers
# ---------------------------------------------------------------------------

def bytes_to_bits(data: bytes) -> np.ndarray:
    """Bytes → air-order bit array (LSB of each byte first)."""
    return np.unpackbits(np.frombuffer(bytes(data), dtype=np.uint8), bitorder="little")


def bits_to_bytes(bits) -> bytes:
    """Air-order bit array → bytes (LSB-first packing); len must be a multiple of 8."""
    arr = np.asarray(bits, dtype=np.uint8) & 1
    return np.packbits(arr, bitorder="little").tobytes()


def _rev24(x: int) -> int:
    return int(f"{x & 0xFFFFFF:024b}"[::-1], 2)


# ---------------------------------------------------------------------------
# Whitening
# ---------------------------------------------------------------------------

def whitening_sequence(channel: int, nbytes: int) -> bytes:
    """Return ``nbytes`` of BLE whitening keystream for ``channel`` (0-39)."""
    lfsr = (channel & 0x3F) | 0x40
    out = bytearray(nbytes)
    for i in range(nbytes):
        w = 0
        for bit in range(8):
            if lfsr & 1:
                lfsr ^= 0x88
                w |= 1 << bit
            lfsr >>= 1
        out[i] = w
    return bytes(out)


_WHITEN_CACHE: dict[int, np.ndarray] = {}
_WHITEN_MAX = 2 + 255 + 3


def whiten(data: bytes, channel: int) -> bytes:
    """Whiten / dewhiten ``data`` (the operation is its own inverse).

    ``data`` must start at the first PDU header byte.
    """
    seq = _WHITEN_CACHE.get(channel)
    if seq is None:
        seq = np.frombuffer(whitening_sequence(channel, _WHITEN_MAX), dtype=np.uint8)
        _WHITEN_CACHE[channel] = seq
    buf = np.frombuffer(bytes(data), dtype=np.uint8)
    if len(buf) > len(seq):
        raise ValueError("data longer than maximum BLE packet")
    return (buf ^ seq[: len(buf)]).tobytes()


dewhiten = whiten


# ---------------------------------------------------------------------------
# CRC-24
# ---------------------------------------------------------------------------

def crc24(data: bytes, init: int = ADV_CRC_INIT) -> int:
    """BLE CRC-24 over ``data`` (PDU header + payload).

    ``init`` is the spec-form preset (0x555555 for advertising).  Compare the
    result against ``int.from_bytes(received_crc_bytes, "little")``.
    """
    state = _rev24(init)
    for byte in bytes(data):
        cur = byte
        for _ in range(8):
            next_bit = (state ^ cur) & 1
            cur >>= 1
            state >>= 1
            if next_bit:
                state |= 1 << 23
                state ^= 0x5A6000
    return state


def crc24_bytes(data: bytes, init: int = ADV_CRC_INIT) -> bytes:
    return crc24(data, init).to_bytes(3, "little")


# ---------------------------------------------------------------------------
# Packet build (for tests / loopback) and parse
# ---------------------------------------------------------------------------

def encode_air_bits(pdu: bytes, channel: int,
                    access_address: int = ADV_ACCESS_ADDRESS) -> np.ndarray:
    """Build the on-air bit stream (preamble + AA + whitened PDU + CRC)."""
    aa = access_address.to_bytes(4, "little")
    preamble = b"\xaa" if (aa[0] & 1) == 0 else b"\x55"
    body = whiten(bytes(pdu) + crc24_bytes(pdu), channel)
    return bytes_to_bits(preamble + aa + body)


def parse_adv_pdu(pdu: bytes) -> Optional[tuple[str, bytes]]:
    """Parse a legacy advertising PDU and extract ODID service data.

    Returns ``(mac_str, service_data_from_app_code)`` or None if not ODID.
    """
    if len(pdu) < 8:
        return None
    pdu_type = pdu[0] & 0x0F
    if pdu_type not in (_ADV_IND, _ADV_NONCONN_IND, _ADV_SCAN_IND):
        return None
    payload_len = pdu[1]
    if payload_len < 6 or len(pdu) < 2 + payload_len:
        return None

    mac = ":".join(f"{b:02x}" for b in reversed(pdu[2:8]))   # AdvA, little-endian
    ad_data = pdu[8: 2 + payload_len]
    offset = 0
    while offset + 2 <= len(ad_data):
        ad_len = ad_data[offset]
        if ad_len == 0:
            break
        ad_type = ad_data[offset + 1]
        ad_payload = ad_data[offset + 2: offset + 1 + ad_len]
        if (
            ad_type == AD_TYPE_SERVICE_DATA
            and len(ad_payload) >= 3
            and ad_payload[:2] == ODID_UUID_LE
            and ad_payload[2] == ODID_APP_CODE
        ):
            return mac, bytes(ad_payload[2:])
        offset += 1 + ad_len
    return None


# ---------------------------------------------------------------------------
# Access-address search + streaming framer
# ---------------------------------------------------------------------------

def find_access_address(bits: np.ndarray, access_address: int = ADV_ACCESS_ADDRESS) -> np.ndarray:
    """Return indices just *after* every exact match of the 32-bit AA.

    Vectorised: starts with all positions matching bit 0 and prunes the
    candidate index array bit by bit, so cost is ~N for random data.
    """
    bits = np.asarray(bits, dtype=np.uint8)
    n = len(bits) - 31
    if n <= 0:
        return np.empty(0, dtype=np.int64)
    pattern = bytes_to_bits(access_address.to_bytes(4, "little"))
    idx = np.flatnonzero(bits[:n] == pattern[0])
    for k in range(1, 32):
        if idx.size == 0:
            break
        idx = idx[bits[idx + k] == pattern[k]]
    return idx + 32


class BLEFramer:
    """Streaming BLE advertising framer.

    Feed demodulated bits (0/1 uint8, air order) with :meth:`feed`; it
    returns the CRC-valid PDUs (header + payload, dewhitened) found so far.
    Bits spanning calls are buffered.
    """

    _MAX_BODY_BITS = (2 + MAX_ADV_PDU_LEN + 3) * 8

    def __init__(self, channel: int = 37, access_address: int = ADV_ACCESS_ADDRESS,
                 crc_init: int = ADV_CRC_INIT) -> None:
        self.channel = channel
        self.access_address = access_address
        self.crc_init = crc_init
        self._buf = np.empty(0, dtype=np.uint8)
        self._buf_start = 0     # absolute bit index of _buf[0]
        self._next_start = 0    # candidates at absolute index < this are done
        # Diagnostics (read by the flowgraph's --stats output)
        self.aa_hits = 0        # access-address matches examined
        self.crc_ok = 0         # CRC-valid advertising PDUs (any advertiser)
        self.crc_failures = 0

    def set_channel(self, channel: int) -> None:
        """Change the dewhitening channel and drop buffered bits."""
        self.channel = channel
        self.reset()

    def reset(self) -> None:
        self._buf_start += len(self._buf)
        self._next_start = self._buf_start
        self._buf = np.empty(0, dtype=np.uint8)

    def feed(self, bits) -> list[bytes]:
        new = np.asarray(bits, dtype=np.uint8) & 1
        buf = np.concatenate((self._buf, new)) if self._buf.size else new
        base = self._buf_start
        found: list[bytes] = []
        keep_from = max(len(buf) - 31, 0)     # AA may straddle the next call

        for start in find_access_address(buf, self.access_address):
            start = int(start)
            if base + start < self._next_start:
                continue
            if start + 16 > len(buf):
                keep_from = min(keep_from, start - 32)
                break
            hdr = whiten(bits_to_bytes(buf[start:start + 16]), self.channel)
            length = hdr[1]
            if length > MAX_ADV_PDU_LEN:
                self.aa_hits += 1
                self._next_start = base + start + 1
                continue
            total = 16 + 8 * length + 24
            if start + total > len(buf):
                keep_from = min(keep_from, start - 32)
                break
            self.aa_hits += 1  # counted once the whole candidate is buffered
            pkt = whiten(bits_to_bytes(buf[start:start + total]), self.channel)
            pdu, crc = pkt[: 2 + length], pkt[2 + length:]
            if crc24(pdu, self.crc_init) == int.from_bytes(crc, "little"):
                self.crc_ok += 1
                found.append(pdu)
                self._next_start = base + start + total
            else:
                self.crc_failures += 1
                self._next_start = base + start + 1

        keep_from = max(keep_from, 0)
        self._buf = buf[keep_from:].copy()
        self._buf_start = base + keep_from
        return found
