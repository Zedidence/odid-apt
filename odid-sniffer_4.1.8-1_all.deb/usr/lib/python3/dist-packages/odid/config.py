"""TOML configuration file support for ODID Sniffer.

Config file location: ~/.config/odid/config.toml (when running under sudo,
the invoking user's home is used so ``sudo odid sniff`` and ``odid query``
share one config).

Example config::

    [observer]
    lat = 51.5074
    lon = -0.1278

    [capture]
    interface = "wlan1"
    channels = [1, 6, 11]
    dwell = 5.0
    drone_ttl = 300

    [output]
    log_dir = "logs"
    web = false
    web_port = 8080
    no_pcap = false
    no_jsonl = false
    no_csv = false
    no_db = false
    max_sessions = 0

    [alerts]
    watchlist = ""
    webhook = ""
"""

import json
import math
import os
import re
import sys
import logging
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

# Python 3.11+ ships tomllib; earlier versions need tomli
if sys.version_info >= (3, 11):
    import tomllib as _tomllib
else:
    try:
        import tomllib as _tomllib  # type: ignore
    except ImportError:
        try:
            import tomli as _tomllib  # type: ignore
        except ImportError:
            _tomllib = None



def _user_home() -> Path:
    """Home of the real user, even when running under sudo."""
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user and os.geteuid() == 0:
        try:
            import pwd
            return Path(pwd.getpwnam(sudo_user).pw_dir)
        except (KeyError, ImportError):
            pass
    return Path.home()


# ODID_CONFIG overrides the location. The systemd service uses it to read a
# root-owned /etc/odid/config.toml rather than a user-writable file.
SERVICE_CONFIG_PATH = Path("/etc/odid/config.toml")
CONFIG_PATH = (Path(os.environ["ODID_CONFIG"]) if os.environ.get("ODID_CONFIG")
               else _user_home() / ".config" / "odid" / "config.toml")
# Settings changed in the web dashboard. Loaded after CONFIG_PATH, key by key,
# so the service can edit its own settings while /etc/odid stays root-owned.
# The systemd unit points ODID_SETTINGS into /var/lib/odid.
OVERLAY_PATH = (Path(os.environ["ODID_SETTINGS"]) if os.environ.get("ODID_SETTINGS")
                else CONFIG_PATH.with_name("settings.toml"))


def _trusted(path: Path) -> bool:
    """Whether a config file named by ODID_CONFIG (e.g. by a systemd service)
    may be loaded.

    * As root: only a root-owned file nobody else can write; otherwise any
      local user could reconfigure a root process (web exposure, webhooks...).
    * As another user (the packaged service runs as ``odid``): a file owned by
      root or by that user, not writable by everyone. Group write is allowed
      so the service group can edit its own settings.
    """
    if not os.environ.get("ODID_CONFIG"):
        return True
    try:
        st = path.stat()
    except OSError:
        return True  # missing: nothing to load
    euid = os.geteuid()
    if euid == 0:
        if st.st_uid != 0 or st.st_mode & 0o022:
            log.error("Refusing config %s: running as root but the file is not root-owned "
                      "or is group/world-writable", path)
            return False
        return True
    if st.st_uid not in (0, euid) or st.st_mode & 0o002:
        log.error("Refusing config %s: owned by another user or world-writable", path)
        return False
    return True

# Flat key → TOML section map
_SECTION_MAP = {
    "lat": "observer",
    "lon": "observer",
    "interface": "capture",
    "channels": "capture",
    "dwell": "capture",
    "drone_ttl": "capture",
    "max_drones": "capture",
    "log_dir": "output",
    "web": "output",
    "web_port": "output",
    "no_pcap": "output",
    "no_jsonl": "output",
    "no_csv": "output",
    "no_db": "output",
    "max_sessions": "output",
    "min_free_mb": "output",
    "db_retention_days": "output",
    "web_host": "output",
    "allowed_hosts": "output",
    "trusted_proxy": "output",
    "autostart": "serve",
    "watchlist": "alerts",
    "webhook": "alerts",
}


class ConfigError(Exception):
    """The config file exists but could not be read or parsed."""


def load_raw(strict: bool = False) -> dict[str, Any]:
    """Load the config file as nested sections.

    Returns {} if the file is missing. If it exists but can't be parsed,
    returns {} (with a warning), or raises ConfigError when ``strict``.
    """
    if _tomllib is None or not CONFIG_PATH.exists():
        return {}
    if not _trusted(CONFIG_PATH):
        if strict:
            raise ConfigError(f"{CONFIG_PATH}: untrusted owner or permissions (see log)")
        return {}
    try:
        with open(CONFIG_PATH, "rb") as f:
            return _tomllib.load(f)
    except Exception as exc:
        if strict:
            raise ConfigError(f"{CONFIG_PATH}: {exc}") from exc
        log.warning("Failed to load config %s: %s", CONFIG_PATH, exc)
        return {}


def _chown_to_sudo_user(path: Path) -> None:
    """Under sudo, hand files we create back to the invoking user."""
    if os.geteuid() != 0:
        return
    uid, gid = os.environ.get("SUDO_UID"), os.environ.get("SUDO_GID")
    if not (uid and gid):
        return
    try:
        os.chown(path, int(uid), int(gid))
    except (OSError, ValueError) as exc:
        log.debug("chown %s failed: %s", path, exc)


def flatten(raw: dict[str, Any]) -> dict[str, Any]:
    """Nested sections -> flat option_name -> value (CLI arg names)."""
    flat: dict[str, Any] = {}
    for section, values in raw.items():
        if isinstance(values, dict):
            for k, v in values.items():
                flat[k] = v
        else:
            flat[section] = values
    return flat


def load_overlay() -> dict[str, Any]:
    """The dashboard's settings overlay as nested sections; {} if missing,
    untrusted or unreadable (with a warning)."""
    if _tomllib is None or not OVERLAY_PATH.exists() or not _trusted(OVERLAY_PATH):
        return {}
    try:
        with open(OVERLAY_PATH, "rb") as f:
            return _tomllib.load(f)
    except Exception as exc:
        log.warning("Ignoring dashboard settings %s: %s", OVERLAY_PATH, exc)
        return {}


def load(overlay: bool = True) -> dict[str, Any]:
    """Load and flatten config from ~/.config/odid/config.toml, then the
    dashboard overlay (unless ``overlay`` is False).

    Returns a flat dict of option_name -> value, matching CLI arg names.
    Returns an empty dict if no file exists or tomllib is unavailable.
    """
    if _tomllib is None:
        log.debug("tomllib not available, config file disabled (Python < 3.11, tomli not installed)")
        return {}
    flat: dict[str, Any] = {}
    if CONFIG_PATH.exists():
        flat = flatten(load_raw())
        log.info("Loaded config from %s (%d keys)", CONFIG_PATH, len(flat))
    else:
        log.debug("Config file not found: %s", CONFIG_PATH)
    if overlay:
        extra = flatten(load_overlay())
        if extra:
            flat.update(extra)
            log.info("Loaded dashboard settings from %s (%d keys)", OVERLAY_PATH, len(extra))
    log.debug("Config values: %s", flat)
    return flat


def apply_defaults(args: Any, config: dict[str, Any]) -> None:
    """Fill in missing args attributes from config, without overriding set CLI values.

    Only touches attributes that are ``None`` or the argparse default (False for flags).
    This allows CLI flags to always win over config file.
    """
    for key, value in config.items():
        if not hasattr(args, key):
            continue
        current = getattr(args, key)
        # Don't override CLI values; argparse sets missing strings to None,
        # missing flags to False, and missing ints/floats to their defaults.
        # We only fill in if the value is None (meaning "not set by user").
        if current is None:
            setattr(args, key, value)
            log.debug("Config override: %s = %r (from config file)", key, value)


_BARE_KEY_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _toml_key(k: Any) -> str:
    k = str(k)
    return k if _BARE_KEY_RE.match(k) else json.dumps(k)


def _toml_value(v: Any) -> str:
    """Serialise a scalar, list or inline table as TOML."""
    if isinstance(v, bool):
        return str(v).lower()
    if isinstance(v, str):
        # JSON string escaping is valid for TOML basic strings
        return json.dumps(v)
    if isinstance(v, (int, float)):
        if isinstance(v, float) and not math.isfinite(v):
            raise ValueError(f"cannot write non-finite float {v!r} to TOML")
        return repr(v)
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_toml_value(i) for i in v if i is not None) + "]"
    if isinstance(v, dict):
        items = ", ".join(f"{_toml_key(k)} = {_toml_value(x)}" for k, x in v.items() if x is not None)
        return "{ " + items + " }" if items else "{}"
    raise ValueError(f"cannot write {type(v).__name__} value {v!r} to TOML")


def _toml_table(lines: list[str], path: list[str], values: dict[str, Any]) -> None:
    """Append ``[path]`` with its scalar keys, then its sub-tables."""
    scalars = {k: v for k, v in values.items() if not isinstance(v, dict) and v is not None}
    tables = {k: v for k, v in values.items() if isinstance(v, dict)}
    if path and (scalars or not tables):
        lines.append("[" + ".".join(_toml_key(p) for p in path) + "]")
    for k, v in scalars.items():
        lines.append(f"{_toml_key(k)} = {_toml_value(v)}")
    if path and (scalars or not tables):
        lines.append("")
    for k, v in tables.items():
        _toml_table(lines, path + [k], v)


def dumps(config: dict[str, Any]) -> str:
    """Serialise a (possibly nested) config dict as TOML.

    Top-level scalars come first (TOML requires them before any table);
    nested dicts become ``[section]`` / ``[section.sub]`` tables. Unsupported
    types raise ValueError instead of producing an unreadable file.
    """
    lines: list[str] = [
        "# ODID Sniffer configuration",
        "# Generated by: odid init",
        "",
    ]
    top = {k: v for k, v in config.items() if not isinstance(v, dict) and v is not None}
    for k, v in top.items():
        lines.append(f"{_toml_key(k)} = {_toml_value(v)}")
    if top:
        lines.append("")
    _toml_table(lines, [], {k: v for k, v in config.items() if isinstance(v, dict)})
    return "\n".join(lines)


def save(config: dict[str, Any]) -> None:
    """Write a config dict to ~/.config/odid/config.toml.

    The config dict should be nested by section, e.g.::

        {"observer": {"lat": 51.5, "lon": -0.1}, "capture": {"interface": "wlan1"}}
    """
    text = dumps(config)  # serialise first: never truncate the file on a bad value
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _chown_to_sudo_user(CONFIG_PATH.parent)
    CONFIG_PATH.write_text(text)
    _chown_to_sudo_user(CONFIG_PATH)
    log.info("Config written to %s", CONFIG_PATH)


def read_file(path: Path) -> dict[str, Any]:
    """Parse a TOML file without the ODID_CONFIG trust check (for tools that
    only edit the file, e.g. ``odid provision``). {} if missing; raises
    ConfigError if unreadable."""
    if _tomllib is None:
        raise ConfigError("TOML support unavailable (Python < 3.11 without tomli)")
    try:
        with open(path, "rb") as f:
            return _tomllib.load(f)
    except FileNotFoundError:
        return {}
    except Exception as exc:
        raise ConfigError(f"{path}: {exc}") from exc


def write_file(path: Path, config: dict[str, Any], header: str = "odid provision",
               owner: tuple[int, int] | None = None, mode: int | None = None) -> None:
    """Atomically replace ``path`` with ``config`` as TOML.

    The temp file is created with O_EXCL|O_NOFOLLOW and ownership/mode are set
    on the descriptor, never by path. ``owner``/``mode`` default to those of
    the existing file (or the caller's, 0640, for a new one).
    """
    import secrets
    text = dumps(config).replace("# Generated by: odid init", f"# Generated by: {header}", 1)
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        st = None
    if st is not None and not stat_is_regular(st.st_mode):
        raise ValueError(f"{path} is not a regular file")
    if mode is None:
        mode = 0o640 if st is None else st.st_mode & 0o777
    if owner is None and st is not None:
        owner = (st.st_uid, st.st_gid)
    tmp = path.with_name(f".{path.name}.{secrets.token_hex(8)}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
            f.flush()
            if owner is not None and os.geteuid() == 0:
                os.fchown(f.fileno(), *owner)
            os.fchmod(f.fileno(), mode)
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def stat_is_regular(mode: int) -> bool:
    import stat
    return stat.S_ISREG(mode)


def config_path() -> Path:
    """Return the config file path."""
    return CONFIG_PATH
