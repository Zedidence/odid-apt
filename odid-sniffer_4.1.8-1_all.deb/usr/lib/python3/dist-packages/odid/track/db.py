"""SQLite persistence for drone tracking data."""

import json
import logging
import sqlite3
import threading
import time
import weakref
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from odid.decode.frame import ODIDFrame
from odid.decode.messages import LocationMessage, MessagePack
from odid.track.tracker import ANOMALIES_CAP, DroneState, as_utc, utcnow

log = logging.getLogger(__name__)

SCHEMA_VERSION = 4

CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS drones (
    mac TEXT PRIMARY KEY,
    uas_id TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    frame_count INTEGER DEFAULT 0,
    anomaly_flags TEXT,
    data_json TEXT
);

CREATE TABLE IF NOT EXISTS frames (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    mac TEXT NOT NULL,
    signal_dbm INTEGER,
    channel INTEGER,
    frame_type TEXT,
    message_types TEXT,
    data_json TEXT,
    FOREIGN KEY (mac) REFERENCES drones(mac)
);

CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mac TEXT NOT NULL,
    ts TEXT NOT NULL,
    lat REAL NOT NULL,
    lon REAL NOT NULL,
    alt_geo REAL,
    alt_baro REAL,
    height REAL,
    speed_h REAL,
    speed_v REAL,
    direction REAL
);

CREATE INDEX IF NOT EXISTS idx_positions_mac_ts ON positions(mac, ts);
CREATE INDEX IF NOT EXISTS idx_positions_ts ON positions(ts);
CREATE INDEX IF NOT EXISTS idx_frames_mac ON frames(mac);
CREATE INDEX IF NOT EXISTS idx_frames_timestamp ON frames(timestamp);
CREATE INDEX IF NOT EXISTS idx_drones_uas_id ON drones(uas_id);
CREATE INDEX IF NOT EXISTS idx_drones_last_seen ON drones(last_seen);
"""

_MIGRATE_V1_TO_V2 = """
ALTER TABLE drones ADD COLUMN anomaly_flags TEXT;
"""

_POSITION_INSERT = (
    "INSERT INTO positions (mac, ts, lat, lon, alt_geo, alt_baro, height, "
    "speed_h, speed_v, direction) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
)


def _parse_dt(value) -> Optional[datetime]:
    """Parse a stored ISO timestamp to UTC-aware (naive rows are local time)."""
    if not value:
        return None
    try:
        return as_utc(datetime.fromisoformat(value))
    except (TypeError, ValueError):
        return None


def _utc_text(value) -> Optional[str]:
    """SQLite function: a stored timestamp as a UTC ISO string."""
    dt = _parse_dt(value)
    return dt.isoformat() if dt is not None else value


# State-based anomaly categories describe the drone's current state, so a
# stored one is dropped once the live DroneState no longer has it.
_STATE_ANOMALIES = {"missing_basic_id": "No Basic ID received after initial frames"}


def _merge_anomalies(old_state: dict, new_state: dict) -> dict:
    """Merge stored and current anomaly state {category: {first_seen, description}}.

    Current entries win (latest description); for a category in both, the
    earliest ``first_seen`` is kept. Stored state-based categories absent
    from the current state are dropped. The result is capped at
    ANOMALIES_CAP categories (current ones first, then oldest stored).
    """
    merged = {cat: dict(v) for cat, v in new_state.items()}
    stale_state_descs = {
        desc for cat, desc in _STATE_ANOMALIES.items() if cat not in new_state
    }
    by_desc = {v.get("description"): cat for cat, v in merged.items()}
    olds = []
    for cat, v in (old_state or {}).items():
        if not isinstance(v, dict):
            continue
        if cat not in merged and v.get("description") in by_desc:
            cat = by_desc[v.get("description")]   # legacy row keyed by description
        if cat in _STATE_ANOMALIES and cat not in new_state:
            continue
        if v.get("description") in stale_state_descs:   # legacy rows
            continue
        old_ts = _parse_dt(v.get("first_seen"))
        if cat in merged:
            new_ts = _parse_dt(merged[cat].get("first_seen"))
            if old_ts is not None and (new_ts is None or old_ts < new_ts):
                merged[cat]["first_seen"] = old_ts.isoformat()
        else:
            olds.append((old_ts or datetime.max.replace(tzinfo=timezone.utc), cat, v))
    olds.sort(key=lambda t: t[0])
    for _, cat, v in olds:
        if len(merged) >= ANOMALIES_CAP:
            break
        merged[cat] = {
            "first_seen": v.get("first_seen"),
            "description": v.get("description") or cat,
        }
    return merged


def _stored_anomaly_state(row, old_data: dict) -> dict:
    """Anomaly state from a stored row: data_json's ``anomaly_state``, else
    the legacy ``anomaly_flags`` {description: first_seen} JSON."""
    state = old_data.get("anomaly_state") if isinstance(old_data, dict) else None
    if isinstance(state, dict):
        return state
    try:
        flags = json.loads(row["anomaly_flags"] or "{}") or {}
    except (TypeError, ValueError):
        flags = {}
    if not isinstance(flags, dict):
        return {}
    return {desc: {"first_seen": ts, "description": desc} for desc, ts in flags.items()}


def _message_types(messages) -> str:
    """Comma-separated message types, listing a pack's contents in brackets.

    e.g. ``"Message Pack[Basic ID,Location,System]"``.
    """
    parts = []
    for m in messages:
        name = getattr(m, "msg_type", "unknown")
        if isinstance(m, MessagePack):
            name = f"{name}[{_message_types(m.messages)}]"
        parts.append(name)
    return ",".join(parts)


def _iter_locations(messages):
    """Yield LocationMessages, descending into Message Packs."""
    for msg in messages:
        if isinstance(msg, LocationMessage):
            yield msg
        elif isinstance(msg, MessagePack):
            yield from _iter_locations(msg.messages)


class DroneDB:
    """SQLite database for persistent drone tracking.

    All use of the shared connection is serialised by ``self._lock`` so the
    tracker callback (capture threads), the writer thread's
    ``commit_if_due()`` and ``close()`` can run concurrently.

    With ``read_only=True`` the database is opened with ``mode=ro``: no DDL,
    migrations or commits are performed, and older schema versions are read
    as-is. If the WAL side files cannot be created or opened (e.g. a
    root-owned capture directory), it falls back to ``immutable=1``.

    ``drones`` holds one row per MAC across sessions: ``frame_count``
    accumulates, ``first_seen`` and a known ``uas_id`` are kept. Every
    Location fix with a lat/lon is stored in ``positions``.
    """

    def __init__(self, db_path: str | Path = "odid_drones.db", read_only: bool = False):
        self.db_path = Path(db_path)
        self.read_only = read_only
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None
        self._write_count: int = 0
        self._pending: int = 0               # writes since the last commit
        self._last_commit_time: float = time.monotonic()
        self._COMMIT_INTERVAL_FRAMES = 100   # commit every N frames
        self._COMMIT_INTERVAL_SECS = 2.0     # or every N seconds, whichever first
        # mac -> (weakref to DroneState, frame_count at its last upsert), so
        # each upsert adds only the frames seen since the previous one
        self._synced: dict[str, tuple] = {}
        self._synced_prune_at = self._SYNCED_PRUNE_MIN
        # Pre-v4 file opened read-only: its timestamps are naive local time
        # (never migrated), so SQL compares them through odid_utc()
        self._legacy_ts = False
        if read_only:
            self._open_read_only()
        else:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._init_db()

    def _open_read_only(self):
        base = self.db_path.resolve().as_uri()
        conn = sqlite3.connect(base + "?mode=ro", uri=True, check_same_thread=False)
        try:
            conn.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
        except sqlite3.OperationalError as e:
            conn.close()
            if not self.db_path.exists():
                raise
            # WAL databases need a writable -shm; without one, read the main
            # file as immutable (close() checkpoints, so it is complete).
            log.debug("Read-only open failed (%s); retrying with immutable=1", e)
            conn = sqlite3.connect(base + "?mode=ro&immutable=1", uri=True,
                                   check_same_thread=False)
            conn.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
        self._conn = conn
        self._conn.row_factory = sqlite3.Row
        try:
            row = conn.execute("SELECT version FROM schema_version LIMIT 1").fetchone()
            version = row[0] if row else SCHEMA_VERSION
        except sqlite3.OperationalError:
            version = 1
        if version < 4:
            self._legacy_ts = True
            conn.create_function("odid_utc", 1, _utc_text, deterministic=True)
            log.debug("Schema v%d: comparing timestamps as UTC in queries", version)
        log.debug("Database opened read-only: %s", self.db_path)

    def _ts(self, col: str) -> str:
        """SQL for column ``col`` as a comparable UTC ISO string."""
        return f"odid_utc({col})" if self._legacy_ts else col

    def _init_db(self):
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(CREATE_TABLES)

        # Check/set schema version
        cur = self._conn.execute("SELECT version FROM schema_version LIMIT 1")
        row = cur.fetchone()
        if row is None:
            self._conn.execute(
                "INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,)
            )
            self._conn.commit()
            log.debug("Database created at schema version %d", SCHEMA_VERSION)
        else:
            existing = row[0]
            if existing < SCHEMA_VERSION:
                self._migrate(existing)

        log.info("Database initialised: %s (schema v%d)", self.db_path, SCHEMA_VERSION)

    def _migrate(self, from_version: int):
        """Apply incremental schema migrations."""
        log.info("Migrating DB schema from v%d to v%d", from_version, SCHEMA_VERSION)
        if from_version < 2:
            try:
                self._conn.execute(_MIGRATE_V1_TO_V2)
                log.debug("Applied migration: v1→v2 (added anomaly_flags column)")
            except sqlite3.OperationalError as e:
                if "duplicate column" not in str(e).lower():
                    raise
        if from_version < 3:
            # The positions table itself comes from CREATE_TABLES. Seed it
            # with each drone's last stored location so older data still
            # exports at least one point.
            seeded = 0
            for row in self._conn.execute(
                    "SELECT mac, last_seen, data_json FROM drones").fetchall():
                try:
                    loc = (json.loads(row["data_json"] or "{}") or {}).get("location") or {}
                except (TypeError, ValueError):
                    continue
                if not isinstance(loc, dict):
                    continue
                lat, lon = loc.get("latitude"), loc.get("longitude")
                if lat is None or lon is None:
                    continue
                self._conn.execute(_POSITION_INSERT, (
                    row["mac"], row["last_seen"], lat, lon,
                    loc.get("altitude_geo"), loc.get("altitude_msl"),
                    loc.get("height_agl"), loc.get("speed_h"),
                    loc.get("speed_v"), loc.get("direction"),
                ))
                seeded += 1
            log.debug("Applied migration: v2→v3 (positions table, %d seeded)", seeded)
        if from_version < 4:
            # Before v4, timestamps were naive local time; they are now UTC
            # ISO strings with an offset. Rewrite the old rows so string
            # comparisons in --since filters are correct.
            fixed = 0
            for table, key, col in (("drones", "mac", "first_seen"),
                                    ("drones", "mac", "last_seen"),
                                    ("frames", "id", "timestamp"),
                                    ("positions", "rowid", "ts")):
                rows = self._conn.execute(
                    f"SELECT {key} AS k, {col} AS v FROM {table} "  # noqa: S608 - constant identifiers
                    f"WHERE {col} NOT LIKE '%+%' AND {col} NOT LIKE '%Z' AND {col} NOT LIKE '%-__:__'"
                ).fetchall()
                for row in rows:
                    dt = _parse_dt(row["v"])
                    if dt is not None:
                        self._conn.execute(
                            f"UPDATE {table} SET {col} = ? WHERE {key} = ?",  # noqa: S608
                            (dt.isoformat(), row["k"]),
                        )
                        fixed += 1
            log.debug("Applied migration: v3→v4 (%d naive timestamps rewritten as UTC)", fixed)
        self._conn.execute(
            "UPDATE schema_version SET version = ?", (SCHEMA_VERSION,)
        )
        self._conn.commit()
        log.info("Database migration complete")

    _SYNCED_PRUNE_MIN = 256

    def _prune_synced_locked(self):
        """Drop ``_synced`` entries whose DroneState is gone (evicted).

        Caller must hold ``self._lock``. A pruned MAC that reappears gets a
        new DroneState, which counts from zero anyway. The threshold doubles
        with the live size so pruning stays amortised O(1) per upsert.
        """
        dead = [mac for mac, (ref, _) in self._synced.items() if ref() is None]
        for mac in dead:
            del self._synced[mac]
        self._synced_prune_at = max(self._SYNCED_PRUNE_MIN, 2 * len(self._synced))
        if dead:
            log.debug("Pruned %d stale _synced entries (%d remain)", len(dead), len(self._synced))

    def _commit_locked(self):
        """Commit pending writes. Caller must hold ``self._lock``."""
        if self._conn is None or self.read_only:
            return
        self._conn.commit()
        self._pending = 0
        self._last_commit_time = time.monotonic()

    def commit_if_due(self, force: bool = False) -> bool:
        """Commit batched writes if the time interval has elapsed.

        Intended for the writer thread's idle ticks so the last batch is not
        left uncommitted when frames stop arriving. Returns True if a commit
        happened.
        """
        with self._lock:
            if self._conn is None or self.read_only or self._pending == 0:
                return False
            due = (time.monotonic() - self._last_commit_time) >= self._COMMIT_INTERVAL_SECS
            if not (due or force):
                return False
            self._commit_locked()
            log.debug("DB idle commit: total_writes=%d", self._write_count)
            return True

    def update_drone(self, drone: DroneState):
        """Upsert drone state, merging with the stored row.

        ``frame_count`` grows by the frames seen since this DroneState was
        last upserted (a re-created DroneState, after eviction or in a new
        session, counts from zero). The stored ``first_seen`` and a known
        ``uas_id`` are kept, and ``data_json`` is made consistent with them.
        Stored anomaly flags are merged with the current ones (earliest
        first-seen time per category), so a clean session does not erase them.
        """
        log.debug(
            "Upserting drone %s (frames=%d, anomalies=%d)",
            drone.mac, drone.frame_count, len(drone.anomalies),
        )
        d = drone.to_dict()
        new_anomalies = {
            cat: {
                "first_seen": as_utc(ts).isoformat(),
                "description": drone.anomaly_descriptions.get(cat, cat),
            }
            for cat, ts in list(drone.anomalies.items())
        }
        first_seen = as_utc(drone.first_seen)
        last_seen = as_utc(drone.last_seen)
        with self._lock:
            if self._conn is None:
                log.debug("update_drone after close ignored (%s)", drone.mac)
                return
            prev = self._synced.get(drone.mac)
            if prev is not None and prev[0]() is drone:
                delta = max(0, drone.frame_count - prev[1])
            else:
                delta = drone.frame_count
            self._synced[drone.mac] = (weakref.ref(drone), drone.frame_count)
            if len(self._synced) > self._synced_prune_at:
                self._prune_synced_locked()

            row = self._conn.execute(
                "SELECT uas_id, first_seen, last_seen, frame_count, anomaly_flags, data_json "
                "FROM drones WHERE mac = ?", (drone.mac,),
            ).fetchone()
            uas_id = drone.uas_id
            total = delta
            old_anomalies: dict = {}
            if row is not None:
                try:
                    old = json.loads(row["data_json"] or "{}") or {}
                except (TypeError, ValueError):
                    old = {}
                if not isinstance(old, dict):
                    old = {}
                old_anomalies = _stored_anomaly_state(row, old)
                total = (row["frame_count"] or 0) + delta
                old_first = _parse_dt(row["first_seen"])
                old_last = _parse_dt(row["last_seen"])
                if old_first is not None and old_first < first_seen:
                    first_seen = old_first
                if old_last is not None and old_last > last_seen:
                    last_seen = old_last
                if uas_id is None and row["uas_id"]:
                    uas_id = row["uas_id"]
                    # Keep the stored Basic ID(s) until a new one is seen
                    for key in ("basic_id", "basic_ids"):
                        if old.get(key) and key not in d:
                            d[key] = old[key]
            # Anomalies persist across sessions: merge stored + current
            anomaly_state = _merge_anomalies(old_anomalies, new_anomalies)
            details = {v["description"]: v["first_seen"] for v in anomaly_state.values()}
            anomaly_json = json.dumps(details) if details else None
            d["anomaly_state"] = anomaly_state
            d["anomaly_details"] = details
            d["anomalies"] = list(details)
            d["first_seen"] = first_seen.isoformat()
            d["last_seen"] = last_seen.isoformat()
            d["frame_count"] = total
            d["duration_s"] = round((last_seen - first_seen).total_seconds(), 1)
            data_json = json.dumps(d)

            self._conn.execute(
                """INSERT INTO drones (mac, uas_id, first_seen, last_seen, frame_count, anomaly_flags, data_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(mac) DO UPDATE SET
                     uas_id = COALESCE(excluded.uas_id, drones.uas_id),
                     first_seen = excluded.first_seen,
                     last_seen = excluded.last_seen,
                     frame_count = excluded.frame_count,
                     anomaly_flags = excluded.anomaly_flags,
                     data_json = excluded.data_json
                """,
                (
                    drone.mac,
                    uas_id,
                    d["first_seen"],
                    d["last_seen"],
                    total,
                    anomaly_json,
                    data_json,
                ),
            )
            self._pending += 1
        # No commit here: log_frame() / commit_if_due() handle batched commits

    def log_frame(self, frame: ODIDFrame, timestamp: Optional[datetime] = None):
        """Log a raw frame, and each Location fix with a lat/lon in it.

        The timestamp is ``timestamp``, else the frame's capture time, else now.
        """
        ts = as_utc(timestamp or frame.timestamp or utcnow()).isoformat()
        msg_types = _message_types(frame.messages)

        frame_data = {
            "source_mac": frame.source_mac,
            "signal_dbm": frame.signal_dbm,
            "channel": frame.channel,
            "frame_type": frame.frame_type,
            "message_counter": frame.message_counter,
            "proto_version": frame.proto_version,
        }

        with self._lock:
            if self._conn is None:
                log.debug("log_frame after close ignored (%s)", frame.source_mac)
                return
            self._conn.execute(
                """INSERT INTO frames (timestamp, mac, signal_dbm, channel, frame_type, message_types, data_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    ts,
                    frame.source_mac,
                    frame.signal_dbm,
                    frame.channel,
                    frame.frame_type,
                    msg_types,
                    json.dumps(frame_data),
                ),
            )
            for loc in _iter_locations(frame.messages):
                if loc.latitude is None or loc.longitude is None:
                    continue
                self._conn.execute(_POSITION_INSERT, (
                    frame.source_mac, ts, loc.latitude, loc.longitude,
                    loc.altitude_geo, loc.altitude_msl, loc.height_agl,
                    loc.speed_horizontal, loc.speed_vertical, loc.direction_deg,
                ))
            self._write_count += 1
            self._pending += 1
            time_due = (time.monotonic() - self._last_commit_time) >= self._COMMIT_INTERVAL_SECS
            count_due = self._write_count % self._COMMIT_INTERVAL_FRAMES == 0
            if time_due or count_due:
                self._commit_locked()
                log.debug("DB commit: total_writes=%d mac=%s", self._write_count, frame.source_mac)

    _PRUNE_BATCH = 2000

    def prune(self, older_than: datetime, should_stop=None) -> dict[str, int]:
        """Delete frames, positions and drones older than ``older_than``.

        A drone row goes once its ``last_seen`` is older. Deletes run in
        small batches, each its own transaction, with the lock released in
        between so capture callbacks are never held up for long.
        ``should_stop()`` is checked between batches. Freed pages are reused
        by later inserts (the file does not shrink). Returns rows deleted
        per table.
        """
        cutoff = as_utc(older_than).isoformat()
        removed = {"frames": 0, "positions": 0, "drones": 0}
        for table, col in (("frames", "timestamp"), ("positions", "ts")):
            while True:
                if should_stop is not None and should_stop():
                    return removed
                with self._lock:
                    if self._conn is None or self.read_only:
                        return removed
                    n = self._conn.execute(
                        f"DELETE FROM {table} WHERE id IN "
                        f"(SELECT id FROM {table} WHERE {col} < ? LIMIT ?)",
                        (cutoff, self._PRUNE_BATCH),
                    ).rowcount
                    self._commit_locked()
                removed[table] += n
                if n < self._PRUNE_BATCH:
                    break
                time.sleep(0.02)   # let capture threads at the lock
        with self._lock:
            if self._conn is None or self.read_only:
                return removed
            macs = [r[0] for r in self._conn.execute(
                "SELECT mac FROM drones WHERE last_seen < ?", (cutoff,))]
            if macs:
                self._conn.execute("DELETE FROM drones WHERE last_seen < ?", (cutoff,))
                self._commit_locked()
                # A drone still held in memory re-inserts with its full count
                for mac in macs:
                    self._synced.pop(mac, None)
            removed["drones"] = len(macs)
        return removed

    # ------------------------------------------------------------------
    # Query API
    # ------------------------------------------------------------------

    # Query methods return empty results (or None / zero counts) once the
    # database is closed, matching the writes, which are no-ops after close().

    def get_all_drones(self) -> list[dict]:
        """Get all drones from database, newest first."""
        with self._lock:
            if self._conn is None:
                return []
            cur = self._conn.execute(
                f"SELECT data_json FROM drones ORDER BY {self._ts('last_seen')} DESC")
            rows = cur.fetchall()
        return [json.loads(row[0]) for row in rows]

    def get_drone_by_uas_id(self, uas_id: str) -> Optional[dict]:
        """Look up a drone by exact UAS ID."""
        log.debug("Query: uas_id=%r", uas_id)
        with self._lock:
            if self._conn is None:
                return None
            row = self._conn.execute(
                "SELECT data_json FROM drones WHERE uas_id = ?", (uas_id,)
            ).fetchone()
        return json.loads(row[0]) if row else None

    def query_drones(
        self,
        since: Optional[datetime] = None,
        uas_id: Optional[str] = None,
        mac: Optional[str] = None,
        anomalies_only: bool = False,
        limit: int = 100,
    ) -> list[dict]:
        """Flexible drone query.

        Args:
            since: Return drones last seen after this datetime.
            uas_id: Partial match on UAS ID (LIKE %value%).
            mac: Exact MAC address match.
            anomalies_only: Only return drones with anomaly flags.
            limit: Maximum number of results.

        Returns:
            List of drone dicts, newest first.
        """
        conditions = []
        params: list = []

        if since is not None:
            conditions.append(f"{self._ts('last_seen')} >= ?")
            params.append(as_utc(since).isoformat())
            log.debug("Query filter: since=%s", since)

        if uas_id is not None:
            conditions.append("uas_id LIKE ?")
            params.append(f"%{uas_id}%")
            log.debug("Query filter: uas_id LIKE %%%s%%", uas_id)

        if mac is not None:
            conditions.append("mac = ?")
            params.append(mac)
            log.debug("Query filter: mac=%s", mac)

        if anomalies_only:
            conditions.append("anomaly_flags IS NOT NULL")
            log.debug("Query filter: anomalies_only")

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = (f"SELECT data_json FROM drones {where} "
               f"ORDER BY {self._ts('last_seen')} DESC LIMIT ?")
        params.append(limit)

        log.debug("Query SQL: %s  params=%s", sql, params)
        with self._lock:
            if self._conn is None:
                return []
            fetched = self._conn.execute(sql, params).fetchall()
        rows = [json.loads(row[0]) for row in fetched]
        log.debug("Query returned %d rows", len(rows))
        return rows

    def positions_for(self, mac: str) -> list[dict]:
        """Return the stored track for ``mac``, oldest first.

        Keys: ts (ISO), latitude, longitude, altitude_geo, altitude_msl,
        height_agl, speed_horizontal, speed_vertical, direction_deg. Returns
        [] for a pre-v3 database (opened read-only) with no positions table.
        """
        with self._lock:
            if self._conn is None:
                return []
            try:
                fetched = self._conn.execute(
                    "SELECT ts, lat, lon, alt_geo, alt_baro, height, speed_h, speed_v, "
                    f"direction FROM positions WHERE mac = ? ORDER BY {self._ts('ts')}, id", (mac,),
                ).fetchall()
            except sqlite3.OperationalError as e:
                if "no such table" in str(e).lower():
                    return []
                raise
        return [
            {
                "ts": r["ts"],
                "latitude": r["lat"],
                "longitude": r["lon"],
                "altitude_geo": r["alt_geo"],
                "altitude_msl": r["alt_baro"],
                "height_agl": r["height"],
                "speed_horizontal": r["speed_h"],
                "speed_vertical": r["speed_v"],
                "direction_deg": r["direction"],
            }
            for r in fetched
        ]

    def query_frames(
        self,
        mac: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 200,
    ) -> list[dict]:
        """Query raw frame log.

        Args:
            mac: Filter by source MAC.
            since: Only frames after this datetime.
            limit: Maximum results.
        """
        conditions = []
        params: list = []

        if mac:
            conditions.append("mac = ?")
            params.append(mac)
        if since:
            conditions.append(f"{self._ts('timestamp')} >= ?")
            params.append(as_utc(since).isoformat())

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = (
            f"SELECT timestamp, mac, signal_dbm, channel, frame_type, message_types "
            f"FROM frames {where} ORDER BY {self._ts('timestamp')} DESC LIMIT ?"
        )
        params.append(limit)

        log.debug("Frame query SQL: %s  params=%s", sql, params)
        with self._lock:
            if self._conn is None:
                return []
            fetched = self._conn.execute(sql, params).fetchall()
        return [dict(row) for row in fetched]

    def get_stats(self) -> dict:
        """Return high-level database statistics."""
        with self._lock:
            c = self._conn
            if c is None:
                drone_count = frame_count = anomaly_count = 0
                earliest = latest = None
            else:
                drone_count = c.execute("SELECT COUNT(*) FROM drones").fetchone()[0]
                frame_count = c.execute("SELECT COUNT(*) FROM frames").fetchone()[0]
                try:
                    anomaly_count = c.execute(
                        "SELECT COUNT(*) FROM drones WHERE anomaly_flags IS NOT NULL"
                    ).fetchone()[0]
                except sqlite3.OperationalError:
                    anomaly_count = 0   # v1 schema opened read-only
                ts = self._ts("timestamp")
                earliest = c.execute(f"SELECT MIN({ts}) FROM frames").fetchone()[0]
                latest = c.execute(f"SELECT MAX({ts}) FROM frames").fetchone()[0]
        return {
            "drones": drone_count,
            "frames": frame_count,
            "drones_with_anomalies": anomaly_count,
            "earliest_frame": earliest,
            "latest_frame": latest,
            "db_path": str(self.db_path),
            "db_size_bytes": self.db_path.stat().st_size if self.db_path.exists() else 0,
        }

    def close(self):
        """Flush and close the database."""
        with self._lock:
            if self._conn:
                try:
                    if not self.read_only:
                        self._conn.commit()
                        try:
                            # Fold the WAL into the main file so read-only
                            # readers (immutable fallback) see everything
                            self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                        except sqlite3.Error:
                            log.debug("WAL checkpoint failed", exc_info=True)
                finally:
                    self._conn.close()
                    self._conn = None
                log.info("Database closed: %s", self.db_path)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def parse_since(since_str: str) -> datetime:
    """Parse a relative time string like '1h', '30m', '2d' into a datetime.

    Also accepts ISO 8601 datetime strings (naive ones are local time).
    Returns a UTC-aware datetime.
    """
    s = since_str.strip().lower()
    try:
        now = datetime.now(timezone.utc)
        if s.endswith("m"):
            return now - timedelta(minutes=float(s[:-1]))
        if s.endswith("h"):
            return now - timedelta(hours=float(s[:-1]))
        if s.endswith("d"):
            return now - timedelta(days=float(s[:-1]))
        # Try ISO format
        return as_utc(datetime.fromisoformat(since_str.strip()))
    except (ValueError, TypeError) as e:
        raise ValueError(f"Cannot parse time spec {since_str!r}: {e}") from e
