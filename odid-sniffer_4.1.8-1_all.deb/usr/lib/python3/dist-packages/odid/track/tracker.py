"""Drone tracker - correlates ODID messages into per-drone state."""

import heapq
import logging
import threading
import time
from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from odid.decode.frame import ODIDFrame
from odid.decode.messages import (
    BasicIdMessage,
    LocationMessage,
    AuthMessage,
    SelfIdMessage,
    SystemMessage,
    OperatorIdMessage,
    MessagePack,
)

log = logging.getLogger(__name__)

# Anomaly thresholds
MAX_PLAUSIBLE_SPEED_MS = 100.0    # m/s (~360 km/h)
MAX_PLAUSIBLE_ALT_MSL = 10_000.0  # metres
MISSING_BASIC_ID_FRAMES = 10      # warn if no Basic ID after this many frames
LOCATION_HISTORY_CAP = 1000

# Memory caps for unbounded metadata sets
CHANNELS_SEEN_CAP = 20      # max unique channels tracked per drone
FRAME_TYPES_SEEN_CAP = 16   # small fixed set of known ODID frame types
ANOMALIES_CAP = 32          # max distinct anomaly categories per drone
MAX_DRONES_DEFAULT = 2000   # live-capture cap on tracked drones (odid.cli)
_CAP_WARN_INTERVAL = 60.0   # seconds between "tracker full" warnings

# Basic ID selection priority for the primary UAS ID (F3411 allows a UA to send
# more than one Basic ID): Serial Number > CAA Registration > UTM UUID >
# Specific Session ID > anything else.
BASIC_ID_PRIORITY = (1, 2, 3, 4)


def utcnow() -> datetime:
    """Current time as a UTC-aware datetime."""
    return datetime.now(timezone.utc)


def as_utc(dt: Optional[datetime]) -> Optional[datetime]:
    """Normalise a datetime to UTC-aware. Naive values are taken as local time."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.astimezone(timezone.utc)
    return dt.astimezone(timezone.utc) if dt.utcoffset() else dt


def _basic_id_rank(id_type) -> int:
    try:
        return BASIC_ID_PRIORITY.index(id_type)
    except ValueError:
        return len(BASIC_ID_PRIORITY)


@dataclass
class SignalStats:
    """Running signal strength statistics."""
    current: Optional[int] = None
    min_dbm: Optional[int] = None
    max_dbm: Optional[int] = None
    _sum: float = 0.0
    _count: int = 0

    def update(self, dbm: int):
        self.current = dbm
        self._sum += dbm
        self._count += 1
        if self.min_dbm is None or dbm < self.min_dbm:
            self.min_dbm = dbm
        if self.max_dbm is None or dbm > self.max_dbm:
            self.max_dbm = dbm

    @property
    def average(self) -> Optional[float]:
        return self._sum / self._count if self._count > 0 else None


@dataclass
class DroneState:
    """Aggregated state for a single drone identified by MAC address."""
    mac: str
    first_seen: datetime = field(default_factory=utcnow)
    last_seen: datetime = field(default_factory=utcnow)
    frame_count: int = 0
    signal: SignalStats = field(default_factory=SignalStats)

    # Latest Basic ID per id_type; see the ``basic_id`` property
    basic_ids: dict = field(default_factory=dict)
    # Latest decoded data per message type
    location: Optional[LocationMessage] = None
    # Most recent Location that carried a valid lat/lon
    last_valid_location: Optional[LocationMessage] = None
    auth: Optional[AuthMessage] = None
    self_id: Optional[SelfIdMessage] = None
    system: Optional[SystemMessage] = None
    operator_id: Optional[OperatorIdMessage] = None

    # Flight path history: bounded deque for O(1) append/pop
    location_history: deque = field(default_factory=lambda: deque(maxlen=LOCATION_HISTORY_CAP))

    # Anomaly flags keyed by fixed category: {category -> first_seen_timestamp}
    anomalies: dict = field(default_factory=dict)
    # Latest human-readable description per category (may include a value)
    anomaly_descriptions: dict = field(default_factory=dict)

    # Bounded channel/frame-type counters, no unbounded growth
    channels_seen: Counter = field(default_factory=Counter)
    frame_types_seen: Counter = field(default_factory=Counter)

    # Lock of the DroneTracker that owns this state (set by the tracker), so
    # readers outside the tracker can take a consistent snapshot.
    _tracker_lock: Optional[object] = field(default=None, init=False, repr=False, compare=False)

    def __setattr__(self, name, value):
        # first_seen/last_seen are always UTC-aware, so callers that assign
        # naive (local) datetimes cannot break comparisons.
        if name in ("first_seen", "last_seen") and isinstance(value, datetime):
            value = as_utc(value)
        object.__setattr__(self, name, value)

    @property
    def basic_id(self) -> Optional[BasicIdMessage]:
        """Primary Basic ID, chosen by fixed id_type priority (see BASIC_ID_PRIORITY).

        Basic IDs with an empty UAS ID rank after those with a value.
        """
        if not self.basic_ids:
            return None
        return min(
            self.basic_ids.items(),
            key=lambda kv: (not kv[1].uas_id, _basic_id_rank(kv[0])),
        )[1]

    @basic_id.setter
    def basic_id(self, msg: Optional[BasicIdMessage]):
        """Store ``msg`` under its id_type; ``None`` clears all Basic IDs."""
        if msg is None:
            self.basic_ids.clear()
        else:
            self.basic_ids[getattr(msg, "id_type", 0)] = msg

    @property
    def uas_id(self) -> Optional[str]:
        """Primary drone identifier from the primary Basic ID."""
        bid = self.basic_id
        if bid and bid.uas_id:
            return bid.uas_id
        return None

    @property
    def duration_seconds(self) -> float:
        return (self.last_seen - self.first_seen).total_seconds()

    @property
    def anomaly_list(self) -> list[str]:
        """Anomaly descriptions as a plain list (for backward compat)."""
        return [self.anomaly_descriptions.get(k, k) for k in list(self.anomalies)]

    def to_dict(self) -> dict:
        """Serialize to dict for JSON/DB storage."""
        d = {
            "mac": self.mac,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "frame_count": self.frame_count,
            "duration_s": round(self.duration_seconds, 1),
            # Bounded: top-N most-seen channels/types
            "channels_seen": sorted(
                dict(self.channels_seen.most_common(CHANNELS_SEEN_CAP)).keys()
            ),
            "frame_types_seen": sorted(
                dict(self.frame_types_seen.most_common(FRAME_TYPES_SEEN_CAP)).keys()
            ),
            # Anomalies with first-seen timestamps
            "anomalies": self.anomaly_list,
            "anomaly_details": {
                self.anomaly_descriptions.get(k, k): v.isoformat()
                for k, v in list(self.anomalies.items())
            },
            "signal": {
                "current": self.signal.current,
                "min": self.signal.min_dbm,
                "max": self.signal.max_dbm,
                "avg": round(self.signal.average, 1) if self.signal.average else None,
            },
        }

        def _bid(b):
            return {
                "id_type": b.id_type_name,
                "ua_type": b.ua_type_name,
                "uas_id": b.uas_id,
            }

        primary = self.basic_id
        if primary:
            d["basic_id"] = _bid(primary)
            d["basic_ids"] = [
                _bid(b) for _, b in sorted(
                    self.basic_ids.items(), key=lambda kv: _basic_id_rank(kv[0]))
            ]

        def _loc(loc):
            return {
                "status": loc.status_name,
                "latitude": loc.latitude,
                "longitude": loc.longitude,
                "altitude_msl": loc.altitude_msl,
                "altitude_geo": loc.altitude_geo,
                "height_agl": loc.height_agl,
                "height_type": loc.height_type_name,
                "speed_h": loc.speed_horizontal,
                "speed_v": loc.speed_vertical,
                "direction": loc.direction_deg,
            }

        if self.location:
            d["location"] = _loc(self.location)
        if self.last_valid_location:
            d["last_valid_location"] = _loc(self.last_valid_location)

        if self.self_id:
            d["self_id"] = {
                "desc_type": self.self_id.desc_type_name,
                "description": self.self_id.description,
            }

        if self.system:
            sys = self.system
            d["system"] = {
                "operator_lat": sys.operator_latitude,
                "operator_lon": sys.operator_longitude,
                "area_radius": sys.area_radius,
                "area_ceiling": sys.area_ceiling,
                "area_floor": sys.area_floor,
                "operator_alt": sys.operator_altitude,
            }

        if self.operator_id:
            d["operator_id"] = {
                "type": self.operator_id.operator_id_type,
                "id": self.operator_id.operator_id,
            }

        if self.auth:
            d["auth"] = {
                "auth_type": self.auth.auth_type_name,
                "page": self.auth.page_number,
                "last_page": self.auth.last_page_index,
            }

        return d

    def location_history_as_dicts(self) -> list[dict]:
        """Return location history as list of serializable dicts."""
        result = []
        for ts, loc in list(self.location_history):
            result.append({
                "timestamp": ts.isoformat(),
                "latitude": loc.latitude,
                "longitude": loc.longitude,
                "altitude_msl": loc.altitude_msl,
                "altitude_geo": loc.altitude_geo,
                "height_agl": loc.height_agl,
                "speed_h": loc.speed_horizontal,
                "speed_v": loc.speed_vertical,
                "direction": loc.direction_deg,
                "status": loc.status_name,
            })
        return result


class DroneTracker:
    """Tracks all detected drones and their state.

    Thread-safe: ``process_frame`` may be called from several capture threads
    while ``evict_stale`` runs on a timer thread and readers take snapshots.
    All state changes happen under an internal re-entrant lock. Update
    callbacks run while the lock is held (so they see a consistent
    DroneState and may call back into the tracker); evict callbacks run after
    the lock is released.

    ``max_drones`` (0 = no limit) caps how many drones are held: a new MAC
    beyond it evicts the least recently heard drones (1% of the cap at a
    time), so random-MAC floods cannot grow memory without bound.
    """

    def __init__(self, max_drones: int = 0):
        self._lock = threading.RLock()
        self._drones: dict[str, DroneState] = {}
        self._max_drones = max(0, int(max_drones))
        self._cap_evicted = 0          # evictions since the last warning
        self._cap_warned_at: Optional[float] = None
        self._total_frames: int = 0
        # wall clock minus capture time of the latest frame (non-zero in replay)
        self._clock_offset = None
        self._callbacks: list = []
        self._evict_callbacks: list = []
        log.debug("DroneTracker initialised")

    @property
    def lock(self) -> threading.RLock:
        """The tracker lock, for callers that need a consistent multi-step read."""
        return self._lock

    @property
    def drones(self) -> dict[str, DroneState]:
        """Shallow-copied snapshot of {mac: DroneState}."""
        with self._lock:
            return dict(self._drones)

    @property
    def total_frames(self) -> int:
        return self._total_frames

    def now(self) -> datetime:
        """Current time on the capture clock (UTC-aware).

        Live, this is the wall clock. When frames carry older capture
        timestamps (pcap replay), it is shifted back by the offset seen on the
        latest frame, so TTL eviction and "last seen" ages follow the capture
        timeline instead of evicting every replayed drone at once.
        """
        offset = self._clock_offset
        return utcnow() - offset if offset is not None else utcnow()

    @property
    def max_drones(self) -> int:
        return self._max_drones

    def set_max_drones(self, max_drones: int) -> int:
        """Change the cap (0 = no limit); evicts at once if now over it.

        Returns the number of drones evicted.
        """
        with self._lock:
            self._max_drones = max(0, int(max_drones))
            over = len(self._drones) - self._max_drones if self._max_drones else 0
            evicted = self._evict_oldest_locked(over) if over > 0 else []
        self._fire_evicted(evicted)
        return len(evicted)

    def _evict_oldest_locked(self, n: int) -> list[str]:
        """Remove the ``n`` least recently heard drones. Caller holds the lock."""
        oldest = heapq.nsmallest(n, self._drones.items(), key=lambda kv: kv[1].last_seen)
        macs = [mac for mac, _ in oldest]
        for mac in macs:
            del self._drones[mac]
        self._cap_evicted += len(macs)
        now = time.monotonic()
        if self._cap_warned_at is None or now - self._cap_warned_at >= _CAP_WARN_INTERVAL:
            log.warning("Tracker full (%d drones): evicted %d least recently heard drone(s) "
                        "to make room (random-MAC flood?)", self._max_drones, self._cap_evicted)
            self._cap_warned_at = now
            self._cap_evicted = 0
        return macs

    def _fire_evicted(self, macs) -> None:
        """Run evict callbacks for ``macs``. Call without holding the lock."""
        for mac in macs:
            for cb in list(self._evict_callbacks):
                try:
                    cb(mac)
                except Exception:
                    log.exception("Evict callback error in %s", cb)

    @property
    def drone_count(self) -> int:
        with self._lock:
            return len(self._drones)

    def snapshot(self) -> dict[str, dict]:
        """Return {mac: DroneState.to_dict()} taken under the lock."""
        with self._lock:
            return {mac: d.to_dict() for mac, d in self._drones.items()}

    def on_update(self, callback):
        """Register a callback for drone state updates.

        Callback signature: callback(drone: DroneState, frame: ODIDFrame)
        """
        self._callbacks.append(callback)
        log.debug("Registered update callback: %s", callback)

    def on_evict(self, callback):
        """Register a callback fired for each drone removed by ``evict_stale``.

        Callback signature: callback(mac: str)
        """
        self._evict_callbacks.append(callback)
        log.debug("Registered evict callback: %s", callback)

    def evict_stale(self, ttl_seconds: float = 300.0) -> int:
        """Remove drones not heard within ``ttl_seconds``.

        Returns the number of drones evicted.
        Call periodically from a background thread or timer.
        """
        with self._lock:
            now = self.now()
            stale = [
                mac for mac, drone in self._drones.items()
                if (now - drone.last_seen).total_seconds() >= ttl_seconds
            ]
            for mac in stale:
                del self._drones[mac]
                log.info("Evicted stale drone %s (not heard for >=%.0fs)", mac, ttl_seconds)
            remaining = len(self._drones)

        if stale:
            log.debug("Evicted %d stale drone(s); %d remain", len(stale), remaining)
            self._fire_evicted(stale)
        return len(stale)

    def process_frame(self, frame: ODIDFrame):
        """Process a decoded ODID frame and update drone state."""
        mac = frame.source_mac
        evicted: list[str] = []
        with self._lock:
            wall = utcnow()
            ts = as_utc(frame.timestamp) if frame.timestamp is not None else None
            if ts is None:
                # No capture time: stamp it on the current capture clock and
                # leave the replay offset alone, so one untimed frame cannot
                # snap now() to wall time and evict every replayed drone.
                offset = self._clock_offset
                now = wall - offset if offset is not None else wall
            else:
                now = ts
                offset = wall - ts
                # Treat small skews (live capture) as no offset
                self._clock_offset = offset if abs(offset.total_seconds()) > 5.0 else None
            self._total_frames += 1

            log.debug(
                "Processing frame #%d: mac=%s type=%s ch=%s signal=%s",
                self._total_frames, mac, frame.frame_type, frame.channel, frame.signal_dbm,
            )

            drone = self._drones.get(mac)
            if drone is None:
                if self._max_drones and len(self._drones) >= self._max_drones:
                    # Free 1% of the cap at once: the scan for the oldest
                    # then runs once per many new MACs during a flood
                    evicted = self._evict_oldest_locked(
                        len(self._drones) - self._max_drones + max(1, self._max_drones // 100))
                drone = self._drones[mac] = DroneState(mac=mac, first_seen=now, last_seen=now)
                drone._tracker_lock = self._lock
                log.info("New drone detected: %s", mac)

            if now > drone.last_seen:
                drone.last_seen = now
            if now < drone.first_seen:
                drone.first_seen = now
            drone.frame_count += 1

            if frame.signal_dbm is not None:
                drone.signal.update(frame.signal_dbm)

            if frame.channel is not None:
                drone.channels_seen[frame.channel] += 1
                # Prune to cap if Counter has grown too large; keep most-frequently-seen
                if len(drone.channels_seen) > CHANNELS_SEEN_CAP:
                    drone.channels_seen = Counter(
                        dict(drone.channels_seen.most_common(CHANNELS_SEEN_CAP))
                    )

            drone.frame_types_seen[frame.frame_type] += 1

            for msg in frame.messages:
                self._apply_message(drone, msg, now)

            self._check_anomalies(drone, now)

            for cb in list(self._callbacks):
                try:
                    cb(drone, frame)
                except Exception:
                    log.exception("Callback error in %s", cb)
        self._fire_evicted(evicted)

    def _apply_message(self, drone: DroneState, msg, ts: Optional[datetime] = None):
        """Apply a decoded message to drone state (``ts``: capture time)."""
        log.debug("Applying %s message to drone %s", getattr(msg, "msg_type", type(msg).__name__), drone.mac)

        if ts is None:
            ts = utcnow()
        if isinstance(msg, BasicIdMessage):
            drone.basic_id = msg          # stored per id_type
        elif isinstance(msg, LocationMessage):
            drone.location = msg
            if msg.latitude is not None and msg.longitude is not None:
                drone.last_valid_location = msg
            drone.location_history.append((ts, msg))
        elif isinstance(msg, AuthMessage):
            drone.auth = msg
        elif isinstance(msg, SelfIdMessage):
            drone.self_id = msg
        elif isinstance(msg, SystemMessage):
            drone.system = msg
        elif isinstance(msg, OperatorIdMessage):
            drone.operator_id = msg
        elif isinstance(msg, MessagePack):
            log.debug("  MessagePack: %d sub-messages", msg.message_count)
            for sub_msg in msg.messages:
                self._apply_message(drone, sub_msg, ts)

    def _check_anomalies(self, drone: DroneState, now: Optional[datetime] = None):
        """Run validity checks and populate drone.anomalies.

        Anomalies are keyed by a fixed category so repeated detections with
        different measured values don't grow the dict; the latest description
        (with value) is kept in ``drone.anomaly_descriptions``.
        """
        if now is None:
            now = utcnow()

        def _flag(category: str, description: str):
            if category not in drone.anomalies:
                if len(drone.anomalies) >= ANOMALIES_CAP:
                    return
                drone.anomalies[category] = now
                log.warning("Anomaly [%s]: %s", drone.mac, description)
            drone.anomaly_descriptions[category] = description

        loc = drone.location
        if loc is not None:
            if loc.speed_horizontal is not None and loc.speed_horizontal > MAX_PLAUSIBLE_SPEED_MS:
                _flag("implausible_speed",
                      f"Implausible horizontal speed: {loc.speed_horizontal:.1f} m/s")

            for label, alt in (("MSL", loc.altitude_msl), ("geodetic", loc.altitude_geo)):
                if alt is not None and alt > MAX_PLAUSIBLE_ALT_MSL:
                    _flag("implausible_altitude", f"Implausible altitude: {alt:.0f}m {label}")

        if drone.basic_id is None:
            if drone.frame_count >= MISSING_BASIC_ID_FRAMES:
                _flag("missing_basic_id", "No Basic ID received after initial frames")
        else:
            # State-based: clear once a Basic ID has arrived
            drone.anomalies.pop("missing_basic_id", None)
            drone.anomaly_descriptions.pop("missing_basic_id", None)

    def get_stats(self) -> dict:
        """Get tracker statistics."""
        with self._lock:
            return {
                "total_drones": len(self._drones),
                "total_frames": self._total_frames,
                "drones": {mac: d.to_dict() for mac, d in self._drones.items()},
            }
