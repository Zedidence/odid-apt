"""``odid provision``: configure the packaged service (odid.service).

Detects the radios on this Pi, asks (or takes from options) which ones the
service should run, and writes ``/etc/odid/config.toml``. Works headless:
every question has an option, and ``--yes`` accepts the defaults.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from odid.config import SERVICE_CONFIG_PATH, write_file

SERVICE_USER = "odid"
STATE_DIR = Path("/var/lib/odid")
SERVICE = "odid.service"
_BLADERF_IDS = {("2cf0", "5246"), ("2cf0", "5250")}


# ---------------------------------------------------------------------------
# Hardware detection (sysfs roots are parameters for tests)
# ---------------------------------------------------------------------------

@dataclass
class Hardware:
    wifi: list[dict] = field(default_factory=list)   # {"name", "has_ip"}
    bladerf: bool = False
    bt_adapters: list[str] = field(default_factory=list)


def detect(net=Path("/sys/class/net"), usb=Path("/sys/bus/usb/devices"),
           bt=Path("/sys/class/bluetooth")) -> Hardware:
    from odid.capture.interface import interface_has_ip
    hw = Hardware()
    try:
        for d in sorted(net.iterdir()):
            if (d / "phy80211").exists() or (d / "wireless").exists():
                hw.wifi.append({"name": d.name, "has_ip": interface_has_ip(d.name)})
    except OSError:
        pass
    try:
        for d in usb.iterdir():
            try:
                ids = ((d / "idVendor").read_text().strip(), (d / "idProduct").read_text().strip())
            except OSError:
                continue
            if ids in _BLADERF_IDS:
                hw.bladerf = True
    except OSError:
        pass
    try:
        hw.bt_adapters = sorted(d.name for d in bt.iterdir() if d.name.startswith("hci"))
    except OSError:
        pass
    return hw


def default_dongle(hw: Hardware) -> Optional[str]:
    """First wireless interface with no IP address (not carrying traffic)."""
    for w in hw.wifi:
        if not w["has_ip"]:
            return w["name"]
    return None


# ---------------------------------------------------------------------------
# Config building
# ---------------------------------------------------------------------------

@dataclass
class Choices:
    lat: Optional[float] = None
    lon: Optional[float] = None
    dongle: Optional[str] = None          # None = no WiFi dongle source
    dongle_channel: int = 6
    bladerf: Optional[str] = None         # "wifi" | "bt" | None
    bladerf_gain: int = 40
    builtin_bt: bool = False


def autostart_list(c: Choices) -> list[dict]:
    out: list[dict] = []
    if c.dongle:
        out.append({"source": "wifi-dongle", "interface": c.dongle, "channel": c.dongle_channel})
    if c.bladerf in ("wifi", "bt"):
        out.append({"source": f"bladerf-{c.bladerf}", "gain": c.bladerf_gain})
    if c.builtin_bt:
        out.append({"source": "builtin-bt"})
    return out


def merge_config(existing: dict, c: Choices) -> dict:
    """Apply the choices on top of the existing config (other keys kept)."""
    cfg = {k: (dict(v) if isinstance(v, dict) else v) for k, v in existing.items()}
    if c.lat is not None and c.lon is not None:
        cfg.setdefault("observer", {}).update({"lat": c.lat, "lon": c.lon})
    cfg.setdefault("serve", {})["autostart"] = autostart_list(c)
    return cfg


# ---------------------------------------------------------------------------
# Applying
# ---------------------------------------------------------------------------

def _service_gid() -> Optional[int]:
    import grp
    try:
        return grp.getgrnam(SERVICE_USER).gr_gid
    except KeyError:
        return None


def check_root_owned_dir(directory: Path) -> None:
    """As root, refuse to write into a directory another user controls
    (a planted symlink could redirect the write)."""
    if os.geteuid() != 0:
        return
    st = os.lstat(directory)
    import stat
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or st.st_mode & 0o022:
        raise OSError(f"{directory} must be a root-owned directory not writable by others "
                      f"(fix: sudo chown root:{SERVICE_USER} {directory} && "
                      f"sudo chmod 0750 {directory})")


def apply(cfg: dict, config_path: Path = SERVICE_CONFIG_PATH,
          state_dir: Path = STATE_DIR) -> Optional[Path]:
    """Write the config (root:odid 0640: the service reads it, only root
    edits it) and retire the saved source state so the new autostart list
    takes effect. Returns the backup path of the old state."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    check_root_owned_dir(config_path.parent)
    gid = _service_gid()
    owner = (0, gid) if os.geteuid() == 0 and gid is not None else None
    write_file(config_path, cfg, owner=owner, mode=0o640)
    state = state_dir / "serve-state.json"
    from odid.web.auth import _AsDirOwner
    with _AsDirOwner(state_dir):          # service-owned directory: act as its owner
        if os.path.lexists(state):
            backup = state.with_name(state.name + ".bak")
            os.replace(state, backup)
            return backup
    return None


def service_active() -> bool:
    if shutil.which("systemctl") is None:
        return False
    r = subprocess.run(["systemctl", "is-active", "--quiet", SERVICE], check=False)
    return r.returncode == 0


def restart_service() -> tuple[bool, str]:
    r = subprocess.run(["systemctl", "restart", SERVICE], check=False,
                       capture_output=True, text=True)
    return r.returncode == 0, r.stderr.strip()


NM_CONF = Path("/etc/NetworkManager/conf.d/90-odid-capture.conf")


def set_nm_unmanaged(dongle: Optional[str], conf: Path = NM_CONF,
                     reload: bool = True) -> Optional[str]:
    """Tell NetworkManager to leave the capture dongle alone (the service may
    not control NetworkManager itself). Removes the file when there is no
    dongle. Returns a message, or None if NetworkManager isn't installed."""
    if not conf.parent.is_dir():
        return None
    if dongle:
        conf.write_text("# Written by odid provision: the Remote ID capture dongle\n"
                        f"[keyfile]\nunmanaged-devices=interface-name:{dongle}\n")
        conf.chmod(0o644)
        msg = f"NetworkManager will leave {dongle} unmanaged"
    elif conf.exists():
        conf.unlink()
        msg = "NetworkManager capture-dongle exception removed"
    else:
        return None
    if reload and shutil.which("nmcli"):
        try:
            subprocess.run(["nmcli", "general", "reload", "conf"], check=False,
                           capture_output=True, timeout=30)
        except (OSError, subprocess.SubprocessError):
            msg += " (reload NetworkManager or reboot to apply)"
    return msg
