"""WiFi interface control - monitor mode, channel switching.

Uses subprocess instead of os.system() for safety and proper error handling.
"""

import logging
import re
import shutil
import subprocess
import time

log = logging.getLogger(__name__)

# What enable_monitor_mode changed per interface, so _rollback_managed and
# disable_monitor_mode can put back exactly that (in-process only):
#   {"nm_was_managed": bool | None, "supplicant": dict | None}
_saved_state: dict[str, dict] = {}


class InterfaceError(Exception):
    """Raised when interface operations fail."""


def run_cmd(args: list[str], check: bool = True, timeout: int = 10) -> subprocess.CompletedProcess:
    """Run a shell command safely via subprocess."""
    log.debug("Running: %s", " ".join(args))
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=check,
        )
        return result
    except subprocess.CalledProcessError as e:
        log.error("Command failed: %s\nstderr: %s", " ".join(args), e.stderr.strip())
        raise InterfaceError(f"Command failed: {' '.join(args)}: {e.stderr.strip()}") from e
    except subprocess.TimeoutExpired as e:
        raise InterfaceError(f"Command timed out: {' '.join(args)}") from e
    except FileNotFoundError as e:
        raise InterfaceError(f"Command not found: {args[0]} (is it installed?)") from e
    except OSError as e:
        raise InterfaceError(f"Could not run {args[0]}: {e}") from e


def get_interface_info(interface: str) -> dict:
    """Get interface info from iw dev.

    Returns dict with keys: type, channel, frequency, etc.
    """
    result = run_cmd(["iw", "dev", interface, "info"], check=False)
    if result.returncode != 0:
        raise InterfaceError(f"Interface {interface} not found")

    info = {}
    for line in result.stdout.splitlines():
        line = line.strip()
        if line.startswith("type "):
            info["type"] = line.split(None, 1)[1]
        elif line.startswith("channel "):
            # "channel 6 (2437 MHz), width: 20 MHz, center1: 2437 MHz"
            m = re.match(r"channel\s+(\d+)\s+\((\d+)\s+MHz\)", line)
            if m:
                info["channel"] = int(m.group(1))
                info["frequency"] = int(m.group(2))
    return info


def is_monitor_mode(interface: str) -> bool:
    """Check if interface is in monitor mode."""
    try:
        info = get_interface_info(interface)
        return info.get("type") == "monitor"
    except InterfaceError:
        return False


def interface_has_ip(interface: str) -> bool:
    """True if ``interface`` has an IPv4 or global IPv6 address.

    Such an interface carries network traffic (maybe the SSH session used to
    manage this Pi), so it must not be switched to monitor mode automatically.
    """
    import fcntl
    import socket
    import struct
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            fcntl.ioctl(s.fileno(), 0x8915,  # SIOCGIFADDR
                        struct.pack("256s", interface.encode()[:15]))
        return True
    except OSError:
        pass  # EADDRNOTAVAIL: no IPv4 address (or no such interface)
    try:
        with open("/proc/net/if_inet6") as f:
            for line in f:
                parts = line.split()
                # columns: addr ifindex prefixlen scope flags name; scope 00 = global
                if len(parts) >= 6 and parts[5] == interface and parts[3] == "00":
                    return True
    except OSError:
        pass
    return False


def get_current_channel(interface: str) -> int | None:
    """Get current channel of interface."""
    try:
        info = get_interface_info(interface)
        return info.get("channel")
    except InterfaceError:
        return None


def set_channel(interface: str, channel: int) -> None:
    """Set WiFi channel."""
    run_cmd(["iw", "dev", interface, "set", "channel", str(channel)])
    log.info("Set %s to channel %d", interface, channel)


def enable_monitor_mode(interface: str, channel: int = 6) -> None:
    """Put interface into monitor mode on specified channel.

    Steps:
      1. Tell NetworkManager to stop managing the interface (if NM is running)
      2. Kill wpa_supplicant on this interface (if running)
      3. Bring interface down
      4. Set type monitor
      5. Bring interface up
      6. Set channel
    """
    log.info("Enabling monitor mode on %s, channel %d", interface, channel)

    # Record the starting mode/channel so a failure only undoes what this
    # call changed (an interface already in monitor mode, maybe in use by a
    # running capture, must not be flipped back to managed).
    try:
        orig = get_interface_info(interface)
    except InterfaceError:
        orig = {}
    already_monitor = orig.get("type") == "monitor"

    # Remember what we change so rollback/disable restore only that.
    state = {"nm_was_managed": _nm_device_managed(interface), "supplicant": None}
    _saved_state[interface] = state

    # NetworkManager (default on Raspberry Pi OS Bookworm) runs one global
    # wpa_supplicant without -i, so killing by interface does nothing and NM
    # would flip the interface back to managed mode.  Unmanage it instead.
    _set_nm_managed(interface, False)

    # Kill wpa_supplicant for this interface only (dhcpcd / ifupdown /
    # wpa_supplicant@IF setups); remember how it ran so it can be restarted.
    state["supplicant"] = _kill_wpa_supplicant(interface)

    if already_monitor:
        # Already in monitor mode: no down/type change needed, just make sure
        # it is up and switch channel.  On failure restore the old channel.
        try:
            run_cmd(["ip", "link", "set", interface, "up"])
            set_channel(interface, channel)
        except Exception:
            log.error("Setting up %s (already in monitor mode) failed; keeping "
                      "monitor mode", interface)
            _rollback_monitor(interface, orig.get("channel"))
            raise
        log.info("Monitor mode enabled on %s channel %d", interface, channel)
        return

    # Down -> monitor -> up -> channel.  On any failure, try to put the
    # interface back the way NetworkManager expects (managed, up, NM-managed)
    # so a bad choice of interface doesn't cut off e.g. an SSH session.
    try:
        run_cmd(["ip", "link", "set", interface, "down"])
        run_cmd(["iw", "dev", interface, "set", "type", "monitor"])
        run_cmd(["ip", "link", "set", interface, "up"])
        set_channel(interface, channel)
    except Exception:
        log.error("Enabling monitor mode on %s failed; restoring managed mode", interface)
        _rollback_managed(interface)
        raise

    log.info("Monitor mode enabled on %s channel %d", interface, channel)


def _rollback_monitor(interface: str, channel: int | None) -> None:
    """Best-effort undo for an interface that was already in monitor mode.

    Keeps monitor mode, brings the link up and restores the previous channel.
    NetworkManager / wpa_supplicant are restored only if this call changed
    them (NM known to have been managing it, or a supplicant was killed).
    """
    steps = [["ip", "link", "set", interface, "up"]]
    if channel is not None:
        steps.append(["iw", "dev", interface, "set", "channel", str(channel)])
    for args in steps:
        try:
            run_cmd(args, check=False)
        except Exception:
            log.warning("Rollback step failed: %s", " ".join(args), exc_info=True)
    state = _saved_state.pop(interface, None) or {}
    if state.get("nm_was_managed") is True:
        try:
            _set_nm_managed(interface, True)
        except Exception:
            log.warning("Could not re-enable NetworkManager on %s", interface,
                        exc_info=True)
    if state.get("supplicant"):
        try:
            _restart_wpa_supplicant(interface, state["supplicant"])
        except Exception:
            log.warning("Could not restart wpa_supplicant on %s; restore "
                        "connectivity manually", interface, exc_info=True)


def _rollback_managed(interface: str) -> None:
    """Best-effort restore of managed mode after a failed enable."""
    for args in (
        ["ip", "link", "set", interface, "down"],
        ["iw", "dev", interface, "set", "type", "managed"],
        ["ip", "link", "set", interface, "up"],
    ):
        try:
            run_cmd(args, check=False)
        except Exception:
            log.warning("Rollback step failed: %s", " ".join(args), exc_info=True)
    _restore_connectivity(interface)


def disable_monitor_mode(interface: str) -> None:
    """Restore interface to managed mode."""
    log.info("Disabling monitor mode on %s", interface)
    run_cmd(["ip", "link", "set", interface, "down"])
    run_cmd(["iw", "dev", interface, "set", "type", "managed"])
    run_cmd(["ip", "link", "set", interface, "up"])
    _restore_connectivity(interface)


def _restore_connectivity(interface: str) -> None:
    """Best effort: undo the NM-unmanage and wpa_supplicant kill done by enable.

    Without a record (enable ran in another process) NM management is
    re-enabled as before, and no supplicant is started.
    """
    state = _saved_state.pop(interface, None)
    # Re-manage unless we know NM was *not* managing it beforehand.
    if state is None or state.get("nm_was_managed") is not False:
        try:
            _set_nm_managed(interface, True)
        except Exception:
            log.warning("Could not re-enable NetworkManager on %s", interface,
                        exc_info=True)
    if state and state.get("supplicant"):
        try:
            _restart_wpa_supplicant(interface, state["supplicant"])
        except Exception:
            log.warning("Could not restart wpa_supplicant on %s; restore "
                        "connectivity manually", interface, exc_info=True)


def list_interfaces() -> list[dict]:
    """List WiFi interfaces and their status."""
    result = run_cmd(["iw", "dev"], check=False)
    if result.returncode != 0:
        return []

    interfaces = []
    current = {}

    for line in result.stdout.splitlines():
        line = line.strip()
        if line.startswith("Interface "):
            if current:
                interfaces.append(current)
            current = {"name": line.split()[1]}
        elif line.startswith(("phy#", "Unnamed/non-netdev interface")):
            # A new phy or a non-netdev (e.g. P2P-device) block: its type/channel
            # lines must not be applied to the previous named interface.
            if current:
                interfaces.append(current)
            current = {}
        elif line.startswith("type ") and current:
            current["type"] = line.split(None, 1)[1]
        elif line.startswith("channel ") and current:
            m = re.match(r"channel\s+(\d+)", line)
            if m:
                current["channel"] = int(m.group(1))

    if current:
        interfaces.append(current)

    return interfaces


def _networkmanager_active() -> bool:
    """True if nmcli exists and NetworkManager is running."""
    if shutil.which("nmcli") is None:
        return False
    try:
        result = run_cmd(["nmcli", "-t", "-f", "RUNNING", "general"], check=False, timeout=5)
    except InterfaceError:
        return False
    return result.returncode == 0 and result.stdout.strip() == "running"


def _nm_device_managed(interface: str) -> bool | None:
    """Whether NetworkManager currently manages ``interface`` (None = unknown/no NM)."""
    if not _networkmanager_active():
        return None
    try:
        result = run_cmd(["nmcli", "-g", "GENERAL.STATE", "device", "show", interface],
                         check=False, timeout=5)
    except InterfaceError:
        return None
    if result.returncode != 0 or not result.stdout.strip():
        return None
    return "unmanaged" not in result.stdout.lower()


def _set_nm_managed(interface: str, managed: bool) -> None:
    """Set NetworkManager's 'managed' flag for ``interface`` (best effort)."""
    if not _networkmanager_active():
        return
    value = "yes" if managed else "no"
    try:
        result = run_cmd(["nmcli", "device", "set", interface, "managed", value], check=False)
    except InterfaceError as e:
        log.warning("nmcli failed for %s: %s", interface, e)
        return
    if result.returncode == 0:
        log.info("NetworkManager: %s managed=%s", interface, value)
    else:
        log.warning("nmcli device set %s managed %s failed: %s",
                    interface, value, result.stderr.strip())


def _wpa_supplicant_pattern(interface: str) -> str:
    """pgrep -f pattern matching wpa_supplicant bound to exactly ``interface``.

    Matches ``-iwlan1`` / ``-i wlan1`` followed by a space or end of line, so
    ``wlan1`` does not match ``wlan10``.
    """
    escaped = interface.replace(".", "\\.")
    return rf"wpa_supplicant.*-i ?{escaped}( |$)"


# systemd units that run a supplicant bound to one interface.
_SUPPLICANT_UNITS = ("wpa_supplicant@{}.service", "wpa_supplicant-nl80211@{}.service")


def _read_cmdline(pid: int) -> list[str]:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            raw = f.read()
    except OSError:
        return []
    return [a.decode(errors="replace") for a in raw.split(b"\0") if a]


def _active_supplicant_units(interface: str) -> list[str]:
    if shutil.which("systemctl") is None:
        return []
    active = []
    for tmpl in _SUPPLICANT_UNITS:
        unit = tmpl.format(interface)
        try:
            r = run_cmd(["systemctl", "is-active", "--quiet", unit], check=False, timeout=5)
        except InterfaceError:
            continue
        if r.returncode == 0:
            active.append(unit)
    return active


def _kill_wpa_supplicant(interface: str) -> dict | None:
    """Kill wpa_supplicant processes for a specific interface.

    Returns how they were running (``{"units": [...], "cmdlines": [[...]]}``)
    so _restart_wpa_supplicant can bring them back, or None if none ran.
    """
    pattern = _wpa_supplicant_pattern(interface)
    result = run_cmd(["pgrep", "-f", pattern], check=False)
    if result.returncode == 0 and result.stdout.strip():
        units = _active_supplicant_units(interface)
        cmdlines = []
        for tok in result.stdout.split():
            if tok.isdigit():
                argv = _read_cmdline(int(tok))
                if argv:
                    cmdlines.append(argv)
        run_cmd(["pkill", "-f", pattern], check=False)
        time.sleep(1)
        log.info("Killed wpa_supplicant on %s", interface)
        return {"units": units, "cmdlines": cmdlines}
    return None


def _restart_wpa_supplicant(interface: str, record: dict) -> None:
    """Restart a supplicant killed by _kill_wpa_supplicant (best effort).

    A systemd unit is restarted through systemctl; otherwise the recorded
    command line is relaunched (detached if it was not daemonised with -B).
    """
    units = record.get("units") or []
    if units:
        for unit in units:
            r = run_cmd(["systemctl", "restart", unit], check=False, timeout=15)
            if r.returncode == 0:
                log.info("Restarted %s", unit)
            else:
                log.warning("systemctl restart %s failed: %s", unit, r.stderr.strip())
        return
    for argv in record.get("cmdlines") or []:
        if "-B" in argv:
            r = run_cmd(argv, check=False, timeout=15)
            ok = r.returncode == 0
        else:
            subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True,
                             close_fds=True)
            ok = True
        if ok:
            log.info("Restarted wpa_supplicant on %s: %s", interface, " ".join(argv))
        else:
            log.warning("Restarting wpa_supplicant on %s failed; restore "
                        "connectivity manually", interface)
