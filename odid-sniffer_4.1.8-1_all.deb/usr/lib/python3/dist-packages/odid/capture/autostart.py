"""Keep the radio sources the user wants running, across failures and reboots.

``odid serve`` runs as a service on an unattended Pi. The
:class:`SourceSupervisor` remembers which sources should be running (the
"desired" set) and restarts any of them that is inactive or has failed (for
example a BladeRF unplugged and plugged back in, or a dongle that is not yet
enumerated at boot), with exponential backoff.

The desired set starts from the saved state file (what was running when the
service last stopped) or, if there is none yet, from ``[serve] autostart`` in
the config. It then follows the user: a source started successfully from the
web UI is added, a source stopped from the UI is removed
(:class:`~odid.capture.manager.SourceManager` reports both via ``on_intent``),
and every change is saved to the state file.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Optional

from odid.capture.manager import SOURCE_CATALOG, SourceStatus

log = logging.getLogger(__name__)

STATE_VERSION = 1
_POLL_SECS = 1.0
_BACKOFF_FIRST = 5.0
_BACKOFF_MAX = 60.0
# A source that dies sooner than this after starting counts as a failed
# start, so a crash-looping source backs off instead of restarting every poll
_STABLE_SECS = 60.0


def parse_autostart(value) -> dict[str, dict]:
    """``[serve] autostart`` → {source_id: config}.

    Accepts a list of tables (``{source = "wifi-dongle", interface = "wlan1"}``)
    or plain source ids. Raises ValueError for anything else.
    """
    if value in (None, ""):
        return {}
    if not isinstance(value, list):
        raise ValueError("autostart must be a list, e.g. [{source = \"wifi-dongle\", interface = \"wlan1\"}]")
    out: dict[str, dict] = {}
    for item in value:
        if isinstance(item, str):
            sid, cfg = item, {}
        elif isinstance(item, dict) and isinstance(item.get("source"), str):
            cfg = {k: v for k, v in item.items() if k != "source"}
            sid = item["source"]
        else:
            raise ValueError(f"autostart entry must be a source id or a table with 'source': {item!r}")
        _check_source(sid)
        out[sid] = cfg
    return out


def _check_source(sid: str) -> None:
    if sid not in SOURCE_CATALOG:
        raise ValueError(f"unknown source {sid!r} (known: {', '.join(SOURCE_CATALOG)})")
    if SOURCE_CATALOG[sid].get("disabled"):
        raise ValueError(f"source {sid!r} is disabled")


def load_state(path: Path) -> Optional[dict[str, dict]]:
    """Desired sources from the state file, or None if there is no usable file."""
    try:
        data = json.loads(path.read_text())
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as exc:
        log.warning("Ignoring unreadable source state %s: %s", path, exc)
        return None
    sources = data.get("sources") if isinstance(data, dict) else None
    if not isinstance(sources, dict):
        log.warning("Ignoring malformed source state %s", path)
        return None
    out = {}
    for sid, cfg in sources.items():
        try:
            _check_source(sid)
        except ValueError as exc:
            log.warning("Source state %s: skipping %s", path, exc)
            continue
        if isinstance(cfg, dict):
            out[sid] = cfg
    return out


def save_state(path: Path, desired: dict[str, dict]) -> None:
    """Atomically write the desired sources."""
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps({"version": STATE_VERSION, "sources": desired}, indent=2) + "\n")
    os.replace(tmp, path)


class SourceSupervisor:
    """Start the desired sources and restart them when they fail.

    Wire :meth:`on_intent` into ``SourceManager(on_intent=...)`` (via
    :meth:`attach`), then call :meth:`start`; call :meth:`stop` before
    ``manager.close()``.
    """

    def __init__(self, desired: dict[str, dict], state_path: Optional[Path] = None) -> None:
        self._manager = None
        self._state_path = state_path
        self._lock = threading.Lock()
        self._desired = {sid: dict(cfg) for sid, cfg in desired.items()}
        self._dirty = False   # the initial set came from the file or the config
        self._failures: dict[str, int] = {}
        self._next_try: dict[str, float] = {}
        self._started_at: dict[str, float] = {}   # when we last started it successfully
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def attach(self, manager) -> None:
        self._manager = manager

    @property
    def desired(self) -> dict[str, dict]:
        with self._lock:
            return {sid: dict(cfg) for sid, cfg in self._desired.items()}

    # Called by SourceManager with its lock held: keep it short.
    def on_intent(self, source_id: str, config: Optional[dict]) -> None:
        with self._lock:
            if config is None:
                changed = self._desired.pop(source_id, None) is not None
            else:
                changed = self._desired.get(source_id) != config
                self._desired[source_id] = dict(config)
            # Our own successful start reports the same config: keep the
            # backoff. A new config or a stop from the user resets it.
            if changed:
                self._failures.pop(source_id, None)
                self._next_try.pop(source_id, None)
                self._started_at.pop(source_id, None)
                self._dirty = True
        self._wake.set()

    def start(self) -> None:
        if self._manager is None:
            raise RuntimeError("attach() a SourceManager first")
        self._thread = threading.Thread(target=self._run, daemon=True, name="odid-autostart")
        self._thread.start()

    def request_stop(self) -> None:
        """Make no further start attempts (returns at once)."""
        self._stop.set()
        self._wake.set()

    def stop(self, timeout: float = 15.0) -> None:
        """Stop and wait for the worker; call after ``manager.close()`` so an
        in-flight start is cancelled rather than waited for."""
        self.request_stop()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
        self._save_if_dirty()

    # -- worker -----------------------------------------------------------

    def _run(self) -> None:
        while not self._stop.is_set():
            self._save_if_dirty()
            for sid, cfg in self.desired.items():
                if self._stop.is_set():
                    break
                self._maybe_start(sid, cfg)
            self._wake.wait(_POLL_SECS)
            self._wake.clear()

    def _maybe_start(self, sid: str, cfg: dict) -> None:
        if self._manager.status_of(sid) not in (SourceStatus.INACTIVE, SourceStatus.ERROR):
            return
        now = time.monotonic()
        with self._lock:
            if sid not in self._desired:
                return
            started = self._started_at.pop(sid, None)
            if started is not None and now - started >= _STABLE_SECS:
                self._failures.pop(sid, None)     # ran long enough: start over
        if started is not None and now - started < _STABLE_SECS:
            # It started, then died soon after (e.g. the flowgraph exited)
            self._note_failure(sid, f"stopped {now - started:.0f} s after starting")
        with self._lock:
            if now < self._next_try.get(sid, 0.0):
                return
        try:
            self._manager.start_source(sid, cfg)
        except Exception as exc:
            if self._manager.status_of(sid) in (SourceStatus.STARTING, SourceStatus.ACTIVE,
                                                SourceStatus.STOPPING):
                return   # lost a race with a start/stop from the UI
            self._note_failure(sid, f"failed: {exc}")
        else:
            with self._lock:
                self._next_try.pop(sid, None)
                self._started_at[sid] = time.monotonic()
            log.info("Autostart: %s running", sid)

    def _note_failure(self, sid: str, reason: str) -> None:
        """Count a failure and schedule the next attempt with backoff."""
        with self._lock:
            if sid not in self._desired:      # stopped by the user meanwhile
                return
            n = self._failures.get(sid, 0) + 1
            self._failures[sid] = n
            delay = min(_BACKOFF_MAX, _BACKOFF_FIRST * 2 ** (n - 1))
            self._next_try[sid] = time.monotonic() + delay
        log.warning("Autostart of %s %s (attempt %d, retrying in %.0f s)", sid, reason, n, delay)
        try:
            self._manager.set_retry_note(sid, f"Retrying automatically every {delay:.0f} s")
        except Exception:
            log.debug("set_retry_note failed", exc_info=True)

    def _save_if_dirty(self) -> None:
        if self._state_path is None:
            return
        with self._lock:
            if not self._dirty:
                return
            snapshot = {sid: dict(cfg) for sid, cfg in self._desired.items()}
            self._dirty = False
        try:
            save_state(self._state_path, snapshot)
        except (OSError, TypeError, ValueError) as exc:
            log.warning("Could not save source state to %s: %s", self._state_path, exc)
