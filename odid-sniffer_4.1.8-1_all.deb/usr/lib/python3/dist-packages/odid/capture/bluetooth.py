"""Bluetooth Remote ID capture: ASTM F3411 BT4 Legacy / BT5 adverts via BlueZ.

ASTM F3411 mandates both WiFi *and* Bluetooth advertising.  Many drones
broadcast only over Bluetooth, so this fills the gap left by WiFi-only capture.

Transport details
-----------------
* AD type 0x16 (Service Data – 16-bit UUID), UUID = 0xFFFA
* Payload layout (bytes after UUID):
    [0]   App code  = 0x0D
    [1]   Counter   = [counter:4][proto_version:4]
    [2..] N × 25-byte ODID messages  (same encoding as WiFi)

Usage::

    capture = BTCapture(callback=on_frame)
    capture.sniff()          # blocks; call capture.stop() from another thread
"""

import asyncio
import logging
import threading
from datetime import datetime, timezone
from typing import Callable, Optional

from odid.decode.frame import ODIDFrame, _decode_message_sequence

log = logging.getLogger(__name__)

ODID_BT_SERVICE_UUID = "0000fffa-0000-1000-8000-00805f9b34fb"
ODID_BT_APP_CODE = 0x0D
FRAME_TYPE_BT = "BT"

try:
    from bleak import BleakScanner
    from bleak.backends.device import BLEDevice
    from bleak.backends.scanner import AdvertisementData

    _BLEAK_AVAILABLE = True
except ImportError:
    _BLEAK_AVAILABLE = False


def _find_odid_payload(service_data: dict) -> Optional[bytes]:
    """Return ODID payload bytes from a service_data dict, or None."""
    for uuid, data in service_data.items():
        if uuid.lower() in (ODID_BT_SERVICE_UUID, "fffa"):
            return data
    return None


def parse_odid_service_data(
    mac: str,
    rssi: Optional[int],
    payload: bytes,
) -> Optional[ODIDFrame]:
    """Parse raw ODID BT service data bytes into an ODIDFrame.

    Args:
        mac:      Source BT MAC address string.
        rssi:     Received signal strength in dBm, or None.
        payload:  Full service data bytes starting at app code (0x0D).

    Frames are labelled ``"BT"``: bleak does not expose the PHY or the
    advertising PDU type, so legacy and BT5 extended adverts can't be told
    apart here.  ``timestamp`` is set to the current UTC time.

    Returns:
        ODIDFrame on success, None if payload is invalid or not ODID.
    """
    if len(payload) < 2:
        log.debug("BT ODID payload too short (%d bytes) from %s", len(payload), mac)
        return None

    if payload[0] != ODID_BT_APP_CODE:
        log.debug(
            "BT service data from %s: unexpected app_code=0x%02x (expected 0x0D)",
            mac, payload[0],
        )
        return None

    # ASTM F3411 BT service data: app code, 8-bit message counter, message.
    # The whole byte is the counter; the protocol version is the low nibble
    # of the (first) message header.
    counter_value = payload[1]
    odid_payload = payload[2:]
    proto_version = odid_payload[0] & 0x0F if odid_payload else 0

    messages = _decode_message_sequence(odid_payload, proto_version)
    if not messages:
        log.debug("BT ODID frame from %s decoded 0 messages", mac)
        return None

    frame_type = FRAME_TYPE_BT

    frame = ODIDFrame(
        source_mac=mac,
        signal_dbm=rssi,
        channel=None,
        frame_type=frame_type,
        message_counter=counter_value,
        proto_version=proto_version,
        messages=messages,
        raw_payload=bytes(payload),
    )
    frame.timestamp = datetime.now(timezone.utc)

    log.debug(
        "BT ODID frame: mac=%s rssi=%s type=%s msgs=%d",
        mac, rssi, frame_type, len(messages),
    )
    return frame


class BTCapture:
    """Scan for Bluetooth Remote ID advertisements and call *callback* with
    each decoded :class:`~odid.decode.frame.ODIDFrame`.

    Mirrors the :class:`~odid.capture.wifi.WiFiCapture` interface so the same
    CLI pipeline code works for both transports.
    """

    def __init__(
        self,
        callback: Callable[[ODIDFrame], None],
        adapter: Optional[str] = None,
    ):
        if not _BLEAK_AVAILABLE:
            raise ImportError(
                "bleak is required for Bluetooth capture. "
                "Install it with: pip install bleak"
            )
        self.callback = callback
        self._adapter = adapter
        self._stop_event = threading.Event()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._async_stop: Optional[asyncio.Event] = None
        self.packet_counts: dict = {}  # no channel concept for BT

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sniff(self) -> None:
        """Block and scan for BT Remote ID advertisements.

        Returns when :meth:`stop` is called (e.g. from a signal handler).
        """
        asyncio.run(self._run())

    def stop(self) -> None:
        """Signal the scan to stop."""
        self._stop_event.set()
        if self._loop and not self._loop.is_closed() and self._async_stop is not None:
            # Set the asyncio event from this thread so _run() wakes immediately.
            # The loop can close between the check above and this call (the
            # capture thread's asyncio.run() finishing); that is harmless.
            try:
                self._loop.call_soon_threadsafe(self._async_stop.set)
            except RuntimeError:
                pass

    @property
    def stopped(self) -> bool:
        return self._stop_event.is_set()

    # ------------------------------------------------------------------
    # Internal async machinery
    # ------------------------------------------------------------------

    def _detection_callback(
        self, device: "BLEDevice", advertisement_data: "AdvertisementData"
    ) -> None:
        """Called by BleakScanner on every advertisement received."""
        payload = _find_odid_payload(advertisement_data.service_data)
        if payload is None:
            return

        rssi = getattr(advertisement_data, "rssi", None)
        frame = parse_odid_service_data(device.address, rssi, payload)
        if frame is None:
            return

        try:
            self.callback(frame)
        except Exception:
            log.exception("Error in BT frame callback")

    async def _run(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._async_stop = asyncio.Event()

        # Handle race: stop() may have been called before _async_stop was created
        if self._stop_event.is_set():
            return

        scanner_kwargs: dict = {"detection_callback": self._detection_callback}
        if self._adapter:
            # bleak >= 0.22: the top-level 'adapter' kwarg is deprecated
            scanner_kwargs["bluez"] = {"adapter": self._adapter}

        scanner = BleakScanner(**scanner_kwargs)
        log.info("Starting Bluetooth scan for Remote ID (service UUID 0xFFFA)")

        await scanner.start()
        try:
            await self._async_stop.wait()   # woken by stop() via call_soon_threadsafe
        finally:
            await scanner.stop()
            log.info("Bluetooth scan stopped")
