"""WiFi packet capture using scapy in monitor mode."""

import logging
import threading
import time
from typing import Callable, Optional

from scapy.sendrecv import AsyncSniffer

from odid.decode.frame import extract_odid, ODIDFrame
from odid.capture.interface import set_channel

log = logging.getLogger(__name__)


class WiFiCapture:
    """Captures ODID frames from a WiFi interface in monitor mode.

    Modes:
      - sniff: listen on a single channel continuously
      - scan:  hop through channels with configurable dwell time

    Both modes run scapy's :class:`AsyncSniffer` so that :meth:`stop` takes
    effect promptly even when no packets arrive.
    """

    # Standard 2.4GHz channels
    CHANNELS_24GHZ = list(range(1, 12))  # 1-11
    ODID_PRIMARY_CHANNEL = 6
    _POLL_SECS = 0.2
    # How long _stop_sniffer keeps retrying stop() (socket opening can be
    # slow on a loaded Pi) before handing off to a background reaper.
    _STOP_WAIT_SECS = 5.0
    _STOP_RETRY_SECS = 0.02
    _DELIVER_WAIT_SECS = 3.0

    def __init__(
        self,
        interface: str,
        callback: Callable[[ODIDFrame], None],
        all_packets_callback: Optional[Callable] = None,
        channel: int = ODID_PRIMARY_CHANNEL,
    ):
        self.interface = interface
        self.default_channel = channel
        self.callback = callback
        self.all_packets_callback = all_packets_callback
        self._stop_event = threading.Event()
        # Held while a packet is being delivered; stop() takes it so no frame
        # is delivered after stop() returns.  Re-entrant so a callback may
        # call stop() itself.
        self._deliver_lock = threading.RLock()
        self._current_channel: int | None = None
        self.packet_counts: dict[int, int] = {ch: 0 for ch in self.CHANNELS_24GHZ}
        self._total_packets = 0

    def stop(self):
        """Signal the capture to stop (takes effect within ~0.2 s).

        No frame is delivered to the callbacks after this returns (unless a
        callback in progress blocks for more than a few seconds).
        """
        got = self._deliver_lock.acquire(timeout=self._DELIVER_WAIT_SECS)
        try:
            self._stop_event.set()
        finally:
            if got:
                self._deliver_lock.release()

    @property
    def stopped(self) -> bool:
        return self._stop_event.is_set()

    def sniff(self, channel: Optional[int] = None):
        """Listen on a single channel until :meth:`stop` is called.

        Raises:
            RuntimeError: if the underlying sniffer ends while not stopped
                (e.g. the interface disappeared), so callers can report it.
        """
        if channel is None:
            channel = self.default_channel
        self._current_channel = channel
        set_channel(self.interface, channel)
        log.info("Sniffing on %s channel %d", self.interface, channel)
        self._sniff_for(None)

    def scan(self, channels: list[int] | None = None, dwell_time: float = 5.0):
        """Hop through channels looking for ODID frames.

        Args:
            channels: List of channels to scan. Defaults to all 2.4GHz.
            dwell_time: Seconds to spend on each channel.
        """
        if channels is None:
            channels = self.CHANNELS_24GHZ

        log.info(
            "Scanning %s across channels %s, dwell=%.1fs",
            self.interface, channels, dwell_time,
        )

        if not channels:
            raise ValueError("scan() needs at least one channel")
        # Wait this long after a failed channel so a broken interface can't
        # make the loop spin.
        fail_wait = dwell_time if dwell_time and dwell_time > 0 else 1.0

        while not self.stopped:
            failures = 0
            last_error: Exception | None = None
            for channel in channels:
                if self.stopped:
                    break

                self._current_channel = channel
                try:
                    set_channel(self.interface, channel)
                except Exception as e:
                    failures += 1
                    last_error = e
                    log.warning("Failed to set channel %d, skipping", channel)
                    if self._stop_event.wait(fail_wait):
                        break
                    continue

                if self._stop_event.wait(0.3):  # let channel settle
                    break
                self._sniff_for(dwell_time)
            else:
                if failures == len(channels):
                    raise RuntimeError(
                        f"Could not set any channel on {self.interface} "
                        f"(last error: {last_error})"
                    ) from last_error

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _sniff_for(self, duration: Optional[float]) -> None:
        """Run an AsyncSniffer until stopped or ``duration`` elapses.

        Raises RuntimeError if the sniffer thread dies on its own.
        """
        # Per-sniffer gate: once this sniffer is being stopped its packets are
        # dropped, even if its thread lingers (see _stop_sniffer).
        closed = threading.Event()

        def prn(pkt):
            self._handle_packet(pkt, closed)

        sniffer = AsyncSniffer(iface=self.interface, prn=prn, store=False)
        sniffer.start()
        deadline = None if duration is None else time.monotonic() + duration
        died = False
        try:
            while not self.stopped:
                if deadline is not None and time.monotonic() >= deadline:
                    break
                sniffer.thread.join(self._POLL_SECS)
                if not sniffer.thread.is_alive():
                    died = True
                    break
        finally:
            got = self._deliver_lock.acquire(timeout=self._DELIVER_WAIT_SECS)
            try:
                closed.set()
            finally:
                if got:
                    self._deliver_lock.release()
            self._stop_sniffer(sniffer)

        if sniffer.exception is not None:
            raise RuntimeError(
                f"WiFi sniffer on {self.interface} failed: {sniffer.exception}"
            ) from sniffer.exception
        if died and not self.stopped:
            raise RuntimeError(f"WiFi sniffer on {self.interface} stopped unexpectedly")

    @classmethod
    def _stop_sniffer(cls, sniffer) -> None:
        """Stop an AsyncSniffer, tolerating scapy's start-up race.

        In scapy 2.6.x ``_run`` sets ``running = True`` before it opens the
        socket and defines ``stop_cb``; a stop() in that window raises
        Scapy_Exception.  ``continue_sniff = True`` is also set *after*
        stop_cb exists, so a single early stop can be overwritten.  Hence
        stop() is retried until the thread exits, also clearing
        ``continue_sniff`` directly.  If the thread still has not exited after
        _STOP_WAIT_SECS, a daemon reaper keeps trying in the background; the
        caller's gate already drops any packets it still sees.
        """
        t = sniffer.thread
        if t is None:
            return
        end = time.monotonic() + cls._STOP_WAIT_SECS
        while t.is_alive() and time.monotonic() < end:
            cls._try_stop(sniffer)
            t.join(cls._STOP_RETRY_SECS)
        if t.is_alive():
            iface = sniffer.kwargs.get("iface")
            log.warning("WiFi sniffer thread on %s did not exit; retrying in background",
                        iface)

            def reap():
                while t.is_alive():
                    cls._try_stop(sniffer)
                    t.join(0.5)
                log.info("Lingering WiFi sniffer thread on %s exited", iface)

            threading.Thread(target=reap, name="AsyncSnifferReaper", daemon=True).start()

    @staticmethod
    def _try_stop(sniffer) -> None:
        """One stop attempt; never raises."""
        try:
            sniffer.stop(join=False)
        except Exception:
            # Not running yet / stop_cb not defined yet: retried by caller.
            log.debug("AsyncSniffer.stop failed (will retry)", exc_info=True)
        if getattr(sniffer, "running", False) and hasattr(sniffer, "stop_cb"):
            # Covers the window where _run sets continue_sniff = True after an
            # earlier stop_cb already cleared it.
            sniffer.continue_sniff = False

    def _handle_packet(self, pkt, closed: Optional[threading.Event] = None):
        """Process a captured packet.  Never raises (scapy would drop the socket).

        Packets arriving after stop() (or after this sniffer was closed) are
        dropped.
        """
        with self._deliver_lock:
            if self.stopped or (closed is not None and closed.is_set()):
                return
            try:
                self._process_packet(pkt)
            except Exception:
                log.exception("Error handling WiFi packet")

    def _process_packet(self, pkt):
        channel = self._current_channel or 0
        self._total_packets += 1

        # Count all packets for channel activity stats
        if channel in self.packet_counts:
            self.packet_counts[channel] += 1

        debug = log.isEnabledFor(logging.DEBUG)
        if debug:
            log.debug(
                "Packet #%d on ch%d: len=%d layers=%s",
                self._total_packets, channel, len(pkt), pkt.summary(),
            )

        if self.all_packets_callback:
            self.all_packets_callback(pkt, channel)

        # Try ODID extraction
        frame = extract_odid(pkt)
        if frame:
            # Fill in channel if not from RadioTap
            if frame.channel is None:
                frame.channel = channel
            if debug:
                log.debug(
                    "ODID frame extracted: mac=%s type=%s msgs=%d",
                    frame.source_mac, frame.frame_type, len(frame.messages),
                )
            self.callback(frame)
