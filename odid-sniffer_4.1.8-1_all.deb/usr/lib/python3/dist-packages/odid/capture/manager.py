"""Live radio-source manager: start/stop capture sources without restarting.

Used by `odid serve` to let the web UI control which radio sources are active.
All capture classes share the same interface, so this manager is capture-agnostic.

Thread model
------------
Each capture source runs in its own daemon thread.  The manager itself is
thread-safe via an RLock; all state mutations and status snapshots are
protected by that lock.  The ``on_sources_changed`` callback is invoked
*inside* the lock to guarantee ordering, but it must be non-blocking (the
web layer schedules the actual broadcast on the asyncio event loop via
``asyncio.run_coroutine_threadsafe``).

Blocking work (stopping capture threads, terminating flowgraph processes) is
never done while holding the lock: resources are *detached* from the entry
under the lock and torn down outside it, so ``get_status()`` never stalls.

Lifecycle
---------
::

    INACTIVE/ERROR --start--> STARTING --ok--> ACTIVE --stop--> STOPPING --> INACTIVE
                                  |                 |
                                  +--fail--> ERROR  +--capture/flowgraph dies--> ERROR

* ``start_source`` is only allowed from INACTIVE or ERROR (an ERROR source is
  torn down first, and a teardown still running after a failure is waited
  for).  Anything else raises :class:`SourceStateError`.
* ``stop_source`` during STARTING cancels the start (via a per-entry
  generation counter) and waits for it to unwind.
* Each entry has a ``generation`` counter; background threads (capture
  runner, flowgraph watchdog, an in-flight start) only commit state changes
  if the generation they were started with is still current.

BladeRF sources additionally spawn a GNU Radio flowgraph subprocess before
starting the ZMQ-based capture thread.  Flowgraphs are spawned from a single
long-lived thread with ``PR_SET_PDEATHSIG`` so they die with the server.
"""

import collections
import concurrent.futures
import ctypes
import ctypes.util
import enum
import json
import logging
import os
import re
import signal
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)


class SourceStateError(ValueError):
    """The requested operation conflicts with the current source state.

    Examples: starting a source that is already active/starting, starting a
    BladeRF source while another one owns the device, stopping a source that
    is already stopping, or a start that was cancelled by a stop request.
    The web layer maps this to HTTP 409.
    """


class _StartCancelled(Exception):
    """Internal: an in-flight start was superseded by stop_source()."""


# ---------------------------------------------------------------------------
# Source catalog
# ---------------------------------------------------------------------------

DUAL_DISABLED_REASON = (
    "Dual WiFi+BT capture on one BladeRF is disabled: the bladeRF 2.0 (AD9361) "
    "has a single RX LO shared by both RX channels, so WiFi and BT cannot be "
    "tuned independently. Use 'BladeRF WiFi only' or 'BladeRF BT only' "
    "(one protocol per BladeRF)."
)

SOURCE_CATALOG: dict[str, dict] = {
    "bladerf-dual": {
        "label": "BladeRF WiFi + BT (Dual RX)",
        "flowgraph": "odid_dual_bladerf.py",
        "has_flowgraph": True,
        "is_dual": True,
        "zmq_default": "tcp://127.0.0.1:5555",
        "zmq_bt_default": "tcp://127.0.0.1:5556",
        "disabled": DUAL_DISABLED_REASON,
    },
    "bladerf-wifi": {
        "label": "BladeRF WiFi only (ZMQ)",
        "flowgraph": "odid_wifi_bladerf.py",
        "has_flowgraph": True,
        "sdr_control": True,       # monitor, IQ recording, live gain (sdr_monitor.py)
        # The spectrum monitor cost ~6% of the (already CPU-bound) receiver's
        # throughput on an idle Pi 5 (2026-10-14: 11.3 -> 10.7 MS/s), so it
        # is opt-in here.
        "monitor_default": False,
        "zmq_default": "tcp://127.0.0.1:5555",
    },
    "bladerf-bt": {
        "label": "BladeRF BT only (ZMQ)",
        "flowgraph": "odid_bt_bladerf.py",
        "has_flowgraph": True,
        "sdr_control": True,
        "monitor_default": True,   # ~+13% of a core, no throughput loss at 2 MS/s
        "zmq_default": "tcp://127.0.0.1:5556",
    },
    "wifi-dongle": {
        "label": "WiFi Dongle (Scapy)",
        "has_flowgraph": False,
    },
    "builtin-bt": {
        "label": "Built-in BT (Bleak)",
        "has_flowgraph": False,
    },
}

# Sources that share the BladeRF device; at most one may be active at a time
_BLADERF_SOURCES = {"bladerf-dual", "bladerf-wifi", "bladerf-bt"}

# Linux interface names: IFNAMSIZ-1 = 15 chars, no '/', no whitespace.
_IFACE_RE = re.compile(r"^[A-Za-z0-9_.-]{1,15}$")
# Flowgraph ZMQ endpoints must stay on the loopback interface.
_ZMQ_ADDR_RE = re.compile(r"^tcp://(127\.0\.0\.1|localhost):(\d{1,5})$")
# sysfs root, overridable in tests.
_SYSFS_NET = Path("/sys/class/net")

_START_POLL_SECS = 3.0       # how long a new flowgraph must survive
_READER_JOIN_SECS = 1.0      # wait for log readers to hit EOF before closing pipes
_STDERR_TAIL_WAIT_SECS = 1.0  # max wait for stderr reader EOF when a flowgraph dies at startup
_STDERR_TAIL_LINES = 20       # stderr lines kept per flowgraph for error messages
_WATCHDOG_INTERVAL = 1.0     # flowgraph liveness poll period
_THREAD_JOIN_SECS = 10.0
_TERM_WAIT_SECS = 5.0
_KILL_WAIT_SECS = 2.0
_RESTORE_WAIT_SECS = 15.0    # ip/iw/nmcli calls restoring managed mode


class SourceStatus(str, enum.Enum):
    INACTIVE = "inactive"
    STARTING = "starting"
    ACTIVE   = "active"
    ERROR    = "error"
    STOPPING = "stopping"


@dataclass
class SourceEntry:
    source_id: str
    status: SourceStatus = SourceStatus.INACTIVE
    thread: Optional[threading.Thread] = None
    capture: object = None
    flowgraph_proc: Optional[subprocess.Popen] = None
    # Interface this source switched to monitor mode (restored on stop)
    restore_iface: Optional[str] = None
    error_msg: str = ""
    # Set by an autostart supervisor while it is retrying a failed source
    retry_note: str = ""
    frame_count: int = 0       # int += 1 is GIL-safe; no extra lock needed
    config: dict = field(default_factory=dict)
    # Bumped on every start/stop; stale background threads compare against it.
    generation: int = 0
    # Cleared while a start is in flight; set when start_source() returns.
    start_done: threading.Event = field(default_factory=threading.Event)
    # Cleared while a failed source's resources are torn down in the
    # background (_fail_if_current); start/stop wait for it before going on.
    teardown_done: threading.Event = field(default_factory=threading.Event)
    # SDR flowgraphs (sdr_control): gain, recording state, last level reading
    # and last record/control result, as reported by the flowgraph.
    sdr: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.start_done.set()
        self.teardown_done.set()


# ---------------------------------------------------------------------------
# Config validation helpers
# ---------------------------------------------------------------------------

def validate_wifi_interface(name) -> str:
    """Validate a WiFi interface name; return the stripped name.

    Raises ValueError (without echoing the raw input) when the name is
    malformed or does not refer to an existing wireless interface.
    """
    if not isinstance(name, str) or not name.strip():
        raise ValueError("WiFi interface name is required (e.g. 'wlan1')")
    name = name.strip()
    if not _IFACE_RE.match(name) or name in (".", ".."):
        raise ValueError(
            "Invalid WiFi interface name (allowed: letters, digits, '_', '.', '-'; max 15 chars)"
        )
    base = _SYSFS_NET / name
    if not ((base / "phy80211").exists() or (base / "wireless").exists()):
        raise ValueError("WiFi interface not found or not wireless; check 'iw dev'")
    return name


def _validate_zmq_addr(addr) -> str:
    if not isinstance(addr, str):
        raise ValueError("ZMQ address must be a string like tcp://127.0.0.1:5555")
    m = _ZMQ_ADDR_RE.match(addr.strip())
    if not m or not (1 <= int(m.group(2)) <= 65535):
        raise ValueError("ZMQ address must be tcp://127.0.0.1:<port> or tcp://localhost:<port>")
    return addr.strip()


def _validate_gain(value, name: str = "gain") -> int:
    try:
        if isinstance(value, bool):
            raise TypeError
        gain = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be an integer between 0 and 71") from None
    if not 0 <= gain <= 71:
        raise ValueError(f"{name} must be an integer between 0 and 71")
    return gain


def _validate_hop(value) -> bool:
    if not isinstance(value, bool):
        raise ValueError("hop must be true or false")
    return value


def _validate_bt_channel(value) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValueError("BT channel must be 37, 38 or 39")
    try:
        ch = int(value)
    except ValueError:
        raise ValueError("BT channel must be 37, 38 or 39") from None
    if ch not in (37, 38, 39):
        raise ValueError("BT channel must be 37, 38 or 39")
    return ch


def _validate_record_secs(value) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("recording length must be a number of seconds")
    if not 0 < value <= MAX_RECORD_SECS:
        raise ValueError(f"recording length must be between 0 and {MAX_RECORD_SECS:.0f} s")
    return float(value)


def _validate_wifi_channel(value, lo: int = 1, hi: int = 14) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValueError(f"WiFi channel must be an integer between {lo} and {hi}")
    try:
        ch = int(value)
    except ValueError:
        raise ValueError(f"WiFi channel must be an integer between {lo} and {hi}") from None
    if not lo <= ch <= hi:
        raise ValueError(f"WiFi channel must be an integer between {lo} and {hi}")
    return ch


# 2.4 GHz channel -> centre frequency (MHz); mirrors flowgraphs/odid_wifi_bladerf.py
_WIFI_CHANNEL_MHZ = {ch: 2407 + 5 * ch for ch in range(1, 14)}
_WIFI_CHANNEL_MHZ[14] = 2484
_BLADERF_WIFI_DEFAULT_CHANNEL = 6
MAX_RECORD_SECS = 60.0          # mirrors flowgraphs/sdr_monitor.py
# Level reading kept in the sdr status: the latest mean / noise floor, and
# the worst clipping and peak over the last LEVEL_WINDOW_S (one 0.25 s
# reading is too jumpy for an alarm: a single strong burst would flap it).
LEVEL_WINDOW_S = 10.0


def _bind_addr(connect_addr: str) -> str:
    """tcp://localhost:5555 → tcp://127.0.0.1:5555 (flowgraph PUSH bind)."""
    port = connect_addr.rsplit(":", 1)[-1]
    return f"tcp://127.0.0.1:{port}"


# ---------------------------------------------------------------------------
# Parent-death signal for flowgraph subprocesses
# ---------------------------------------------------------------------------

_PR_SET_PDEATHSIG = 1
try:
    _LIBC = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6", use_errno=True)
except OSError:  # pragma: no cover - non-glibc platforms
    _LIBC = None


def _make_pdeathsig_preexec(parent_pid: int) -> Optional[Callable[[], None]]:
    """Return a preexec_fn that makes the child get SIGTERM when we die.

    Note: PDEATHSIG fires when the *thread* that forked the child exits, so
    the manager always spawns flowgraphs from one long-lived thread.
    """
    if _LIBC is None or not sys.platform.startswith("linux"):
        return None
    prctl = _LIBC.prctl

    def _preexec() -> None:
        prctl(_PR_SET_PDEATHSIG, int(signal.SIGTERM), 0, 0, 0)
        # Parent may already have died between fork() and prctl().
        if os.getppid() != parent_pid:
            os._exit(1)

    return _preexec


# ---------------------------------------------------------------------------
# Flowgraph directory discovery
# ---------------------------------------------------------------------------

def _find_flowgraph_dir() -> Optional[Path]:
    """Return the path to the ``flowgraphs/`` directory, or None.

    Resolution order:
    1. ``ODID_FLOWGRAPH_DIR`` environment variable
    2. The ``odid/flowgraphs`` package directory (installed copy)
    3. ``Path.cwd() / "flowgraphs"``
    """
    env = os.environ.get("ODID_FLOWGRAPH_DIR")
    if env:
        p = Path(env)
        if p.is_dir():
            return p
        log.warning("ODID_FLOWGRAPH_DIR=%r does not exist", env)

    # odid/capture/manager.py → odid/capture/ → odid/flowgraphs
    candidate = Path(__file__).resolve().parent.parent / "flowgraphs"
    if candidate.is_dir():
        return candidate

    cwd_candidate = Path.cwd() / "flowgraphs"
    if cwd_candidate.is_dir():
        return cwd_candidate

    return None


# ---------------------------------------------------------------------------
# SourceManager
# ---------------------------------------------------------------------------

_Stale = tuple  # (capture, thread, proc, restore_iface)


# GNU Radio / gr-osmosdr / libbladeRF write everything (banners, debug, real
# errors) to stderr, so classify lines instead of logging them all as warnings.
_OVERFLOW_RE = re.compile(r"^[OU]+$")   # UHD-style overflow/underflow markers
_STDERR_PROBLEM_RE = re.compile(
    r"error|fail|traceback|exception|overflow|unable|cannot|could not|not found|timeout|timed out",
    re.IGNORECASE,
)


def _flowgraph_exit_message(rc: int) -> str:
    """Human-readable reason for an unexpected flowgraph exit."""
    if rc < 0:
        try:
            how = f"killed by {signal.Signals(-rc).name}"
        except ValueError:
            how = f"killed by signal {-rc}"
    else:
        how = f"exit code {rc}"
    # libbladeRF aborts (SIGABRT) or errors out when the device disappears
    return (f"Flowgraph exited unexpectedly ({how}). Check the BladeRF is still connected "
            "(bladeRF-cli -p) and see the server log")


def _stderr_level(msg: str) -> int:
    if _OVERFLOW_RE.match(msg) or msg.startswith("SDR sample overflow") or _STDERR_PROBLEM_RE.search(msg):
        return logging.WARNING
    if "DEBUG:" in msg:
        return logging.DEBUG
    return logging.INFO


class SourceManager:
    """Orchestrate multiple concurrent capture sources.

    Parameters
    ----------
    on_frame:
        Shared callback forwarded to every capture instance.  Called from
        whichever capture thread receives a frame.
    flowgraph_dir:
        Path to the ``flowgraphs/`` directory.  If None, auto-discovered via
        :func:`_find_flowgraph_dir`.
    on_sources_changed:
        Optional callable invoked (from within the RLock) whenever source
        state changes.  Must be non-blocking; use it to schedule async I/O.
    on_intent:
        Optional ``on_intent(source_id, config_or_None)`` invoked (from within
        the RLock, must be non-blocking) when a source becomes ACTIVE through
        start_source() (``config``) or is stopped by stop_source() (``None``).
        It records what the user wants running; shutdown via close() does not
        count as a stop.  A gain change made live (set_gain) is reported the
        same way, so a restart keeps it.
    iq_dir:
        Directory for IQ recordings (``--iq-dir``); None disables recording.
    on_monitor:
        Optional ``on_monitor(source_id, msg)`` for the SDR flowgraphs'
        spectrum/level messages (~4 per second, from a capture thread; must
        be non-blocking).
    """

    def __init__(
        self,
        on_frame: Callable,
        flowgraph_dir: Optional[Path] = None,
        on_sources_changed: Optional[Callable] = None,
        on_intent: Optional[Callable] = None,
        iq_dir: Optional[str] = None,
        on_monitor: Optional[Callable] = None,
    ) -> None:
        self._on_frame = on_frame
        self._flowgraph_dir = flowgraph_dir or _find_flowgraph_dir()
        self._on_sources_changed = on_sources_changed
        self._on_intent = on_intent
        self._iq_dir = iq_dir
        self._on_monitor = on_monitor
        self._stdin_lock = threading.Lock()   # serialises control-command writes
        # source id -> deque[(t, clip_pct, peak_dbfs)] over LEVEL_WINDOW_S
        self._levels: dict = {}
        self._lock = threading.RLock()
        # Set by close(); start_source() refuses once shutdown has begun.
        self._closing = False
        # Log-reader threads per flowgraph process (joined before pipes close).
        self._readers: dict = {}
        self._stderr_tails: dict = {}   # proc -> deque of last stderr lines
        self._overflows: dict = {}      # proc -> [SDR overflow count] (health page)
        self._sources: dict[str, SourceEntry] = {
            sid: SourceEntry(source_id=sid) for sid in SOURCE_CATALOG
        }
        # Flowgraph processes detached from an entry but not yet reaped.
        # They may still hold the BladeRF / ZMQ port.
        self._reaping: set = set()
        # One long-lived thread spawns all flowgraphs (see PDEATHSIG note).
        self._spawner = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="odid-fg-spawn"
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_status(self) -> list[dict]:
        """Return a JSON-serialisable snapshot of all source states."""
        with self._lock:
            return [
                {
                    "id": sid,
                    "label": SOURCE_CATALOG[sid]["label"],
                    "status": entry.status.value,
                    "error": entry.error_msg,
                    "retry": entry.retry_note,
                    "frame_count": entry.frame_count,
                    "config": dict(entry.config),
                    "has_flowgraph": SOURCE_CATALOG[sid]["has_flowgraph"],
                    "is_dual": SOURCE_CATALOG[sid].get("is_dual", False),
                    "zmq_default": SOURCE_CATALOG[sid].get("zmq_default", ""),
                    "zmq_bt_default": SOURCE_CATALOG[sid].get("zmq_bt_default", ""),
                    "available": not SOURCE_CATALOG[sid].get("disabled"),
                    "unavailable_reason": SOURCE_CATALOG[sid].get("disabled") or "",
                    "overflows": self._overflows.get(entry.flowgraph_proc, [0])[0],
                    "sdr_control": bool(SOURCE_CATALOG[sid].get("sdr_control")),
                    "monitor_default": bool(SOURCE_CATALOG[sid].get("monitor_default")),
                    "sdr": dict(entry.sdr) if entry.sdr else None,
                }
                for sid, entry in self._sources.items()
            ]

    def start_source(self, source_id: str, config: dict) -> None:
        """Start a capture source (blocks for up to ~3 s for flowgraphs).

        Raises
        ------
        KeyError
            If ``source_id`` is not in :data:`SOURCE_CATALOG`.
        SourceStateError
            If the source is not INACTIVE/ERROR, the BladeRF is busy, the
            source is disabled, or the start was cancelled by stop_source().
        ValueError
            If ``config`` is invalid.
        RuntimeError
            If the flowgraph cannot be found or exits immediately.
        """
        if source_id not in SOURCE_CATALOG:
            raise KeyError(f"Unknown source: {source_id!r}")
        catalog = SOURCE_CATALOG[source_id]
        if self._closing:
            raise SourceStateError("Source manager is shutting down")
        if catalog.get("disabled"):
            raise SourceStateError(catalog["disabled"])
        if config is None:
            config = {}
        if not isinstance(config, dict):
            raise ValueError("config must be an object")

        with self._lock:
            if self._closing:
                raise SourceStateError("Source manager is shutting down")
            entry = self._sources[source_id]
            if entry.status not in (SourceStatus.INACTIVE, SourceStatus.ERROR):
                raise SourceStateError(
                    f"Source {source_id!r} is {entry.status.value}; stop it first"
                )
            if source_id in _BLADERF_SOURCES:
                self._check_bladerf_free(source_id)
            entry.generation += 1
            gen = entry.generation
            stale = self._detach(entry)
            failed_teardown = entry.teardown_done
            entry.status = SourceStatus.STARTING
            entry.error_msg = ""
            entry.config = dict(config)
            entry.frame_count = 0
            entry.start_done.clear()
            self._notify_changed()

        try:
            self._wait_failed_teardown(source_id, failed_teardown)
            self._teardown(source_id, stale)
            self._do_start(source_id, config, gen)
        except BaseException as exc:
            with self._lock:
                if entry.generation == gen:
                    entry.status = SourceStatus.ERROR
                    entry.error_msg = str(exc) or type(exc).__name__
                    self._notify_changed()
                    cancelled = False
                else:
                    cancelled = True
            if cancelled and isinstance(exc, Exception):
                raise SourceStateError(
                    f"Start of {source_id!r} was cancelled by a stop request"
                ) from exc
            raise
        finally:
            entry.start_done.set()

    def stop_source(self, source_id: str) -> None:
        """Stop a source gracefully.

        No-op if the source is already inactive.  Stopping a STARTING source
        cancels the start and waits for it to unwind.  Stopping an ERROR
        source releases any leftover resources and resets it to INACTIVE.

        Raises
        ------
        KeyError
            Unknown ``source_id``.
        SourceStateError
            The source is already stopping.
        """
        if source_id not in SOURCE_CATALOG:
            raise KeyError(f"Unknown source: {source_id!r}")

        start_done = None
        with self._lock:
            entry = self._sources[source_id]
            status = entry.status
            failed_teardown = entry.teardown_done
            if not self._closing:
                self._record_intent(source_id, None)
            if entry.retry_note:
                entry.retry_note = ""
                self._notify_changed()
            if status == SourceStatus.STOPPING:
                raise SourceStateError(f"Source {source_id!r} is already stopping")
            if status == SourceStatus.INACTIVE:
                stale = self._detach(entry)   # normally empty
                if not any(stale) and failed_teardown.is_set():
                    return
            else:
                stale = self._detach(entry)
            entry.generation += 1             # cancels in-flight start / watchdog
            gen = entry.generation
            if status == SourceStatus.STARTING:
                start_done = entry.start_done
            entry.status = SourceStatus.STOPPING
            self._notify_changed()

        if start_done is not None:
            # The starting thread owns whatever it launched; it tears it down
            # when it notices the generation changed.
            if not start_done.wait(timeout=_START_POLL_SECS + _THREAD_JOIN_SECS
                                   + _TERM_WAIT_SECS + _KILL_WAIT_SECS):
                log.warning("Start of %r did not unwind in time", source_id)
        self._wait_failed_teardown(source_id, failed_teardown)
        self._teardown(source_id, stale)

        with self._lock:
            if entry.generation == gen and entry.status == SourceStatus.STOPPING:
                entry.status = SourceStatus.INACTIVE
                entry.error_msg = ""
                self._notify_changed()

    def stop_all(self) -> None:
        """Stop all sources.  Swallows individual errors."""
        for sid in list(SOURCE_CATALOG):
            try:
                self.stop_source(sid)
            except Exception:
                log.exception("Error stopping source %r during stop_all", sid)

    def set_retry_note(self, source_id: str, note: str) -> None:
        """Attach a short "retrying…" note to a source's status (autostart)."""
        with self._lock:
            entry = self._sources[source_id]
            if entry.retry_note != note:
                entry.retry_note = note
                self._notify_changed()

    def status_of(self, source_id: str) -> SourceStatus:
        with self._lock:
            return self._sources[source_id].status

    def close(self) -> None:
        """Refuse new starts, stop everything and release the spawner thread.

        After close(), :meth:`start_source` raises :class:`SourceStateError`.
        """
        with self._lock:
            self._closing = True
        self.stop_all()
        self._spawner.shutdown(wait=False)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_bladerf_free(self, source_id: str) -> None:
        """Raise SourceStateError if another BladeRF user is alive.  Lock held."""
        for sid in _BLADERF_SOURCES - {source_id}:
            other = self._sources[sid]
            busy = other.status in (
                SourceStatus.ACTIVE, SourceStatus.STARTING, SourceStatus.STOPPING
            )
            if (other.status == SourceStatus.ERROR and other.flowgraph_proc is not None
                    and other.flowgraph_proc.poll() is None):
                busy = True
            if busy:
                raise SourceStateError(
                    f"Cannot start {source_id!r}: {sid!r} is using the BladeRF device"
                )
        if any(p.poll() is None for p in self._reaping):
            raise SourceStateError(
                f"Cannot start {source_id!r}: a previous BladeRF flowgraph is still "
                "shutting down; try again in a few seconds"
            )

    def _wait_failed_teardown(self, source_id: str, done: threading.Event) -> None:
        """Wait (lock NOT held) for a teardown started by _fail_if_current,
        so a restart doesn't race it, e.g. the old teardown switching the
        interface back to managed under the new capture."""
        if done.is_set():
            return
        log.debug("Waiting for %r to finish its previous teardown", source_id)
        if not done.wait(timeout=_THREAD_JOIN_SECS + _TERM_WAIT_SECS + _KILL_WAIT_SECS
                         + _RESTORE_WAIT_SECS):
            log.warning("Previous teardown of %r did not finish in time", source_id)

    def _detach(self, entry: SourceEntry) -> _Stale:
        """Detach capture/thread/proc from ``entry``.  Lock must be held."""
        stale = (entry.capture, entry.thread, entry.flowgraph_proc, entry.restore_iface)
        entry.sdr = {}
        self._levels.pop(entry.source_id, None)
        entry.capture = None
        entry.thread = None
        entry.restore_iface = None
        if entry.flowgraph_proc is not None:
            self._reaping.add(entry.flowgraph_proc)
        entry.flowgraph_proc = None
        return stale

    def _teardown(self, source_id: str, stale: _Stale) -> None:
        """Stop a detached capture, join its thread, reap its process.

        Must be called WITHOUT the lock held (it blocks).
        """
        capture, thread, proc, restore_iface = stale
        if capture is not None:
            try:
                capture.stop()
            except Exception:
                log.exception("Error stopping capture %r", source_id)
        if (thread is not None and thread is not threading.current_thread()
                and thread.ident is not None):
            thread.join(timeout=_THREAD_JOIN_SECS)
            if thread.is_alive():
                log.warning("Capture thread for %r still alive after %.0fs",
                            source_id, _THREAD_JOIN_SECS)
        if proc is not None:
            self._reap(proc, source_id)
        if restore_iface is not None:
            self._restore_managed(restore_iface)

    def _reap(self, proc: subprocess.Popen, source_id: str) -> None:
        """Terminate and wait for a flowgraph process (lock NOT held).

        The process stays in ``_reaping`` (so the BladeRF counts as busy)
        until it has really exited.  If it survives SIGKILL (e.g. stuck in
        uninterruptible USB I/O), a background thread keeps waiting for it.
        """
        with self._lock:
            self._reaping.add(proc)
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=_TERM_WAIT_SECS)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=_KILL_WAIT_SECS)
        except Exception:
            log.exception("Error terminating flowgraph for %r", source_id)

        if proc.poll() is None:
            log.error("Flowgraph for %r (pid %s) did not exit after SIGKILL; "
                      "will keep waiting in the background", source_id, proc.pid)
            threading.Thread(target=self._finish_reap, args=(proc, source_id),
                             daemon=True, name=f"odid-{source_id}-reap").start()
            return
        self._release_proc(proc)

    def _finish_reap(self, proc: subprocess.Popen, source_id: str) -> None:
        """Background: wait for an unkillable flowgraph, then release it."""
        try:
            proc.wait()
        except Exception:
            log.exception("Error waiting for flowgraph for %r", source_id)
            return
        log.info("Flowgraph for %r finally exited (rc=%s)", source_id, proc.returncode)
        self._release_proc(proc)

    def _release_proc(self, proc: subprocess.Popen) -> None:
        """Close an exited process's pipes and drop it from ``_reaping``.

        Pipes are only closed once their reader threads have finished (they
        get EOF when the process exits); closing a BufferedReader while
        another thread is blocked reading it can deadlock.
        """
        with self._lock:
            readers = self._readers.pop(proc, [])
            self._stderr_tails.pop(proc, None)
            self._overflows.pop(proc, None)
        streams_busy = False
        for t in readers:
            t.join(timeout=_READER_JOIN_SECS)
            if t.is_alive():
                streams_busy = True
        if streams_busy:
            # e.g. a grandchild still holds the pipe; the daemon reader
            # closes its own stream when it eventually hits EOF.
            log.debug("Flowgraph log reader still running; leaving its pipe open")
        else:
            for stream in (proc.stdout, proc.stderr):
                try:
                    if stream is not None:
                        stream.close()
                except Exception:
                    pass
        with self._stdin_lock:
            try:
                if proc.stdin is not None:
                    proc.stdin.close()
            except Exception:
                pass
        with self._lock:
            self._reaping.discard(proc)

    def _cancelled(self, entry: SourceEntry, gen: int) -> bool:
        with self._lock:
            return entry.generation != gen

    def _wait_flowgraph_startup(self, proc: subprocess.Popen, entry: SourceEntry, gen: int) -> None:
        """Poll the new flowgraph for ~3 s; raise if it dies or we are cancelled."""
        deadline = time.monotonic() + _START_POLL_SECS
        while time.monotonic() < deadline:
            time.sleep(0.1)
            if self._cancelled(entry, gen):
                raise _StartCancelled()
            if proc.poll() is not None:
                raise RuntimeError(
                    f"Flowgraph exited immediately (rc={proc.returncode}): "
                    f"{self._stderr_tail(proc)}"
                )

    def _stderr_tail(self, proc: subprocess.Popen) -> str:
        """Last ~500 chars of an exited flowgraph's stderr, without blocking.

        The stderr reader thread collects the tail; give it a bounded moment
        to reach EOF.  Never read the pipe here: a grandchild that inherited
        it can keep it open forever.
        """
        with self._lock:
            readers = list(self._readers.get(proc, []))
            tail = self._stderr_tails.get(proc)
        for t in readers:
            if t.name.endswith("-err"):
                t.join(timeout=_STDERR_TAIL_WAIT_SECS)
        if tail is None:
            return ""
        return "\n".join(list(tail))[-500:].strip()

    def _do_start(self, source_id: str, config: dict, gen: int) -> None:
        """Blocking startup logic (runs in the *calling* thread).

        Everything launched here is kept in locals until the final commit,
        which only happens if ``gen`` is still current; otherwise (or on any
        error) it is torn down before re-raising.
        """
        entry = self._sources[source_id]
        catalog = SOURCE_CATALOG[source_id]
        callback = self._make_counted_callback(entry)
        proc: Optional[subprocess.Popen] = None
        capture = None
        restore_iface: Optional[str] = None   # put back in managed mode on stop

        try:
            # --- BladeRF sources: launch flowgraph first ---
            # (bladerf-dual is disabled in the catalog and rejected by
            # start_source() before reaching here.)
            if catalog["has_flowgraph"] and not catalog.get("is_dual"):
                zmq_addr = _validate_zmq_addr(config.get("zmq_addr", catalog["zmq_default"]))
                gain = _validate_gain(config.get("gain", 40))
                args = ["--zmq", _bind_addr(zmq_addr), "--gain", str(gain)]
                if source_id == "bladerf-wifi":
                    args += self._bladerf_wifi_args(config)
                elif source_id == "bladerf-bt" and config.get("channel") is not None:
                    args += ["--channel", str(_validate_bt_channel(config["channel"]))]
                monitor = config.get("monitor", catalog.get("monitor_default", True))
                if catalog.get("sdr_control"):
                    args += self._sdr_args(config, monitor)
                proc = self._launch_flowgraph(catalog["flowgraph"], args)
                # Readers start at once so a chatty flowgraph can't fill the
                # pipe during startup; they keep a stderr tail for errors.
                self._start_flowgraph_readers(proc, catalog["flowgraph"])
                self._wait_flowgraph_startup(proc, entry, gen)
                from odid.capture.bladerf import BladeRFCapture
                capture = BladeRFCapture(callback=callback, zmq_addr=zmq_addr,
                                         on_event=self._make_sdr_event_handler(source_id, gen))
                if catalog.get("sdr_control"):
                    entry.sdr = {"gain_db": gain, "monitor": monitor is True, "recording": None}

            elif source_id == "wifi-dongle":
                interface = validate_wifi_interface(config.get("interface", ""))
                from odid.capture.wifi import WiFiCapture
                channel = config.get("channel") or WiFiCapture.ODID_PRIMARY_CHANNEL
                try:
                    channel = int(channel)
                except (TypeError, ValueError):
                    raise ValueError("WiFi channel must be a number")
                if not 1 <= channel <= 233:
                    raise ValueError("WiFi channel must be between 1 and 233")
                monitor_set = self._ensure_monitor_mode(interface, channel)
                try:
                    capture = WiFiCapture(interface=interface, callback=callback,
                                          channel=channel)
                except BaseException:
                    if monitor_set:
                        self._restore_managed(interface)
                    raise
                restore_iface = interface if monitor_set else None

            elif source_id == "builtin-bt":
                from odid.capture.bluetooth import _BLEAK_AVAILABLE
                if not _BLEAK_AVAILABLE:
                    raise ImportError(
                        "bleak is required for Bluetooth capture. "
                        "Install it with: pip install bleak"
                    )
                adapter = config.get("adapter") or None
                if adapter is not None:
                    if not isinstance(adapter, str) or not _IFACE_RE.match(adapter):
                        raise ValueError("Invalid Bluetooth adapter name (e.g. 'hci0')")
                from odid.capture.bluetooth import BTCapture
                capture = BTCapture(callback=callback, adapter=adapter)

            else:
                raise RuntimeError(f"No capture implementation for {source_id!r}")

            t = threading.Thread(
                target=self._run_capture,
                args=(source_id, capture, gen),
                daemon=True,
                name=f"odid-{source_id}",
            )

            with self._lock:
                if entry.generation != gen:
                    raise _StartCancelled()
                entry.capture = capture
                entry.thread = t
                entry.flowgraph_proc = proc
                entry.restore_iface = restore_iface
                entry.status = SourceStatus.ACTIVE
                entry.retry_note = ""
                self._record_intent(source_id, config)
                # Start inside the lock so a racing stop never sees an
                # unstarted thread.
                t.start()
                self._notify_changed()
        except BaseException:
            if proc is not None:
                self._reap(proc, source_id)
            if restore_iface is not None:
                self._restore_managed(restore_iface)
            raise

        if proc is not None:
            threading.Thread(
                target=self._watchdog, args=(source_id, proc, gen),
                daemon=True, name=f"odid-{source_id}-watchdog",
            ).start()
        log.info("Source %r started", source_id)

    @staticmethod
    def _ensure_monitor_mode(interface: str, channel: int) -> bool:
        """Put ``interface`` into monitor mode if needed; True if we changed it.

        Refuses an interface that has an IP address: it is carrying network
        traffic (perhaps the session used to manage this Pi), so taking it
        over must be a deliberate ``odid setup``.
        """
        from odid.capture import interface as iface
        if iface.is_monitor_mode(interface):
            return False
        if iface.interface_has_ip(interface):
            raise ValueError(
                f"WiFi interface {interface} is connected to a network (it has an IP "
                "address), so it was not switched to monitor mode. Use a dedicated "
                f"capture adapter, or run: sudo odid setup {interface}"
            )
        try:
            iface.enable_monitor_mode(interface, channel)
        except iface.InterfaceError as exc:
            raise RuntimeError(
                f"Could not put {interface} into monitor mode: {exc}. "
                f"Try: sudo odid setup {interface}"
            ) from None
        return True

    @staticmethod
    def _restore_managed(interface: str) -> None:
        """Undo _ensure_monitor_mode (best effort, lock NOT held)."""
        from odid.capture import interface as iface
        try:
            iface.disable_monitor_mode(interface)
        except Exception as exc:
            log.warning("Could not restore %s to managed mode: %s", interface, exc)

    @staticmethod
    def _bladerf_wifi_args(config: dict) -> list:
        """Flowgraph args for bladerf-wifi from optional ``hop``/``channel``.

        Default: stay on channel 6 (``--no-hop --freq 2437``), where ODID NAN
        and most ODID beacons are sent.  ``hop: true`` hops channels 1-11
        starting from ``channel``.
        """
        hop = _validate_hop(config.get("hop", False))
        channel = config.get("channel")
        channel = (_BLADERF_WIFI_DEFAULT_CHANNEL if channel is None
                   else _validate_wifi_channel(channel))
        args = ["--freq", str(_WIFI_CHANNEL_MHZ[channel])]
        if not hop:
            args.append("--no-hop")
        return args

    def _sdr_args(self, config: dict, monitor) -> list:
        """sdr_monitor options: control pipe, IQ directory, monitor on/off."""
        if not isinstance(monitor, bool):
            raise ValueError("monitor must be true or false")
        args = ["--control-stdin"]
        if self._iq_dir:
            args += ["--iq-dir", str(self._iq_dir)]
        if not monitor:
            args.append("--no-monitor")
        return args

    # ------------------------------------------------------------------
    # SDR control (IQ recording, live gain) and flowgraph events
    # ------------------------------------------------------------------

    def record_iq(self, source_id: str, seconds) -> None:
        """Ask an SDR source's flowgraph to record ``seconds`` of IQ.

        The result arrives asynchronously in the source's ``sdr`` status
        (``recording`` / ``last_record``).
        """
        seconds = _validate_record_secs(seconds)
        if not self._iq_dir:
            raise SourceStateError("IQ recording is not configured (no data directory)")
        self.send_control(source_id, {"cmd": "record", "seconds": seconds})

    def stop_record(self, source_id: str) -> None:
        self.send_control(source_id, {"cmd": "record_stop"})

    def set_gain(self, source_id: str, gain) -> None:
        self.send_control(source_id, {"cmd": "gain", "db": _validate_gain(gain)})

    def send_control(self, source_id: str, cmd: dict) -> None:
        """Write one JSON command line to an ACTIVE SDR flowgraph's stdin.

        Raises KeyError (unknown source), SourceStateError (not an active
        SDR source, or its flowgraph stopped reading).
        """
        if source_id not in SOURCE_CATALOG:
            raise KeyError(f"Unknown source: {source_id!r}")
        with self._lock:
            entry = self._sources[source_id]
            if not SOURCE_CATALOG[source_id].get("sdr_control"):
                raise SourceStateError(f"{source_id} has no SDR controls")
            proc = entry.flowgraph_proc
            if entry.status != SourceStatus.ACTIVE or proc is None or proc.stdin is None:
                raise SourceStateError(f"{source_id} is not running")
        line = (json.dumps(cmd) + "\n").encode()
        with self._stdin_lock:
            try:
                proc.stdin.write(line)
                proc.stdin.flush()
            except (OSError, ValueError):     # broken pipe / closed by _release_proc
                raise SourceStateError(f"{source_id} is not accepting commands") from None

    def recording_files(self) -> set:
        """Base names of IQ recordings being written right now."""
        with self._lock:
            return {e.sdr["recording"]["file"] for e in self._sources.values()
                    if e.sdr.get("recording") and e.sdr["recording"].get("file")}

    def _make_sdr_event_handler(self, source_id: str, gen: int) -> Callable:
        """Handler for the flowgraph's ``{"kind": ...}`` ZMQ messages."""
        def _on_event(msg: dict) -> None:
            kind = msg.get("kind")
            if kind == "monitor":
                self._on_sdr_monitor(source_id, gen, msg)
            elif kind in ("record", "gain", "control_error"):
                self._on_sdr_result(source_id, gen, kind, msg)
        return _on_event

    def _current_sdr_entry(self, source_id: str, gen: int) -> Optional[SourceEntry]:
        """The entry if ``gen`` is still its live generation (lock held)."""
        e = self._sources[source_id]
        if e.generation != gen or e.status != SourceStatus.ACTIVE:
            return None
        return e

    def _on_sdr_monitor(self, source_id: str, gen: int, msg: dict) -> None:
        with self._lock:
            e = self._current_sdr_entry(source_id, gen)
            if e is None:
                return
            changed = False
            rec = msg.get("recording") if isinstance(msg.get("recording"), dict) else None
            for key, value in (("recording", rec), ("can_record", bool(msg.get("can_record"))),
                               ("record_note", msg.get("record_note") or "")):
                if key == "recording":
                    # elapsed changes every message; only start/stop is news
                    if (e.sdr.get(key) or {}).get("file") != (value or {}).get("file"):
                        changed = True
                elif e.sdr.get(key) != value:
                    changed = True
                e.sdr[key] = value
            self._update_level(e, msg)
            if changed:
                self._notify_changed()
        if self._on_monitor is not None:
            try:
                self._on_monitor(source_id, msg)
            except Exception:
                log.exception("on_monitor callback error")

    def _update_level(self, e: SourceEntry, msg: dict, now: Optional[float] = None) -> None:
        """Fold one monitor message into e.sdr's level reading (lock held)."""
        def num(key):
            v = msg.get(key)
            return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None
        for key in ("mean_dbfs", "noise_dbfs"):
            if num(key) is not None:
                e.sdr[key] = num(key)
        clip, peak = num("clip_pct"), num("peak_dbfs")
        if clip is None or peak is None:
            return
        now = time.monotonic() if now is None else now
        dq = self._levels.setdefault(e.source_id, collections.deque())
        dq.append((now, clip, peak))
        while dq and now - dq[0][0] > LEVEL_WINDOW_S:
            dq.popleft()
        e.sdr["clip_pct"] = max(c for _t, c, _p in dq)
        e.sdr["peak_dbfs"] = max(p for _t, _c, p in dq)

    def _on_sdr_result(self, source_id: str, gen: int, kind: str, msg: dict) -> None:
        now = time.time()
        with self._lock:
            e = self._current_sdr_entry(source_id, gen)
            if e is None:
                return
            if kind == "gain" and isinstance(msg.get("gain_db"), int):
                e.sdr["gain_db"] = msg["gain_db"]
                e.config["gain"] = msg["gain_db"]
                self._record_intent(source_id, e.config)
                log.info("Source %r gain set to %d dB", source_id, msg["gain_db"])
            elif kind == "record":
                state = msg.get("state")
                last = {k: msg[k] for k in ("state", "file", "seconds", "bytes", "error",
                                            "dropped_pct", "warning") if k in msg}
                last["at"] = now
                e.sdr["last_record"] = last
                if state == "started":
                    e.sdr["recording"] = {"file": msg.get("file"), "seconds": msg.get("seconds"),
                                          "elapsed": 0.0}
                elif state in ("done", "error"):
                    e.sdr["recording"] = None
                (log.warning if state == "error" else log.info)(
                    "Source %r IQ recording %s: %s", source_id, state,
                    msg.get("error") or msg.get("file"))
            else:
                e.sdr["last_error"] = {"error": str(msg.get("error", ""))[:300], "at": now}
                log.warning("Source %r control error: %s", source_id, msg.get("error"))
            self._notify_changed()

    def _fail_if_current(self, src_id: str, gen: int, msg: str) -> None:
        """Move a live source to ERROR and release its resources.

        Only acts if the entry is still ACTIVE on generation ``gen``; a stop
        or restart in progress owns the teardown otherwise.
        """
        with self._lock:
            e = self._sources[src_id]
            if e.generation != gen or e.status != SourceStatus.ACTIVE:
                return
            e.status = SourceStatus.ERROR
            e.error_msg = msg
            stale = self._detach(e)
            e.teardown_done.clear()
            self._notify_changed()
        try:
            self._teardown(src_id, stale)
        finally:
            e.teardown_done.set()

    def _run_capture(self, src_id: str, cap, gen: int) -> None:
        """Capture thread target: moves the source to ERROR on unexpected exit."""
        try:
            cap.sniff()
        except Exception as exc:
            log.exception("Capture thread %r failed", src_id)
            self._fail_if_current(src_id, gen, str(exc) or type(exc).__name__)
        else:
            # A clean return is only expected after stop(); otherwise report it.
            self._fail_if_current(src_id, gen, "Capture ended unexpectedly")

    def _watchdog(self, src_id: str, proc: subprocess.Popen, gen: int) -> None:
        """Mark the source ERROR if its flowgraph dies while ACTIVE."""
        while True:
            time.sleep(_WATCHDOG_INTERVAL)
            with self._lock:
                e = self._sources[src_id]
                if e.generation != gen or e.status != SourceStatus.ACTIVE:
                    return
            rc = proc.poll()
            if rc is not None:
                log.error("Flowgraph for %r exited (rc=%s)", src_id, rc)
                self._fail_if_current(src_id, gen, _flowgraph_exit_message(rc))
                return

    def _launch_flowgraph(self, script_name: str, args: list) -> subprocess.Popen:
        """Launch a GNU Radio flowgraph subprocess.

        The flowgraph binds a ZMQ PUSH socket on 127.0.0.1 and the capture
        connects a PULL socket to it.
        """
        if self._flowgraph_dir is None:
            raise RuntimeError(
                "Cannot find the flowgraphs directory (odid/flowgraphs); "
                "reinstall odid-sniffer or set ODID_FLOWGRAPH_DIR."
            )
        script = Path(self._flowgraph_dir) / script_name
        if not script.exists():
            raise RuntimeError(f"Flowgraph script not found: {script}")

        cmd = [sys.executable, str(script)] + [str(a) for a in args]
        log.info("Launching flowgraph: %s", " ".join(cmd))
        return self._spawn(cmd)

    def _spawn(self, cmd: list) -> subprocess.Popen:
        """Popen ``cmd`` from the long-lived spawner thread with PDEATHSIG."""
        preexec = _make_pdeathsig_preexec(os.getpid())
        fut = self._spawner.submit(
            subprocess.Popen,
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.PIPE,    # --control-stdin commands (send_control)
            start_new_session=True,   # don't propagate Ctrl+C to flowgraph
            preexec_fn=preexec,
        )
        # NOTE: the caller starts reader threads right away; they keep a
        # stderr tail used for startup-failure messages.
        return fut.result()

    def _start_flowgraph_readers(self, proc: subprocess.Popen, script_name: str) -> None:
        """Attach daemon threads that forward flowgraph stdout/stderr to the logger.

        Started immediately after launch.  The last stderr lines are kept in
        ``_stderr_tails[proc]`` for crash diagnostics (see _stderr_tail).
        """
        fg_log = logging.getLogger(f"odid.flowgraph.{script_name.removesuffix('.py')}")
        tail: collections.deque = collections.deque(maxlen=_STDERR_TAIL_LINES)
        overflows = [0]
        threads = []
        for stream, classify, tag in (
            (proc.stdout, lambda _msg: logging.DEBUG, "out"),
            (proc.stderr, _stderr_level, "err"),
        ):
            def _reader(s=stream, cls=classify, keep=(tail if tag == "err" else None)):
                try:
                    for line in s:
                        msg = line.decode(errors="replace").rstrip()
                        if msg and keep is not None:
                            keep.append(msg)
                        if msg:
                            if _OVERFLOW_RE.match(msg):
                                overflows[0] += len(msg)
                                msg = f"SDR sample overflow ({len(msg)}x): host not keeping up"
                            elif msg.startswith("SDR sample overflow"):
                                overflows[0] += 1
                            fg_log.log(cls(msg), "%s", msg)
                except Exception:
                    pass
                finally:
                    # Close our own stream on EOF so _reap never has to close
                    # it from another thread while we're blocked reading.
                    try:
                        s.close()
                    except Exception:
                        pass
            t = threading.Thread(target=_reader, daemon=True,
                                 name=f"odid-fg-{script_name}-{tag}")
            threads.append(t)
        with self._lock:
            self._readers[proc] = threads
            self._stderr_tails[proc] = tail
            self._overflows[proc] = overflows
        for t in threads:
            t.start()

    def _make_counted_callback(self, entry: SourceEntry) -> Callable:
        """Wrap the shared on_frame callback to count frames per source."""
        def _cb(frame):
            entry.frame_count += 1   # GIL guarantees atomicity for simple int increment
            self._on_frame(frame)
        return _cb

    def _record_intent(self, source_id: str, config: Optional[dict]) -> None:
        """Call on_intent if registered.  Must be called with lock held."""
        if self._on_intent is not None:
            try:
                self._on_intent(source_id, None if config is None else dict(config))
            except Exception:
                log.exception("on_intent callback error")

    def _notify_changed(self) -> None:
        """Call on_sources_changed if registered.  Must be called with lock held."""
        if self._on_sources_changed is not None:
            try:
                self._on_sources_changed()
            except Exception:
                log.exception("on_sources_changed callback error")
