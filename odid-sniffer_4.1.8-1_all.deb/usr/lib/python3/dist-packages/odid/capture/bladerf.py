"""BladeRF SDR capture via GNU Radio ZMQ bridge.

The BladeRF is a raw SDR: it streams IQ samples, not decoded packets.
A GNU Radio flowgraph must run alongside this process to demodulate the
RF signal and emit decoded frames over a ZMQ PUSH socket.

Integration path
----------------
WiFi:
    GNU Radio + gr-ieee802-11 demodulates 802.11 OFDM frames and emits
    raw 802.11 frame bytes over ZMQ.  BladeRFCapture wraps them in scapy
    and passes them through the existing extract_odid() decoder.

    Flowgraph: flowgraphs/odid_wifi_bladerf.py

Bluetooth LE:
    GNU Radio GFSK demod + flowgraphs/ble_dsp.py framer reconstructs BLE
    ADV_NONCONN_IND PDUs and emits the ODID service data payload bytes
    (UUID 0xFFFA service data, starting at app code 0x0D) over ZMQ.

    Flowgraph: flowgraphs/odid_bt_bladerf.py

ZMQ message format (JSON, UTF-8 encoded)
-----------------------------------------
{
    "source":  "wifi" | "bt",
    "mac":     "aa:bb:cc:dd:ee:ff",
    "rssi":    -72,              # optional, dBm
    "snr":     23.5,             # optional, dB (WiFi flowgraph)
    "channel": 6,                # optional, tuned 2.4 GHz channel (WiFi)
    "payload": "deadbeef..."     # hex-encoded bytes
}

For "wifi": payload is the bare 802.11 MAC frame as published by
gr-ieee802-11 ``decode_mac`` (no RadioTap header, FCS stripped).  A payload
that starts with a valid RadioTap header is also accepted.  ``rssi`` (dBm)
from the envelope is copied into ``ODIDFrame.signal_dbm`` when the frame
carries no signal value itself; ``snr`` (dB) goes into ``ODIDFrame.snr_db``
(it is *not* a dBm value).  ``channel`` fills ``ODIDFrame.channel``.

Every frame gets ``ODIDFrame.timestamp`` = receive time (UTC) if unset.

For "bt": payload is the BLE service data bytes starting at the app code byte
(0x0D), i.e. what bleak returns as service_data[UUID_0xFFFA].

Quick start
-----------
    # Terminal 1: run the GNU Radio WiFi flowgraph:
    python flowgraphs/odid_wifi_bladerf.py   # binds tcp://127.0.0.1:5555

    # Terminal 2: start ODID capture:
    python -m odid bladerf --zmq tcp://127.0.0.1:5555

Requirements
------------
    pip install pyzmq
    # Plus GNU Radio + gr-osmosdr, and gr-ieee802-11 for the WiFi flowgraph
"""

import json
import logging
import math
import struct
import threading
from datetime import datetime, timezone
from typing import Callable, Optional

from odid.decode.frame import ODIDFrame

log = logging.getLogger(__name__)


class BladeRFCapture:
    """Receive ODID frames from a GNU Radio flowgraph via ZMQ.

    Mirrors the :class:`~odid.capture.wifi.WiFiCapture` interface so the
    same CLI pipeline (tracker, writer thread, TUI, web) works unchanged.
    """

    FRAME_TYPE_WIFI = "BladeRF WiFi"
    FRAME_TYPE_BT = "BladeRF BT"

    def __init__(
        self,
        callback: Callable[[ODIDFrame], None],
        zmq_addr: str = "tcp://127.0.0.1:5555",
        on_event: Optional[Callable[[dict], None]] = None,
    ):
        """
        Args:
            callback: Called with each decoded ODIDFrame.
            zmq_addr: ZMQ PULL address to connect to.  Must match the PUSH
                      address bound by the GNU Radio flowgraph.
            on_event: Called with the flowgraph's non-frame messages (JSON
                      objects with a ``kind``: monitor, record, gain,
                      control_error; see flowgraphs/sdr_monitor.py).
        """
        self.callback = callback
        self.zmq_addr = zmq_addr
        self.on_event = on_event
        self._stop_event = threading.Event()
        self.packet_counts: dict[int | str, int] = {}  # channel, or frame type

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sniff(self) -> None:
        """Connect to the ZMQ socket and process frames until stop() is called.

        Raises:
            ImportError: if pyzmq is not installed.
        """
        try:
            import zmq
        except ImportError:
            raise ImportError(
                "pyzmq is required for BladeRF capture. "
                "Install it with: pip install pyzmq"
            )

        ctx = zmq.Context()
        try:
            sock = ctx.socket(zmq.PULL)
        except BaseException:
            ctx.term()
            raise
        try:
            sock.setsockopt(zmq.RCVTIMEO, 200)  # ms; allows stop() to be noticed promptly
            sock.connect(self.zmq_addr)
        except BaseException:
            # Don't leak the socket/context (and its I/O thread) on a bad address.
            sock.close(0)
            ctx.term()
            raise

        log.info("BladeRF capture connected to %s", self.zmq_addr)

        try:
            while not self.stopped:
                try:
                    raw = sock.recv()
                except zmq.Again:
                    continue  # timeout: loop back and check stop_event

                try:
                    frame = self._parse_message(raw)
                except Exception:
                    log.exception("BladeRF: error parsing ZMQ message (%d bytes)", len(raw))
                    continue
                if frame is None:
                    continue

                key = frame.channel if isinstance(frame.channel, int) else frame.frame_type
                self.packet_counts[key] = (
                    self.packet_counts.get(key, 0) + 1
                )
                try:
                    self.callback(frame)
                except Exception:
                    log.exception("BladeRF callback error")
        finally:
            sock.close()
            ctx.term()
            log.info("BladeRF capture stopped")

    def stop(self) -> None:
        """Signal sniff() to exit on its next ZMQ receive timeout."""
        self._stop_event.set()

    @property
    def stopped(self) -> bool:
        return self._stop_event.is_set()

    # ------------------------------------------------------------------
    # Internal frame parsing
    # ------------------------------------------------------------------

    def _parse_message(self, raw: bytes) -> Optional[ODIDFrame]:
        """Decode a ZMQ message into an ODIDFrame, or return None."""
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            log.debug("BladeRF: malformed ZMQ message (%d bytes)", len(raw))
            return None
        if not isinstance(data, dict):
            log.debug("BladeRF: ZMQ message is not a JSON object")
            return None
        if "kind" in data:                 # monitor / control event, not a frame
            if self.on_event is not None and isinstance(data["kind"], str):
                try:
                    self.on_event(data)
                except Exception:
                    log.exception("BladeRF event callback error")
            return None

        payload_hex = data.get("payload", "")
        if not isinstance(payload_hex, str) or not payload_hex:
            return None
        try:
            payload = bytes.fromhex(payload_hex)
        except ValueError:
            log.debug("BladeRF: invalid hex in payload field")
            return None

        source = data.get("source", "wifi")

        if source == "wifi":
            frame = self._parse_wifi(payload)
            if frame is not None:
                if frame.signal_dbm is None:
                    frame.signal_dbm = _envelope_rssi(data)
                frame.snr_db = _envelope_number(data, "snr")
                if frame.channel is None:
                    frame.channel = _envelope_channel(data)
        elif source == "bt":
            frame = self._parse_bt(data, payload)
        else:
            log.debug("BladeRF: unknown source field %r", source)
            return None

        if frame is not None and getattr(frame, "timestamp", None) is None:
            frame.timestamp = datetime.now(timezone.utc)
        return frame

    def _parse_wifi(self, payload: bytes) -> Optional[ODIDFrame]:
        """Parse bare 802.11 bytes (or RadioTap-prefixed) and run extract_odid()."""
        from scapy.layers.dot11 import Dot11, RadioTap
        from odid.decode.frame import extract_odid

        try:
            if _looks_like_radiotap(payload):
                pkt = RadioTap(payload)
            else:
                pkt = Dot11(payload)
        except Exception:
            log.debug("BladeRF WiFi: scapy failed to parse frame (%d bytes)", len(payload))
            return None

        frame = extract_odid(pkt)
        if frame is not None:
            frame.frame_type = self.FRAME_TYPE_WIFI
        return frame

    def _parse_bt(self, meta: dict, payload: bytes) -> Optional[ODIDFrame]:
        """Parse BLE service data bytes using the shared bluetooth parser."""
        from odid.capture.bluetooth import parse_odid_service_data

        mac = meta.get("mac")
        if not isinstance(mac, str):
            mac = "00:00:00:00:00:00"
        rssi = _envelope_rssi(meta)
        frame = parse_odid_service_data(mac, rssi, payload)
        if frame is not None:
            frame.frame_type = self.FRAME_TYPE_BT
        return frame


def _looks_like_radiotap(payload: bytes) -> bool:
    """True if ``payload`` starts with a plausible RadioTap header.

    RadioTap: version 0, pad 0, little-endian it_len >= 8 and <= len(payload),
    followed by a 32-bit present bitmap.  A bare 802.11 frame's first bytes
    (frame control + duration) almost never satisfy all of these *and* leave
    room for an 802.11 header after it_len.
    """
    if len(payload) < 8 or payload[0] != 0 or payload[1] != 0:
        return False
    (it_len,) = struct.unpack_from("<H", payload, 2)
    # 10 = minimum 802.11 header (ACK/CTS); real ODID frames are much longer
    return 8 <= it_len <= len(payload) - 10 and it_len % 2 == 0


def _envelope_number(meta: dict, key: str) -> Optional[float]:
    """Return a finite float from envelope field ``key``, or None."""
    v = meta.get(key)
    if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v):
        return float(v)
    return None


def _envelope_rssi(meta: dict) -> Optional[int]:
    """Return the envelope ``rssi`` (dBm) as an int, or None.

    ``snr`` is deliberately *not* used as a fallback: it is a positive dB
    ratio, not an absolute power, and would corrupt dBm statistics.
    """
    v = _envelope_number(meta, "rssi")
    return None if v is None else int(round(v))


def _envelope_channel(meta: dict) -> Optional[int]:
    """Return the envelope ``channel`` (2.4 GHz channel 1-14), or None."""
    v = meta.get("channel")
    if isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 14:
        return v
    return None
