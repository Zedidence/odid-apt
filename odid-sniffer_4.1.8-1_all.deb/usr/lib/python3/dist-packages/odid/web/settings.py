"""Settings editable from the dashboard (GET/PUT /api/settings).

Changes are written to the overlay file (odid.config.OVERLAY_PATH, in
/var/lib/odid for the service), which is loaded after the root-owned
config.toml, one key at a time. Removing a key from the overlay ("reset")
falls back to config.toml, then to the built-in default.

Only the fields below can be edited. Listener settings (bind address, ports,
TLS) are left to ``odid provision``: a wrong value there would lock the
admin out of a remote sensor.

Live fields are applied at once through the ``apply`` callback; the others
take effect after a service restart, which GET reports as pending.
"""

from __future__ import annotations

import logging
import math
import os
import threading
from dataclasses import dataclass
from typing import Any, Callable, Optional

from odid import config

log = logging.getLogger(__name__)


class SettingsError(ValueError):
    """Rejected settings change (shown to the user)."""


@dataclass(frozen=True)
class Field:
    key: str
    section: Optional[str]     # TOML table; None = top level
    group: str                 # heading in the UI
    label: str
    type: str                  # "float" | "int" | "bool"
    default: Any
    live: bool
    min: Optional[float] = None
    max: Optional[float] = None
    optional: bool = False     # may be unset (None)
    unit: str = ""

    def public(self) -> dict:
        d = {"key": self.key, "group": self.group, "label": self.label, "type": self.type,
             "default": self.default, "live": self.live, "optional": self.optional}
        if self.min is not None:
            d["min"] = self.min
        if self.max is not None:
            d["max"] = self.max
        if self.unit:
            d["unit"] = self.unit
        return d


# Defaults and ranges match odid.cli (_global / _resolve_opts).
FIELDS: tuple[Field, ...] = (
    Field("lat", "observer", "Observer", "Latitude", "float", None, True,
          -90.0, 90.0, optional=True, unit="°"),
    Field("lon", "observer", "Observer", "Longitude", "float", None, True,
          -180.0, 180.0, optional=True, unit="°"),
    Field("drone_ttl", "capture", "Tracking", "Forget drones not heard for (0 = never)",
          "int", 300, True, 0, 10**9, unit="s"),
    Field("max_drones", "capture", "Tracking", "Most drones tracked at once (0 = no limit)",
          "int", 2000, True, 0, 10**7),
    Field("db_retention_days", "output", "Storage", "Delete database history older than (0 = keep)",
          "int", 90, True, 0, 36500, unit="days"),
    Field("min_free_mb", "output", "Storage", "Pause frame logging below free disk",
          "int", 200, True, 0, 10**7, unit="MB"),
    Field("max_sessions", "output", "Storage", "Keep the N newest sessions (0 = all)",
          "int", 0, False, 0, 10**6),
    Field("no_pcap", "output", "Storage", "Don't write pcap files", "bool", False, False),
    Field("no_jsonl", "output", "Storage", "Don't write JSONL logs", "bool", False, False),
    Field("no_csv", "output", "Storage", "Don't write CSV files", "bool", False, False),
    Field("no_db", "output", "Storage", "Don't write the SQLite database", "bool", False, False),
    Field("verbose", None, "Logging", "Debug logging", "bool", False, True),
)
BY_KEY = {f.key: f for f in FIELDS}

_TRUE = {"true", "yes", "on", "1"}
_FALSE = {"false", "no", "off", "0"}


def _coerce(f: Field, v: Any) -> Any:
    """Lenient conversion for values read from config.toml; ValueError if bad."""
    if v is None:
        if f.optional:
            return None
        raise ValueError("missing")
    if f.type == "bool":
        if isinstance(v, bool):
            return v
        if isinstance(v, int) and v in (0, 1):
            return bool(v)
        if isinstance(v, str) and v.strip().lower() in _TRUE | _FALSE:
            return v.strip().lower() in _TRUE
        raise ValueError(v)
    if isinstance(v, bool):
        raise ValueError(v)
    n = float(v) if f.type == "float" else int(v)
    if not math.isfinite(n) or (f.min is not None and n < f.min) or (f.max is not None and n > f.max):
        raise ValueError(v)
    return n


def validate(f: Field, v: Any) -> Any:
    """Strict check of a value sent by the browser (JSON types only)."""
    if v is None and f.optional:
        return None
    if f.type == "bool":
        if not isinstance(v, bool):
            raise SettingsError(f"{f.key}: must be true or false")
        return v
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise SettingsError(f"{f.key}: must be a number")
    if f.type == "int":
        if isinstance(v, float):
            if not v.is_integer():
                raise SettingsError(f"{f.key}: must be a whole number")
            v = int(v)
    else:
        v = float(v)
        if not math.isfinite(v):
            raise SettingsError(f"{f.key}: must be a finite number")
    if (f.min is not None and v < f.min) or (f.max is not None and v > f.max):
        raise SettingsError(f"{f.key}: must be between {f.min:g} and {f.max:g}")
    return v


def _nest(flat: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in flat.items():
        f = BY_KEY[k]
        if f.section is None:
            out[k] = v
        else:
            out.setdefault(f.section, {})[k] = v
    return out


class SettingsService:
    """Reads and writes the overlay; tracks which values are in effect.

    ``running`` holds the values the process started with (or last applied
    live). ``apply(changes)`` is called with the live fields whose value
    changed, from a worker thread, after the overlay was written.
    """

    def __init__(self, running: dict[str, Any],
                 apply: Optional[Callable[[dict[str, Any]], None]] = None):
        self._running = {f.key: running.get(f.key, f.default) for f in FIELDS}
        self._apply = apply
        self._lock = threading.Lock()

    @staticmethod
    def _layers() -> tuple[dict[str, Any], dict[str, Any]]:
        base = {k: v for k, v in config.flatten(config.load_raw()).items() if k in BY_KEY}
        overlay = {k: v for k, v in config.flatten(config.load_overlay()).items() if k in BY_KEY}
        return base, overlay

    @staticmethod
    def _effective(base: dict, overlay: dict) -> dict[str, tuple[Any, str]]:
        """key -> (value, source) where source is dashboard | config | default."""
        out = {}
        for f in FIELDS:
            for layer, name in ((overlay, "dashboard"), (base, "config")):
                if layer.get(f.key) in (None, ""):
                    continue
                try:
                    out[f.key] = (_coerce(f, layer[f.key]), name)
                    break
                except (TypeError, ValueError):
                    log.warning("Ignoring invalid %s setting %s=%r", name, f.key, layer[f.key])
            else:
                out[f.key] = (f.default, "default")
        return out

    def get(self) -> dict:
        with self._lock:
            return self._snapshot(*self._layers())

    def _snapshot(self, base: dict, overlay: dict) -> dict:
        eff = self._effective(base, overlay)
        fields = []
        pending = False
        for f in FIELDS:
            value, source = eff[f.key]
            item = f.public()
            item.update(value=value, source=source, running=self._running[f.key])
            item["restart"] = value != self._running[f.key]   # e.g. a failed live apply
            pending |= item["restart"]
            fields.append(item)
        return {"fields": fields, "restart_required": pending,
                "config_path": str(config.CONFIG_PATH), "overlay_path": str(config.OVERLAY_PATH)}

    def put(self, body: Any) -> tuple[dict, dict[str, Any]]:
        """Apply ``{"values": {key: value}, "reset": [key, ...]}``.

        ``values`` sets dashboard overrides; ``reset`` removes them (back to
        config.toml or the default). Returns (new snapshot, changed values).
        """
        if not isinstance(body, dict):
            raise SettingsError("expected a JSON object")
        values = body.get("values")
        reset = body.get("reset")
        values = {} if values is None else values
        reset = [] if reset is None else reset
        if (not isinstance(values, dict) or not isinstance(reset, list)
                or not all(isinstance(k, str) for k in reset)):
            raise SettingsError("'values' must be an object and 'reset' a list of names")
        unknown = [str(k)[:64] for k in list(values) + reset if k not in BY_KEY]
        if unknown:
            raise SettingsError(f"unknown setting: {', '.join(unknown)}")
        clean = {k: validate(BY_KEY[k], v) for k, v in values.items()}

        with self._lock:
            base, overlay = self._layers()
            before = self._effective(base, overlay)
            new_overlay = dict(overlay)
            for k in reset:
                new_overlay.pop(k, None)
            for k, v in clean.items():
                if v is None:
                    # An optional field cleared: base must not show through
                    if base.get(k) not in (None, ""):
                        raise SettingsError(f"{k}: set in {config.CONFIG_PATH}; it can be "
                                            "changed here but not removed")
                    new_overlay.pop(k, None)
                else:
                    new_overlay[k] = v
            after = self._effective(base, new_overlay)
            lat, lon = after["lat"][0], after["lon"][0]
            if (lat is None) != (lon is None):
                raise SettingsError("latitude and longitude must be set together")
            self._write(new_overlay)
            changed = {k: after[k][0] for k in BY_KEY if after[k][0] != before[k][0]}
            live = {k: v for k, v in changed.items()
                    if BY_KEY[k].live and v != self._running[k]}
            if live and self._apply is not None:
                try:
                    self._apply(live)
                except Exception:
                    # Saved; it will take effect on the next restart
                    log.exception("Applying settings %s failed", ", ".join(live))
                    live = {}
            self._running.update(live)
            return self._snapshot(base, new_overlay), changed

    @staticmethod
    def _write(overlay: dict[str, Any]) -> None:
        path = config.OVERLAY_PATH
        if not overlay:
            try:
                os.unlink(path)
            except FileNotFoundError:
                pass
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        config.write_file(path, _nest(overlay), header="odid dashboard (overrides config.toml)",
                          mode=0o640)
