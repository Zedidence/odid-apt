"""TLS for the dashboard: self-signed certificate, fingerprint, SSL context."""

from __future__ import annotations

import hashlib
import ipaddress
import os
import shutil
import socket
import ssl
import subprocess
from pathlib import Path
from typing import Iterable, Optional

DEFAULT_DIR = Path("/etc/odid/tls")
DEFAULT_CERT = DEFAULT_DIR / "cert.pem"
DEFAULT_KEY = DEFAULT_DIR / "key.pem"


def local_names() -> list[str]:
    """This machine's host name and its mDNS (.local) name."""
    host = socket.gethostname().split(".")[0]
    return [host, f"{host}.local"] if host else []


def generate_self_signed(cert: Path, key: Path, names: Iterable[str] = (),
                         ips: Iterable[str] = (), days: int = 3650) -> None:
    """Create an ECDSA P-256 key and a self-signed certificate with ``openssl``.

    The key is written mode 0600; callers adjust ownership. Raises
    RuntimeError if openssl is missing or fails.
    """
    if shutil.which("openssl") is None:
        raise RuntimeError("openssl is not installed (sudo apt install openssl)")
    names = [n for n in dict.fromkeys(names) if n]
    ips = [str(ipaddress.ip_address(i)) for i in dict.fromkeys(ips) if i]
    san = ",".join([f"DNS:{n}" for n in names + ["localhost"]] +
                   [f"IP:{i}" for i in ips + ["127.0.0.1"]])
    cn = (names or ["odid-sniffer"])[0]
    cert.parent.mkdir(parents=True, exist_ok=True)
    tmp_key = key.with_name(key.name + ".tmp")
    tmp_cert = cert.with_name(cert.name + ".tmp")
    old_umask = os.umask(0o077)
    try:
        r = subprocess.run(
            ["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
             "-nodes", "-days", str(days), "-subj", f"/CN={cn}/O=ODID Sniffer",
             "-addext", f"subjectAltName={san}",
             "-addext", "extendedKeyUsage=serverAuth",
             "-keyout", str(tmp_key), "-out", str(tmp_cert)],
            capture_output=True, text=True, timeout=60)
    finally:
        os.umask(old_umask)
    if r.returncode != 0:
        for p in (tmp_key, tmp_cert):
            p.unlink(missing_ok=True)
        raise RuntimeError(f"openssl failed: {r.stderr.strip()[-300:]}")
    os.chmod(tmp_cert, 0o644)
    os.replace(tmp_key, key)
    os.replace(tmp_cert, cert)


def fingerprint(cert: Path) -> str:
    """SHA-256 fingerprint as browsers show it (AB:CD:...)."""
    der = ssl.PEM_cert_to_DER_cert(Path(cert).read_text())
    digest = hashlib.sha256(der).hexdigest().upper()
    return ":".join(digest[i:i + 2] for i in range(0, len(digest), 2))


def server_context(cert: Path, key: Path) -> ssl.SSLContext:
    """TLS 1.2+ server context. Raises OSError/ssl.SSLError with a clear cause."""
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(cert), str(key))
    return ctx


def tailscale_dns_name(timeout: float = 3.0) -> Optional[str]:
    """This node's MagicDNS name (e.g. pi.tailnet-1234.ts.net), if Tailscale runs."""
    status = tailscale_status(timeout)
    if not status or status.get("BackendState") != "Running":
        return None
    name = ((status.get("Self") or {}).get("DNSName") or "").rstrip(".")
    return name or None


def tailscale_status(timeout: float = 3.0) -> Optional[dict]:
    import json
    if shutil.which("tailscale") is None:
        return None
    try:
        r = subprocess.run(["tailscale", "status", "--json"], capture_output=True,
                           text=True, timeout=timeout)
        return json.loads(r.stdout) if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError, ValueError):
        return None
