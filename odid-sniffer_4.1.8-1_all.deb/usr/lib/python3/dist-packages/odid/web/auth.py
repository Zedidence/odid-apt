"""Dashboard accounts, password hashing, sessions and login rate limiting.

Everything lives in one JSON file (``auth.json`` in the data directory,
mode 0600, owned by the service user)::

    {"version": 1,
     "users":    {"alice": {"hash": "scrypt$...", "role": "admin", "created": ...}},
     "sessions": {"<sha256 of token>": {"user": "alice", "csrf": "...", ...}}}

Session cookies are random 256-bit tokens; only their SHA-256 is stored, so
the file never contains a usable cookie. Sessions survive a service restart.
``odid passwd`` edits the same file while the service runs; the service
notices the change (mtime) and reloads it.

No aiohttp here; this module is used by the CLI too.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)

ROLES = ("admin", "viewer")
USERNAME_RE = re.compile(r"^[a-z0-9_.-]{1,32}$")
MIN_PASSWORD = 8
MAX_PASSWORD = 1024

SESSION_IDLE_S = 12 * 3600          # sliding expiry of a normal session
SESSION_MAX_S = 7 * 24 * 3600       # absolute cap of a normal session
REMEMBER_S = 30 * 24 * 3600         # "remember me" sessions (absolute)
_PERSIST_SLIDE_S = 300              # write sliding renewals at most this often
_RELOAD_CHECK_S = 2.0               # how often to look for external edits

# scrypt: ~16 MiB, ~50-100 ms on a Raspberry Pi 5
_SCRYPT_N, _SCRYPT_R, _SCRYPT_P, _SCRYPT_LEN = 2 ** 14, 8, 1, 32


class AuthError(ValueError):
    """Invalid user name, role or password (message is safe to show)."""


# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------

def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R,
                        p=_SCRYPT_P, dklen=_SCRYPT_LEN, maxmem=64 * 2 ** 20)
    return f"scrypt${_SCRYPT_N}${_SCRYPT_R}${_SCRYPT_P}${_b64(salt)}${_b64(dk)}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, n, r, p, salt, want = encoded.split("$")
        if algo != "scrypt":
            return False
        want_b = base64.b64decode(want)
        dk = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n),
                            r=int(r), p=int(p), dklen=len(want_b), maxmem=64 * 2 ** 20)
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(dk, want_b)


# Verified against when the user does not exist, so timing doesn't reveal it.
_DUMMY_HASH = hash_password(secrets.token_urlsafe(16))


def check_password_rules(password) -> None:
    if not isinstance(password, str) or not MIN_PASSWORD <= len(password) <= MAX_PASSWORD:
        raise AuthError(f"Password must be {MIN_PASSWORD}-{MAX_PASSWORD} characters")


def check_username(name) -> str:
    if not isinstance(name, str) or not USERNAME_RE.match(name):
        raise AuthError("User name must be 1-32 characters: a-z 0-9 _ . -")
    return name


def _token_key(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------

class _AsDirOwner:
    """When running as root (``sudo odid passwd``), do file I/O in a directory
    owned by another user (the service's /var/lib/odid) with that user's
    identity. Root must never create/chown files by path in a directory an
    unprivileged user controls: a planted symlink would redirect the write.
    A no-op when not root or when the directory is root-owned.

    seteuid affects the whole process, so this is only for the single-threaded
    CLI; the service never runs as root.
    """

    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self._saved = None

    def __enter__(self):
        if os.geteuid() != 0:
            return self
        try:
            st = os.stat(self.directory)
        except FileNotFoundError:
            return self
        if st.st_uid == 0:
            return self
        self._saved = (os.getegid(), os.getgroups())
        os.setgroups([])
        os.setegid(st.st_gid)
        os.seteuid(st.st_uid)
        return self

    def __exit__(self, *exc):
        if self._saved is not None:
            egid, groups = self._saved
            os.seteuid(0)
            os.setegid(egid)
            os.setgroups(groups)
            self._saved = None
        return False


@dataclass
class Session:
    user: str
    role: str
    csrf: str
    expires: float


class AuthStore:
    """Users and sessions backed by one JSON file. Thread-safe."""

    def __init__(self, path: Path, clock: Callable[[], float] = time.time) -> None:
        self.path = Path(path)
        self._clock = clock
        self._lock = threading.RLock()
        self._users: dict[str, dict] = {}
        self._sessions: dict[str, dict] = {}
        self._mtime: Optional[float] = None
        self._next_reload_check = 0.0
        self._dirty_slides = 0.0
        self._load()

    # -- persistence ------------------------------------------------------

    def _load(self) -> None:
        with _AsDirOwner(self.path.parent):
            self._load_file()

    def _load_file(self) -> None:
        try:
            st = self.path.stat()
            data = json.loads(self.path.read_text())
        except FileNotFoundError:
            self._users, self._sessions, self._mtime = {}, {}, None
            return
        except (OSError, ValueError) as exc:
            # Keep what we had: never drop to "no users" (= no login) on a
            # transient read error or a half-written file.
            log.error("Cannot read %s: %s", self.path, exc)
            return
        if st.st_mode & 0o077:
            log.warning("%s is accessible by other users; it should be mode 0600", self.path)
        users = data.get("users") if isinstance(data, dict) else None
        sessions = data.get("sessions") if isinstance(data, dict) else None
        self._users = {k: v for k, v in (users or {}).items()
                       if isinstance(v, dict) and v.get("role") in ROLES and isinstance(v.get("hash"), str)}
        self._sessions = {k: v for k, v in (sessions or {}).items() if isinstance(v, dict)}
        self._mtime = st.st_mtime

    def _maybe_reload(self) -> None:
        now = time.monotonic()
        if now < self._next_reload_check:
            return
        self._next_reload_check = now + _RELOAD_CHECK_S
        try:
            mtime = self.path.stat().st_mtime
        except FileNotFoundError:
            mtime = None
        except OSError:
            return
        if mtime != self._mtime:
            self._load()

    def _save_file(self) -> None:
        """Write the file (caller holds the flock, inside _AsDirOwner)."""
        self._purge_expired()
        payload = json.dumps({"version": 1, "users": self._users, "sessions": self._sessions},
                             indent=1, sort_keys=True)
        parent = self.path.parent
        parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(f".{self.path.name}.{secrets.token_hex(8)}.tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600)
        try:
            with os.fdopen(fd, "w") as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        try:
            self._mtime = self.path.stat().st_mtime
        except OSError:
            self._mtime = None

    def _mutate(self, change: Callable[[], None]) -> None:
        """Re-read the file, apply ``change`` and write it back, holding an
        flock so ``odid passwd`` and the running service never overwrite each
        other's edits with a stale copy. Caller holds ``self._lock``."""
        import fcntl
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with _AsDirOwner(self.path.parent):
            lock_path = self.path.with_name(self.path.name + ".lock")
            fd = os.open(lock_path, os.O_RDONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX)
                self._load_file()
                change()
                self._save_file()
            finally:
                os.close(fd)

    def _purge_expired(self) -> None:
        now = self._clock()
        for k in [k for k, s in self._sessions.items()
                  if s.get("expires", 0) <= now or s.get("user") not in self._users]:
            del self._sessions[k]

    # -- users ------------------------------------------------------------

    def users(self) -> dict[str, str]:
        """{name: role}"""
        with self._lock:
            self._maybe_reload()
            return {name: u["role"] for name, u in sorted(self._users.items())}

    def has_users(self) -> bool:
        return bool(self.users())

    def role_of(self, name: str) -> Optional[str]:
        return self.users().get(name)

    def accounts(self) -> list[dict]:
        """[{name, role, created, sessions}] with the number of live sessions."""
        with self._lock:
            self._maybe_reload()
            now = self._clock()
            live: dict[str, int] = {}
            for rec in self._sessions.values():
                if rec.get("expires", 0) > now:
                    live[rec.get("user")] = live.get(rec.get("user"), 0) + 1
            return [{"name": n, "role": u["role"], "created": u.get("created"),
                     "sessions": live.get(n, 0)} for n, u in sorted(self._users.items())]

    def add_user(self, name: str, password: str, role: str) -> None:
        """Create a new user; AuthError if the name is taken."""
        self.set_user(name, password, role, create=True)

    def set_user(self, name: str, password: str, role: Optional[str] = None, *,
                 create: Optional[bool] = None, only_role: Optional[str] = None,
                 keep_token: Optional[str] = None) -> None:
        """Create a user, or change an existing one's password (and role).

        Changing a password signs out that user's existing sessions, except
        ``keep_token`` (the caller's own, when changing their own password).
        ``create``: True = must not exist yet, False = must exist.
        ``only_role``: the existing user must have this role (checked under
        the lock, so a concurrent promotion can't slip through)."""
        check_username(name)
        check_password_rules(password)
        if role is not None and role not in ROLES:
            raise AuthError(f"Role must be one of: {', '.join(ROLES)}")
        encoded = hash_password(password)       # slow: outside the locks
        keep = _token_key(keep_token) if keep_token else None

        def change():
            existing = self._users.get(name)
            if create is True and existing:
                raise AuthError(f"User {name} already exists")
            if create is False and not existing:
                raise AuthError(f"No such user: {name}")
            if only_role is not None and existing and existing["role"] != only_role:
                raise AuthError(f"{name} is not a {only_role}")
            new_role = role or (existing or {}).get("role") or "admin"
            if existing and existing["role"] == "admin" and new_role != "admin" \
                    and self._admins() == [name]:
                raise AuthError("Cannot demote the last admin")
            self._users[name] = {"hash": encoded, "role": new_role,
                                 "created": (existing or {}).get("created", int(self._clock()))}
            for k in [k for k, s in self._sessions.items()
                      if s.get("user") == name and k != keep]:
                del self._sessions[k]
        with self._lock:
            self._mutate(change)

    def remove_user(self, name: str, only_role: Optional[str] = None) -> None:
        def change():
            if name not in self._users:
                raise AuthError(f"No such user: {name}")
            if only_role is not None and self._users[name]["role"] != only_role:
                raise AuthError(f"{name} is not a {only_role}")
            if self._users[name]["role"] == "admin" and self._admins() == [name] \
                    and len(self._users) > 1:
                raise AuthError("Cannot remove the last admin while other users exist")
            del self._users[name]
            self._drop_sessions(lambda s: s.get("user") == name)
        with self._lock:
            self._mutate(change)

    def _admins(self) -> list[str]:
        return [n for n, u in self._users.items() if u["role"] == "admin"]

    def authenticate(self, name, password) -> Optional[str]:
        """Return the user's role if the password is right (slow: scrypt)."""
        if not isinstance(name, str) or not isinstance(password, str) or len(password) > MAX_PASSWORD:
            verify_password("x", _DUMMY_HASH)
            return None
        with self._lock:
            self._maybe_reload()
            user = self._users.get(name)
            encoded = user["hash"] if user else _DUMMY_HASH
        ok = verify_password(password, encoded)
        return user["role"] if ok and user else None

    # -- sessions ---------------------------------------------------------

    def create_session(self, name: str, remember: bool = False) -> tuple[str, Session]:
        token = secrets.token_urlsafe(32)
        now = self._clock()
        rec = {"user": name, "csrf": secrets.token_urlsafe(24), "created": now,
               "remember": bool(remember),
               "expires": now + (REMEMBER_S if remember else SESSION_IDLE_S)}
        with self._lock:
            def change():
                if name not in self._users:
                    raise AuthError(f"No such user: {name}")
                self._sessions[_token_key(token)] = rec
            self._mutate(change)
            role = self._users[name]["role"]
        return token, Session(name, role, rec["csrf"], rec["expires"])

    def get_session(self, token: Optional[str]) -> Optional[Session]:
        """The live session for a cookie value (sliding renewal), or None."""
        if not token or len(token) > 128:
            return None
        key = _token_key(token)
        with self._lock:
            self._maybe_reload()
            rec = self._sessions.get(key)
            if rec is None:
                return None
            user = self._users.get(rec.get("user"))
            now = self._clock()
            if user is None or rec.get("expires", 0) <= now:
                self._sessions.pop(key, None)
                return None
            if not rec.get("remember"):
                new_exp = min(now + SESSION_IDLE_S, rec.get("created", now) + SESSION_MAX_S)
                if new_exp > rec["expires"]:
                    rec["expires"] = new_exp
                    if now - self._dirty_slides >= _PERSIST_SLIDE_S:
                        self._dirty_slides = now

                        def change():
                            if key in self._sessions:
                                self._sessions[key]["expires"] = new_exp
                        try:
                            self._mutate(change)
                        except OSError as exc:
                            log.warning("Could not save session renewal: %s", exc)
            return Session(rec["user"], user["role"], rec["csrf"], rec["expires"])

    def revoke(self, token: Optional[str]) -> None:
        if not token:
            return
        key = _token_key(token)
        with self._lock:
            if key in self._sessions:
                self._mutate(lambda: self._sessions.pop(key, None))

    def _drop_sessions(self, pred) -> None:
        for k in [k for k, s in self._sessions.items() if pred(s)]:
            del self._sessions[k]


# ---------------------------------------------------------------------------
# Login rate limiting
# ---------------------------------------------------------------------------

class LoginLimiter:
    """Exponential lockout per key (client IP, user name).

    The first ``free`` failures cost nothing; each further failure doubles the
    wait, up to ``max_wait`` seconds. A success clears the key.
    """

    def __init__(self, free: int = 5, max_wait: float = 300.0,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.free = free
        self.max_wait = max_wait
        self._clock = clock
        self._state: dict[str, tuple[int, float]] = {}   # key -> (failures, locked_until)
        self._lock = threading.Lock()

    def retry_after(self, *keys: str) -> float:
        now = self._clock()
        with self._lock:
            return max([0.0] + [self._state.get(k, (0, 0.0))[1] - now for k in keys])

    def attempt(self, *keys: str) -> float:
        """Reserve an attempt before the (slow) password check.

        Returns the wait in seconds if any key is locked out (nothing is
        recorded). Otherwise the attempt is counted as a failure up front, so
        concurrent requests can't all slip past the check while the first
        hashes run; call ``success()`` afterwards to clear it.
        """
        now = self._clock()
        with self._lock:
            wait = max([0.0] + [self._state.get(k, (0, 0.0))[1] - now for k in keys])
            if wait > 0:
                return wait
            self._record_failure(now, keys)
            return 0.0

    def failure(self, *keys: str) -> None:
        now = self._clock()
        with self._lock:
            self._record_failure(now, keys)

    def _record_failure(self, now: float, keys) -> None:
        if len(self._state) > 10000:          # bound memory under a spray
            self._state = {k: v for k, v in self._state.items() if v[1] > now}
        for k in keys:
            n = self._state.get(k, (0, 0.0))[0] + 1
            wait = 0.0 if n <= self.free else min(self.max_wait, 2.0 ** (n - self.free))
            self._state[k] = (n, now + wait)

    def success(self, *keys: str) -> None:
        with self._lock:
            for k in keys:
                self._state.pop(k, None)
