"""Restart / reboot / update from the dashboard (POST /api/system/*).

Nothing here runs as root. Each action asks systemd or logind over D-Bus
(``systemctl --no-ask-password``), and the package's polkit rule
(packaging/polkit/50-odid.rules) allows the ``odid`` user exactly three
things: restart odid.service, start odid-update.service, reboot. The
updater is a root oneshot that takes no input from us and reports to
/run/odid-update/status.json.

Only offered when this process runs as a systemd service (odid.cli serve
under odid.service); a shell run has no unit to restart.
"""

from __future__ import annotations

import json
import shutil
import signal
import subprocess
import time
from pathlib import Path
from typing import Callable, Optional

UPDATE_UNIT = "odid-update.service"
UPDATE_STATUS = Path("/run/odid-update/status.json")
ACTIONS = ("restart", "reboot", "update")
# After "start", the job may not have begun yet while status.json still holds
# the previous run's result: report "running" for this long regardless.
START_GRACE_S = 10.0


class ActionError(RuntimeError):
    """systemctl refused or failed; the message is shown to the admin."""


def _systemctl(args: list[str], timeout: float = 20.0, stops_us: bool = False) -> str:
    """Run systemctl. ``stops_us``: the job stops this service, and systemctl,
    being in our cgroup, may be SIGTERMed by it before exiting; that means
    the job was accepted, not that it failed."""
    if shutil.which("systemctl") is None:
        raise ActionError("systemctl not found")
    try:
        r = subprocess.run(["systemctl", "--no-ask-password", *args], capture_output=True,
                           text=True, timeout=timeout, env={"LC_ALL": "C", "PATH": "/usr/bin:/bin"})
    except subprocess.TimeoutExpired:
        raise ActionError("systemctl timed out") from None
    except OSError as exc:
        raise ActionError(f"systemctl failed: {exc}") from None
    if stops_us and r.returncode == -signal.SIGTERM:
        return ""
    if r.returncode != 0:
        # First line is the reason ("Failed to restart x: Access denied");
        # systemctl follows it with a generic "See system logs..." pointer
        msg = [ln for ln in (r.stderr or r.stdout).strip().splitlines()
               if not ln.startswith("See system logs")]
        text = msg[0] if msg else f"exit code {r.returncode}"
        if "Access denied" in text or "Interactive authentication required" in text:
            text += " (the polkit rule allows this only for the odid service user)"
        raise ActionError(text[:300])
    return r.stdout


class SystemActions:
    def __init__(self, unit: Optional[str], systemctl: Callable[..., str] = _systemctl,
                 status_path: Path = UPDATE_STATUS,
                 clock: Callable[[], float] = time.monotonic):
        self.unit = unit
        self._systemctl = systemctl
        self._status_path = status_path
        self._clock = clock
        self._update_requested: Optional[float] = None

    @property
    def available(self) -> bool:
        return self.unit is not None

    def run(self, action: str) -> str:
        """Start ``action``; returns a message. Raises ActionError."""
        if not self.available:
            raise ActionError("only available when running as the odid service")
        if action == "restart":
            # --no-block: the restart stops this process; don't wait for it
            self._systemctl(["--no-block", "restart", self.unit], stops_us=True)
            return "Restarting the service. The page reconnects by itself"
        if action == "reboot":
            self._systemctl(["--no-block", "reboot"], stops_us=True)
            return "Rebooting. The sensor will be back in a minute or two"
        if action == "update":
            self._systemctl(["--no-block", "start", UPDATE_UNIT])
            self._update_requested = self._clock()
            return "Update started"
        raise ValueError(f"unknown action: {action}")

    def update_status(self) -> dict:
        """{"running": bool, "result": last status.json or None}."""
        running = False
        if self.available:
            try:
                state = self._systemctl(["show", "-p", "ActiveState", "--value", UPDATE_UNIT],
                                        timeout=5).strip()
                running = state in ("activating", "active", "reloading")
            except ActionError:
                pass
        just_started = (self._update_requested is not None
                        and self._clock() - self._update_requested < START_GRACE_S)
        result = None
        try:
            result = json.loads(self._status_path.read_text())
            if not isinstance(result, dict):
                result = None
        except (OSError, ValueError):
            pass
        if result is not None:
            result = {k: str(result.get(k, "")) for k in ("state", "message", "time", "version")}
            if result["state"] == "running" and not running and not just_started:
                # The unit is the authority: the updater died mid-way
                result.update(state="failed", message="The update stopped unexpectedly "
                                                      "(see /var/log/odid-update.log)")
        return {"available": self.available, "running": running or just_started,
                "result": result}
