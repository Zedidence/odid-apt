"""Web dashboard support: authentication, TLS helpers."""
