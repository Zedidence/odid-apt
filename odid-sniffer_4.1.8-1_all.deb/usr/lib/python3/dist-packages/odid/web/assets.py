"""Dashboard page assets shipped in odid/web/static (loaded once at import).

Only the files listed here are served, by exact name, so there is no path to
traverse.
"""

from __future__ import annotations

from pathlib import Path

_DIR = Path(__file__).resolve().parent / "static"
_TYPES = {
    "app.js": "text/javascript",
    "ui.js": "text/javascript",
    "login.js": "text/javascript",
    "settings.js": "text/javascript",
    "status.js": "text/javascript",
    "logs.js": "text/javascript",
    "captures.js": "text/javascript",
    "actions.js": "text/javascript",
    "account.js": "text/javascript",
    "sdr.js": "text/javascript",
    "leaflet.js": "text/javascript",
    "leaflet.css": "text/css",
    "style.css": "text/css",
}

# name -> (bytes, content type), served at /static/<name>
STATIC: dict[str, tuple[bytes, str]] = {
    name: ((_DIR / name).read_bytes(), ctype) for name, ctype in _TYPES.items()
}


def page(name: str) -> str:
    """An HTML page template (index.html, login.html)."""
    return (_DIR / name).read_text(encoding="utf-8")
