"""Recent log lines for the dashboard (GET /api/logs).

Under systemd the service's own journal is read (``journalctl -u <unit>``,
the odid user is in group systemd-journal), so lines from before a crash or
restart are there too. Elsewhere (``odid serve`` from a shell) an in-process
ring buffer of this run's records is used.

journald only knows a line's level if it starts with a syslog prefix such as
``<4>``; odid.cli adds one when stderr is the journal (see journal_prefix).
"""

from __future__ import annotations

import collections
import json
import logging
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Callable, Optional

LEVELS = ("debug", "info", "warning", "error")
MAX_LINES = 5000
# journalctl -p: this priority and more severe
_JOURNAL_PRIORITY = {"debug": "7", "info": "6", "warning": "4", "error": "3"}
_TIME_PREFIX = re.compile(r"^\d\d:\d\d:\d\d ")


def level_of_priority(p) -> str:
    try:
        p = int(p)
    except (TypeError, ValueError):
        return "info"
    return "error" if p <= 3 else "warning" if p == 4 else "debug" if p >= 7 else "info"


def _level_of_record(levelno: int) -> str:
    if levelno >= logging.ERROR:
        return "error"
    if levelno >= logging.WARNING:
        return "warning"
    return "info" if levelno >= logging.INFO else "debug"


def syslog_priority(levelno: int) -> int:
    if levelno >= logging.CRITICAL:
        return 2
    return {"error": 3, "warning": 4, "info": 6, "debug": 7}[_level_of_record(levelno)]


def stderr_is_journal() -> bool:
    """True when stderr is connected to journald (systemd sets JOURNAL_STREAM)."""
    js = os.environ.get("JOURNAL_STREAM", "")
    try:
        dev, ino = (int(x) for x in js.split(":"))
        st = os.fstat(2)
    except (ValueError, OSError):
        return False
    return st.st_dev == dev and st.st_ino == ino


class LogBuffer(logging.Handler):
    """Keeps the last ``capacity`` records of this process."""

    def __init__(self, capacity: int = 2000):
        super().__init__(logging.DEBUG)
        self._records: collections.deque = collections.deque(maxlen=capacity)
        self._mutex = threading.Lock()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = record.getMessage()
            if record.exc_info:
                msg += "\n" + logging.Formatter().formatException(record.exc_info)
        except Exception:
            msg = str(record.msg)
        with self._mutex:
            self._records.append({"ts": record.created, "level": _level_of_record(record.levelno),
                                  "msg": f"{record.name}: {msg}"})

    def lines(self, n: int, level: str) -> list[dict]:
        floor = LEVELS.index(level)
        with self._mutex:
            recs = [r for r in self._records if LEVELS.index(r["level"]) >= floor]
        return recs[-n:]


def own_unit(cgroup: Path = Path("/proc/self/cgroup")) -> Optional[str]:
    """The system service this process runs in (e.g. odid.service), if any."""
    if not os.environ.get("INVOCATION_ID"):
        return None
    try:
        text = cgroup.read_text()
    except OSError:
        return None
    for line in text.splitlines():
        path = line.rpartition(":")[2]
        if path.startswith("/system.slice/"):
            name = path.rstrip("/").rpartition("/")[2]
            if name.endswith(".service"):
                return name
    return None


def _journalctl(unit: str, n: int, level: str) -> Optional[str]:
    if shutil.which("journalctl") is None:
        return None
    cmd = ["journalctl", "-u", unit, "-o", "json", "-n", str(n), "--no-pager",
           "-p", _JOURNAL_PRIORITY[level]]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout if r.returncode == 0 else None


def parse_journal(text: str) -> list[dict]:
    out = []
    for line in text.splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            continue
        msg = e.get("MESSAGE")
        if isinstance(msg, list):          # non-UTF-8 message: byte array
            try:
                msg = bytes(msg).decode("utf-8", errors="replace")
            except (TypeError, ValueError):
                msg = ""
        try:
            ts = int(e.get("__REALTIME_TIMESTAMP")) / 1e6
        except (TypeError, ValueError):
            ts = None
        out.append({"ts": ts, "level": level_of_priority(e.get("PRIORITY")),
                    "msg": _TIME_PREFIX.sub("", str(msg or ""), count=1)})
    return out


class LogSource:
    def __init__(self, buffer: Optional[LogBuffer] = None, unit: Optional[str] = None,
                 journal: Callable[[str, int, str], Optional[str]] = _journalctl):
        self._buffer = buffer
        self._unit = unit
        self._journal = journal

    def get(self, n: int = 500, level: str = "info") -> dict:
        if level not in LEVELS:
            raise ValueError(f"level must be one of {', '.join(LEVELS)}")
        n = max(1, min(int(n), MAX_LINES))
        if self._unit:
            text = self._journal(self._unit, n, level)
            if text is not None:
                return {"source": "journal", "unit": self._unit, "lines": parse_journal(text)}
        if self._buffer is not None:
            return {"source": "process", "unit": None, "lines": self._buffer.lines(n, level)}
        return {"source": None, "unit": None, "lines": []}
