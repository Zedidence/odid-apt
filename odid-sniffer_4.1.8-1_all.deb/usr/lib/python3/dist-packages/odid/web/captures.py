"""Capture sessions in the data directory (GET/DELETE /api/sessions).

A session is the files one run wrote with the same timestamp:
odid_capture_<ts>.pcap, odid_session_<ts>.jsonl, odid_locations_<ts>.csv,
plus odid_session_<ts>.lock while it is running. Files are only ever
reached by exact name from a fresh directory listing, never by a path
taken from the request, and are opened with O_NOFOLLOW.

IQ recordings (GET/DELETE /api/recordings) are SigMF pairs written by the
BladeRF flowgraphs into <data dir>/iq/:
odid_iq_<source>_<ts>_<MHz>.sigmf-data + .sigmf-meta. They download through
the same /api/sessions/<name>/download route.
"""

from __future__ import annotations

import json
import os
import re
import stat
from datetime import datetime
from pathlib import Path

FILE_RE = re.compile(r"^(odid_capture|odid_session|odid_locations)_(\d{8}_\d{6})\.(pcap|jsonl|csv|lock)$")
SESSION_ID_RE = re.compile(r"^\d{8}_\d{6}$")
KINDS = {"pcap": "pcap", "jsonl": "JSONL", "csv": "CSV"}
IQ_SUBDIR = "iq"
IQ_RE = re.compile(r"^(odid_iq_(bladerf-wifi|bladerf-bt)_(\d{8}_\d{6})_(\d{1,5}))"
                   r"\.(sigmf-data|sigmf-meta)$")
IQ_BASE_RE = re.compile(r"^odid_iq_(bladerf-wifi|bladerf-bt)_\d{8}_\d{6}_\d{1,5}$")
IQ_BYTES_PER_SAMPLE = 4          # ci16_le


class SessionBusy(Exception):
    """The session is still being written."""


def lock_held(path: Path) -> bool:
    """True if a live process holds this session's flock (odid.cli._SessionLock)."""
    import fcntl
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except OSError:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return True
    except OSError:
        return False
    finally:
        os.close(fd)
    return False


def _scan(data_dir: Path) -> dict[str, dict[str, os.stat_result]]:
    """session id -> {file name: lstat} for regular files matching FILE_RE."""
    out: dict[str, dict[str, os.stat_result]] = {}
    try:
        names = os.listdir(data_dir)
    except OSError:
        return out
    for name in names:
        m = FILE_RE.match(name)
        if not m:
            continue
        try:
            st = os.lstat(data_dir / name)
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode):
            out.setdefault(m.group(2), {})[name] = st
    return out


def list_sessions(data_dir) -> list[dict]:
    """Newest first: {"id", "start", "active", "size", "files": [...]}."""
    data_dir = Path(data_dir)
    sessions = []
    for sid, files in _scan(data_dir).items():
        lock = f"odid_session_{sid}.lock"
        active = lock in files and lock_held(data_dir / lock)
        items = sorted(({"name": n, "kind": KINDS[n.rsplit(".", 1)[1]], "size": st.st_size,
                         "mtime": st.st_mtime}
                        for n, st in files.items() if not n.endswith(".lock")),
                       key=lambda f: f["name"])
        if not items:
            continue
        try:
            start = datetime.strptime(sid, "%Y%m%d_%H%M%S").isoformat()
        except ValueError:
            start = None
        sessions.append({"id": sid, "start": start, "active": active,
                         "size": sum(f["size"] for f in items), "files": items})
    sessions.sort(key=lambda s: s["id"], reverse=True)
    return sessions


def open_file(data_dir, name: str) -> tuple[int, int]:
    """(fd, size) of a session or IQ recording file named exactly as in the
    listing. FileNotFoundError if it is not one."""
    data_dir = Path(data_dir)
    if isinstance(name, str) and IQ_RE.match(name):
        iq_dir = data_dir / IQ_SUBDIR
        if name not in _scan_iq(iq_dir).get(IQ_RE.match(name).group(1), {}):
            raise FileNotFoundError(name)
        path = iq_dir / name
    else:
        m = FILE_RE.match(name) if isinstance(name, str) else None
        if not m or name.endswith(".lock") or name not in _scan(data_dir).get(m.group(2), {}):
            raise FileNotFoundError(name)
        path = data_dir / name
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    st = os.fstat(fd)
    if not stat.S_ISREG(st.st_mode):
        os.close(fd)
        raise FileNotFoundError(name)
    return fd, st.st_size


def delete_session(data_dir, session_id: str) -> list[str]:
    """Delete every file of a finished session; returns the names removed."""
    data_dir = Path(data_dir)
    if not isinstance(session_id, str) or not SESSION_ID_RE.match(session_id):
        raise FileNotFoundError(session_id)
    files = _scan(data_dir).get(session_id)
    if not files:
        raise FileNotFoundError(session_id)
    lock = f"odid_session_{session_id}.lock"
    if lock in files and lock_held(data_dir / lock):
        raise SessionBusy(session_id)
    removed = []
    for name in sorted(files):
        try:
            os.unlink(data_dir / name)
            removed.append(name)
        except FileNotFoundError:
            pass
    return removed


def content_type(name: str) -> str:
    ext = name.rsplit(".", 1)[-1]
    return {"pcap": "application/vnd.tcpdump.pcap", "jsonl": "application/x-ndjson",
            "csv": "text/csv", "sigmf-meta": "application/json"}.get(ext, "application/octet-stream")


# ---------------------------------------------------------------------------
# IQ recordings
# ---------------------------------------------------------------------------

def _scan_iq(iq_dir: Path) -> dict[str, dict[str, os.stat_result]]:
    """recording base name -> {file name: lstat} for regular files matching IQ_RE."""
    out: dict[str, dict[str, os.stat_result]] = {}
    try:
        names = os.listdir(iq_dir)
    except OSError:
        return out
    for name in names:
        m = IQ_RE.match(name)
        if not m:
            continue
        try:
            st = os.lstat(iq_dir / name)
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode):
            out.setdefault(m.group(1), {})[name] = st
    return out


def _read_meta(path: Path) -> dict:
    """The few SigMF fields the dialog shows; {} if unreadable."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        with os.fdopen(fd, "rb") as f:
            meta = json.loads(f.read(64 * 1024))
        glob, cap = meta.get("global", {}), (meta.get("captures") or [{}])[0]
        return {"sample_rate": float(glob["core:sample_rate"]),
                "freq": cap.get("core:frequency"), "gain_db": glob.get("odid:gain_db")}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return {}


def list_recordings(data_dir, busy=frozenset()) -> list[dict]:
    """Newest first: {"id", "source", "start", "freq", "sample_rate",
    "gain_db", "seconds", "active", "size", "files": [...]}.

    ``busy``: base names still being written (SourceManager.recording_files()).
    """
    iq_dir = Path(data_dir) / IQ_SUBDIR
    out = []
    for base, files in _scan_iq(iq_dir).items():
        m = IQ_BASE_RE.match(base)
        meta_name, data_name = f"{base}.sigmf-meta", f"{base}.sigmf-data"
        meta = _read_meta(iq_dir / meta_name) if meta_name in files else {}
        size = sum(st.st_size for st in files.values())
        data_size = files[data_name].st_size if data_name in files else 0
        rate = meta.get("sample_rate")
        ts = base.split("_")[3] + "_" + base.split("_")[4]
        try:
            start = datetime.strptime(ts, "%Y%m%d_%H%M%S").isoformat() + "Z"
        except ValueError:
            start = None
        out.append({
            "id": base, "source": m.group(1) if m else None, "start": start,
            "freq": meta.get("freq"), "sample_rate": rate, "gain_db": meta.get("gain_db"),
            "seconds": round(data_size / IQ_BYTES_PER_SAMPLE / rate, 2) if rate else None,
            "active": base in busy, "size": size,
            "files": sorted(({"name": n, "kind": "SigMF " + n.rsplit(".", 1)[1].split("-")[1],
                              "size": st.st_size, "mtime": st.st_mtime}
                             for n, st in files.items()), key=lambda f: f["name"]),
        })
    out.sort(key=lambda r: (r["start"] or "", r["id"]), reverse=True)
    return out


def delete_recording(data_dir, base: str, busy=frozenset()) -> list[str]:
    """Delete both files of a finished IQ recording; returns the names removed."""
    if not isinstance(base, str) or not IQ_BASE_RE.match(base):
        raise FileNotFoundError(base)
    iq_dir = Path(data_dir) / IQ_SUBDIR
    files = _scan_iq(iq_dir).get(base)
    if not files:
        raise FileNotFoundError(base)
    if base in busy:
        raise SessionBusy(base)
    removed = []
    for name in sorted(files):
        try:
            os.unlink(iq_dir / name)
            removed.append(name)
        except FileNotFoundError:
            pass
    return removed

