"""Sensor health for the dashboard Status panel (GET /api/system, WS "system").

One ``SystemHealth.snapshot()`` gathers host vitals (temperature, Pi
throttling, load, memory, disk, uptime), versions and pending updates, clock
sync, Tailscale, attached radios and per-source rates, plus a list of alarms.
Cheap sysfs/proc reads run on every call; subprocess probes (apt-cache,
timedatectl, tailscale, vcgencmd) are cached and time-limited, so a snapshot
every few seconds stays cheap. Every probe degrades to None when its tool or
file is missing (a non-Pi host, no Tailscale, no apt).
"""

from __future__ import annotations

import collections
import json
import logging
import os
import platform
import re
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from odid import __version__

log = logging.getLogger(__name__)

PACKAGE = "odid-sniffer"
TEMP_WARN_C = 80.0
TEMP_ERROR_C = 85.0
NO_FRAMES_INFO_S = 30 * 60      # active source silent this long → info alarm
RATE_WINDOW_S = 60.0            # frames/s and overflow counts are over this window
# SDR input level (sdr_monitor): clipping above this share of samples → warn;
# a peak below LOW_LEVEL_DBFS for a whole window → the gain is probably too low.
# Measured 2026-10-14, BladeRF BT ch37 indoors: gain 0 → peak -40 dBFS and 7x
# fewer BLE packets than gain 20-40 (peak -21..-2); clipping from gain 50
# (0.4%, packets already dropping).
CLIP_WARN_PCT = 0.1
LOW_LEVEL_DBFS = -35.0

# vcgencmd get_throttled bits: (bit, text); +16 = "has occurred since boot"
_THROTTLE_BITS = (
    (0, "under-voltage"),
    (1, "ARM frequency capped"),
    (2, "throttled"),
    (3, "soft temperature limit"),
)


def _read(path: Path) -> Optional[str]:
    try:
        return path.read_text().strip()
    except (OSError, UnicodeDecodeError):
        return None


def _run(cmd: list[str], timeout: float = 3.0) -> Optional[str]:
    """stdout of ``cmd``, or None if it is missing, fails or times out."""
    if shutil.which(cmd[0]) is None:
        return None
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           env={**os.environ, "LC_ALL": "C"})
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout if r.returncode == 0 else None


def parse_throttled(text: Optional[str]) -> Optional[dict]:
    """``throttled=0x50005`` → {"raw", "now": [...], "since_boot": [...]}."""
    if not text or "=" not in text:
        return None
    try:
        v = int(text.strip().split("=", 1)[1], 16)
    except ValueError:
        return None
    return {"raw": hex(v),
            "now": [t for b, t in _THROTTLE_BITS if v & (1 << b)],
            "since_boot": [t for b, t in _THROTTLE_BITS if v & (1 << (b + 16))]}


def parse_apt_policy(text: Optional[str]) -> Optional[dict]:
    if not text:
        return None
    fields = {}
    for line in text.splitlines():
        k, _, v = line.strip().partition(":")
        if k in ("Installed", "Candidate"):
            fields[k.lower()] = v.strip()
    inst, cand = fields.get("installed"), fields.get("candidate")
    if not inst or inst == "(none)":
        return None            # not installed from a package (running from a checkout)
    return {"installed": inst, "candidate": cand,
            "available": bool(cand) and cand not in ("(none)", inst)}


def parse_tailscale(text: Optional[str]) -> Optional[dict]:
    if not text:
        return None
    try:
        d = json.loads(text)
    except ValueError:
        return None
    me = d.get("Self") or {}
    return {"state": d.get("BackendState"),
            "dns_name": (me.get("DNSName") or "").rstrip(".") or None,
            "ips": me.get("TailscaleIPs") or []}


def parse_cert_ips(text: Optional[str]) -> Optional[set[str]]:
    """IP addresses in ``openssl x509 -noout -ext subjectAltName`` output."""
    if text is None:
        return None
    return {m.strip() for m in re.findall(r"IP Address:([0-9A-Fa-f.:]+)", text)}


def parse_lan_ipv4s(text: Optional[str]) -> list[str]:
    """Global IPv4s from ``ip -j -4 addr show scope global``, without VPN
    interfaces (those are reached by name, e.g. through tailscale serve)."""
    try:
        ifaces = json.loads(text or "[]")
    except ValueError:
        return []
    return [a["local"] for ifc in ifaces
            if not str(ifc.get("ifname", "")).startswith(("tailscale", "wg", "tun"))
            for a in ifc.get("addr_info", []) if a.get("local")]


def serve_publishes(text: Optional[str], port: int) -> Optional[bool]:
    """Does ``tailscale serve status --json`` proxy to 127.0.0.1:<port>?
    None if unknown (tailscale missing or the output unreadable)."""
    if text is None:
        return None
    try:
        d = json.loads(text or "{}") or {}
    except ValueError:
        return None
    targets = [h.get("Proxy", "") for web in (d.get("Web") or {}).values()
               for h in (web.get("Handlers") or {}).values() if isinstance(h, dict)]
    return any(t.rstrip("/").endswith((f"127.0.0.1:{port}", f"localhost:{port}"))
               for t in targets)


class _Cache:
    """Per-key TTL cache; slow probes run outside the lock."""

    def __init__(self, clock: Callable[[], float]):
        self._clock = clock
        self._values: dict[str, tuple[float, Any]] = {}

    def get(self, key: str, ttl: float, fn: Callable[[], Any]) -> Any:
        hit = self._values.get(key)
        now = self._clock()
        if hit is not None and now - hit[0] < ttl:
            return hit[1]
        try:
            value = fn()
        except Exception:
            log.debug("health probe %s failed", key, exc_info=True)
            value = None
        self._values[key] = (now, value)
        return value


class SystemHealth:
    """Collects health snapshots. ``sources`` returns SourceManager.get_status();
    ``disk_guard`` returns the running odid.cli._DiskGuard (or None)."""

    def __init__(self, data_dir: str, sources: Optional[Callable[[], list]] = None,
                 disk_guard: Optional[Callable[[], Any]] = None,
                 sys_root: Path = Path("/sys"), proc_root: Path = Path("/proc"),
                 etc_root: Path = Path("/etc"),
                 run: Callable[..., Optional[str]] = _run,
                 clock: Callable[[], float] = time.monotonic,
                 tls_cert: Optional[Path] = None, serve_port: Optional[int] = None):
        self.data_dir = data_dir
        # Remote access checks: the LAN HTTPS certificate, and the port that
        # "tailscale serve" should publish (None = not using tailscale serve)
        self._tls_cert = tls_cert
        self._serve_port = serve_port
        self._sources = sources
        self._disk_guard = disk_guard
        self._sys, self._proc, self._etc = sys_root, proc_root, etc_root
        self._runcmd = run
        self._clock = clock
        self._cache = _Cache(clock)
        self._lock = threading.Lock()
        # source id -> deque[(t, frame_count, overflows)] over RATE_WINDOW_S
        self._samples: dict[str, collections.deque] = {}
        self._last_frame: dict[str, float] = {}   # source id -> time frames last grew
        self._prev_status: dict[str, Optional[str]] = {}

    # -- probes -----------------------------------------------------------

    def _cpu_temp(self) -> Optional[float]:
        raw = _read(self._sys / "class/thermal/thermal_zone0/temp")
        try:
            return round(int(raw) / 1000.0, 1) if raw else None
        except ValueError:
            return None

    def _throttled(self) -> Optional[dict]:
        t = parse_throttled(self._runcmd(["vcgencmd", "get_throttled"]))
        if t is not None:
            return t
        # No vcgencmd access: the rpi_volt hwmon alarm still shows under-voltage
        try:
            hwmons = list((self._sys / "class/hwmon").iterdir())
        except OSError:
            return None
        for h in hwmons:
            if _read(h / "name") == "rpi_volt":
                alarm = _read(h / "in0_lcrit_alarm")
                if alarm in ("0", "1"):
                    return {"raw": None, "now": ["under-voltage"] if alarm == "1" else [],
                            "since_boot": None}
        return None

    def _meminfo(self) -> dict:
        out = {}
        for line in (_read(self._proc / "meminfo") or "").splitlines():
            k, _, v = line.partition(":")
            if k in ("MemTotal", "MemAvailable"):
                try:
                    out[k] = int(v.split()[0]) * 1024
                except (ValueError, IndexError):
                    pass
        return {"total": out.get("MemTotal"), "available": out.get("MemAvailable")}

    def _uptime(self) -> Optional[float]:
        raw = _read(self._proc / "uptime")
        try:
            return float(raw.split()[0]) if raw else None
        except ValueError:
            return None

    def _os_name(self) -> Optional[str]:
        for line in (_read(self._etc / "os-release") or "").splitlines():
            if line.startswith("PRETTY_NAME="):
                return line.split("=", 1)[1].strip().strip('"')
        return None

    def _time_sync(self) -> Optional[bool]:
        out = self._runcmd(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
        return None if out is None else out.strip() == "yes"

    def _hardware(self) -> dict:
        from odid.provision import detect
        hw = detect(net=self._sys / "class/net", usb=self._sys / "bus/usb/devices",
                    bt=self._sys / "class/bluetooth")
        return {"bladerf": hw.bladerf, "wifi": hw.wifi, "bt": hw.bt_adapters}

    def _remote_access(self) -> dict:
        out: dict = {}
        if self._tls_cert is not None:
            cert_ips = parse_cert_ips(self._runcmd(
                ["openssl", "x509", "-noout", "-ext", "subjectAltName",
                 "-in", str(self._tls_cert)]))
            if cert_ips is not None:
                lan = parse_lan_ipv4s(self._runcmd(
                    ["ip", "-j", "-4", "addr", "show", "scope", "global"]))
                out["cert_missing_ips"] = [ip for ip in lan if ip not in cert_ips]
        if self._serve_port is not None:
            out["serve_ok"] = serve_publishes(
                self._runcmd(["tailscale", "serve", "status", "--json"]), self._serve_port)
        return out

    def _disk(self) -> dict:
        d: dict[str, Any] = {"path": self.data_dir}
        try:
            u = shutil.disk_usage(self.data_dir)
            d.update(total=u.total, free=u.free)
        except OSError:
            d.update(total=None, free=None)
        guard = self._disk_guard() if self._disk_guard else None
        d["min_free"] = guard.min_free if guard is not None else None
        d["paused"] = bool(guard.low) if guard is not None else False
        return d

    def _source_stats(self, now: float) -> list[dict]:
        try:
            status = self._sources() if self._sources else []
        except Exception:
            log.exception("SourceManager.get_status() failed")
            status = []
        out = []
        seen = set()
        for s in status:
            sid = s.get("id")
            seen.add(sid)
            frames = int(s.get("frame_count") or 0)
            over = int(s.get("overflows") or 0)
            dq = self._samples.setdefault(sid, collections.deque())
            active = s.get("status") == "active"
            became_active = active and self._prev_status.get(sid) != "active"
            self._prev_status[sid] = s.get("status")
            if dq and (became_active or frames < dq[-1][1] or over < dq[-1][2]):
                dq.clear()          # rates start now (just started, or counters reset)
            if not dq or frames != dq[-1][1] or became_active:
                self._last_frame[sid] = now
            dq.append((now, frames, over))
            # keep one sample at least RATE_WINDOW_S old as the baseline
            while len(dq) > 2 and now - dq[1][0] >= RATE_WINDOW_S:
                dq.popleft()
            t0, f0, o0 = dq[0]
            dt = now - t0
            out.append({
                "id": sid, "label": s.get("label"), "status": s.get("status"),
                "error": s.get("error") or "", "frame_count": frames,
                "fps": round((frames - f0) / dt, 2) if dt > 0 and active else None,
                "overflows": over, "recent_overflows": over - o0,
                "idle_s": round(now - self._last_frame.get(sid, now)) if active else None,
                "level": _level(s.get("sdr")) if active else None,
            })
        for sid in set(self._samples) - seen:
            self._samples.pop(sid, None)
            self._last_frame.pop(sid, None)
            self._prev_status.pop(sid, None)
        return out

    # -- snapshot ---------------------------------------------------------

    def snapshot(self) -> dict:
        c = self._cache
        throttled = c.get("throttled", 10, self._throttled)
        snap = {
            "time": time.time(),
            "host": {
                "hostname": socket.gethostname(),
                "uptime_s": self._uptime(),
                "load": list(os.getloadavg()) if hasattr(os, "getloadavg") else None,
                "cpus": os.cpu_count(),
                "memory": self._meminfo(),
                "cpu_temp_c": self._cpu_temp(),
                "throttled": throttled,
            },
            "disk": self._disk(),
            "versions": {
                "app": __version__,
                "os": c.get("os", 3600, self._os_name),
                "kernel": platform.release(),
                "python": platform.python_version(),
                "update": c.get("apt", 600, lambda: parse_apt_policy(
                    self._runcmd(["apt-cache", "policy", PACKAGE]))),
            },
            "time_sync": c.get("ntp", 60, self._time_sync),
            "tailscale": c.get("tailscale", 30, lambda: parse_tailscale(
                self._runcmd(["tailscale", "status", "--json", "--peers=false"]))),
            "hardware": c.get("hardware", 15, self._hardware),
            "remote_access": c.get("remote", 120, self._remote_access) or {},
        }
        with self._lock:
            snap["sources"] = self._source_stats(self._clock())
        snap["alarms"] = alarms(snap)
        return snap


def _mb(n: Optional[int]) -> str:
    return "?" if n is None else f"{n // 2**20} MB"


def _level(sdr) -> Optional[dict]:
    """The SDR input level from a source's ``sdr`` status, or None."""
    if not isinstance(sdr, dict) or not isinstance(sdr.get("peak_dbfs"), (int, float)):
        return None
    return {k: sdr.get(k) for k in ("peak_dbfs", "mean_dbfs", "noise_dbfs", "clip_pct",
                                    "gain_db")}


def alarms(s: dict) -> list[dict]:
    """Problems worth showing, worst first: {"level": error|warn|info, "text"}."""
    out: list[dict] = []

    def add(level: str, text: str) -> None:
        out.append({"level": level, "text": text})

    host = s["host"]
    temp = host.get("cpu_temp_c")
    if temp is not None and temp >= TEMP_ERROR_C:
        add("error", f"CPU at {temp:.0f} °C: the Pi is overheating")
    elif temp is not None and temp >= TEMP_WARN_C:
        add("warn", f"CPU at {temp:.0f} °C")
    thr = host.get("throttled") or {}
    now = thr.get("now") or []
    if "under-voltage" in now:
        add("error", "Under-voltage now. Check the power supply")
    elif "under-voltage" in (thr.get("since_boot") or []):
        add("warn", "Under-voltage occurred since boot. Check the power supply")
    slowed = [t for t in now if t != "under-voltage"]
    if slowed:
        add("warn", "CPU " + ", ".join(slowed))

    disk = s["disk"]
    if disk.get("paused"):
        add("error", f"Disk nearly full ({_mb(disk.get('free'))} free): pcap/JSONL/CSV "
                     "and the database frame log are paused")
    elif disk.get("min_free") and disk.get("free") is not None \
            and disk["free"] < 2 * disk["min_free"]:
        add("warn", f"Disk space low ({_mb(disk['free'])} free)")
    mem = host.get("memory") or {}
    if mem.get("total") and mem.get("available") is not None \
            and mem["available"] < 0.05 * mem["total"]:
        add("warn", f"Memory low ({_mb(mem['available'])} available)")

    if s.get("time_sync") is False:
        add("warn", "Clock not synchronised (NTP): timestamps may be wrong")
    ts = s.get("tailscale")
    if ts and ts.get("state") not in (None, "Running"):
        add("warn", f"Tailscale is {ts['state']}: remote access may be down")
    remote = s.get("remote_access") or {}
    if remote.get("serve_ok") is False:
        add("warn", "tailscale serve is not publishing the dashboard: remote access over "
                    "the tailnet is down. Fix: sudo odid provision --tailscale")
    if remote.get("cert_missing_ips"):
        ips = ", ".join(remote["cert_missing_ips"])
        add("warn", f"The HTTPS certificate does not cover {ips}: browsers will warn on "
                    "that address. Fix: sudo odid tls --regenerate")

    for src in s.get("sources") or []:
        label = src.get("label") or src.get("id")
        if src.get("status") == "error":
            add("error", f"{label}: {src.get('error') or 'failed'}")
        if src.get("recent_overflows"):
            add("warn", f"{label}: {src['recent_overflows']} SDR overflows in the last "
                        "minute (CPU or USB not keeping up)")
        if src.get("idle_s") is not None and src["idle_s"] >= NO_FRAMES_INFO_S:
            add("info", f"{label}: no Remote ID frames for {src['idle_s'] // 60} min")
        lvl = src.get("level") or {}
        gain = f" (now {lvl['gain_db']} dB)" if isinstance(lvl.get("gain_db"), int) else ""
        if (lvl.get("clip_pct") or 0) >= CLIP_WARN_PCT:
            add("warn", f"{label}: input clipping ({lvl['clip_pct']:.2g}% of samples): "
                        f"lower the gain{gain}")
        elif isinstance(lvl.get("peak_dbfs"), (int, float)) and lvl["peak_dbfs"] < LOW_LEVEL_DBFS:
            add("info", f"{label}: input level very low (peak {lvl['peak_dbfs']:.0f} dBFS): "
                        f"the gain{gain} may be too low")
    running = {src.get("id") for src in s.get("sources") or []
               if src.get("status") in ("starting", "active")}
    if {"bladerf-wifi", "wifi-dongle"} <= running:
        add("info", "BladeRF WiFi and the WiFi dongle are both running: BladeRF WiFi uses "
                    "about 2.5 CPU cores and can't decode 802.11b beacons, which the dongle "
                    "already covers. Consider stopping it or using the BladeRF for Bluetooth.")

    upd = s["versions"].get("update")
    if upd and upd.get("available"):
        add("info", f"Update available: {upd['installed']} → {upd['candidate']}")

    rank = {"error": 0, "warn": 1, "info": 2}
    out.sort(key=lambda a: rank[a["level"]])
    return out
