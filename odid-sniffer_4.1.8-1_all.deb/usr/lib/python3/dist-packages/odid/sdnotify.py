"""Minimal systemd notify protocol (``Type=notify`` + ``WatchdogSec=``).

No dependency on python-systemd: messages are datagrams sent to the Unix
socket named in ``$NOTIFY_SOCKET``. Every function is a silent no-op when the
process is not running under systemd.
"""

from __future__ import annotations

import logging
import os
import socket
import threading
from typing import Callable, Optional

log = logging.getLogger(__name__)


def notify(message: str) -> bool:
    """Send ``message`` (e.g. ``"READY=1"``) to systemd. True if it was sent."""
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return False
    if addr.startswith("@"):            # abstract namespace socket
        addr = "\0" + addr[1:]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM | socket.SOCK_CLOEXEC) as s:
            s.connect(addr)
            s.sendall(message.encode())
        return True
    except OSError as exc:
        log.debug("sd_notify(%r) failed: %s", message, exc)
        return False


def watchdog_interval() -> Optional[float]:
    """Seconds between keep-alive pings systemd expects, or None if disabled."""
    usec = os.environ.get("WATCHDOG_USEC")
    pid = os.environ.get("WATCHDOG_PID")
    if not usec or (pid and pid != str(os.getpid())):
        return None
    try:
        seconds = int(usec) / 1_000_000
    except ValueError:
        return None
    return seconds / 2 if seconds > 0 else None


class Watchdog:
    """Ping systemd's watchdog while ``healthy()`` keeps returning True.

    When a health check fails the pings stop, so systemd restarts the
    service after ``WatchdogSec``, e.g. if the writer thread has died or the
    web event loop is wedged.
    """

    def __init__(self, healthy: Callable[[], bool]) -> None:
        self._healthy = healthy
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> bool:
        interval = watchdog_interval()
        if interval is None:
            return False
        self._thread = threading.Thread(target=self._run, args=(interval,),
                                        daemon=True, name="odid-watchdog")
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def _run(self, interval: float) -> None:
        while not self._stop.wait(interval):
            try:
                ok = self._healthy()
            except Exception:
                log.exception("Watchdog health check raised")
                ok = False
            if ok:
                notify("WATCHDOG=1")
            else:
                log.error("Health check failed, not pinging the systemd watchdog")
