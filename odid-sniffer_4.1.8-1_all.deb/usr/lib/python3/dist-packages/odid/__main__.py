"""Entry point for python -m odid."""

import sys
from odid.cli import main

sys.exit(main())
