"""OpenDroneID Sniffer & Decoder - ASTM F3411 compliant."""

__version__ = "4.1.8"
