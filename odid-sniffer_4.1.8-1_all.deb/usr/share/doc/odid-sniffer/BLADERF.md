# BladeRF SDR receivers

A Nuand bladeRF 2.0 can receive Remote ID on **WiFi** (802.11 OFDM beacons
and NAN action frames) or **Bluetooth LE** (BT4 legacy advertising) through
GNU Radio flowgraphs. Both work on real hardware: a DJI drone was decoded on
WiFi channel 6, and the BLE demodulator decodes ambient adverts at ~83
CRC-valid packets/s. **One BladeRF runs one protocol at a time.**

Limits to know up front:
- On a Pi 5 the WiFi receiver is CPU-bound and drops samples (see
  [Limitations](#limitations)).
- It cannot hear 802.11b **DSSS** beacons, which many 2.4 GHz drones use. A
  monitor-mode WiFi dongle can.
- BT5 extended / Long Range (Coded PHY) advertising is not supported.

## Requirements

- bladeRF 2.0 (micro) on USB 3
- GNU Radio 3.10+ with gr-osmosdr, and gr-ieee802-11 for WiFi
- `pyzmq` (in `.[all]`)
- From a source install, the venv must be created with
  `--system-site-packages`, so the flowgraphs (run under `venv/bin/python`)
  can import GNU Radio from apt.
- The packaged service needs no extra setup: the udev rule gives group
  `plugdev` access to the BladeRF.

## Using it

**From the dashboard (recommended).** `odid serve` launches the flowgraph for
you. In the Sources tab, start **BladeRF WiFi** or **BladeRF BT**. Source
options:

| Option | Sources | Default | Meaning |
|---|---|---|---|
| `gain` | both | 40 | RX gain, 0-71 dB. Can be changed live on a running source and is saved |
| `channel` | WiFi | 6 | 1-14; with `hop` it is the starting channel |
| `hop` | WiFi | false | Hop channels (3 s dwell) instead of staying on one |
| `channel` | BT | hop | 37, 38 or 39 to stay on one advertising channel (needed for IQ recording) |
| `monitor` | both | WiFi off, BT on | Signal monitor (spectrum, level meter) |

Starting the other BladeRF source while one runs is refused (409, "is using
the BladeRF device"). The `bladerf-dual` source is disabled: the bladeRF
2.0's two RX channels share one local oscillator, so WiFi and BT cannot be
tuned independently. For both at once, use two SDRs, or the BladeRF for WiFi
plus the Pi's built-in Bluetooth.

**By hand (two terminals).**

```bash
# WiFi (802.11 OFDM)
python flowgraphs/odid_wifi_bladerf.py --gain 40 --no-hop --freq 2437   # or --dwell 3.0 to hop
odid bladerf --zmq tcp://127.0.0.1:5555 --web

# Bluetooth LE
python flowgraphs/odid_bt_bladerf.py --gain 40 --channel 37
odid bladerf --zmq-bt tcp://127.0.0.1:5556 --web

# WiFi + BT at once needs two SDRs
python flowgraphs/odid_wifi_bladerf.py --device <serial-1>
python flowgraphs/odid_bt_bladerf.py   --device <serial-2>
odid bladerf --zmq tcp://127.0.0.1:5555 --zmq-bt tcp://127.0.0.1:5556 --web
```

`odid bladerf` needs no `sudo`: it reads from ZMQ, not raw sockets. Useful
flowgraph options: `--device SERIAL` (hex) picks a BladeRF, `--stats SECS`
prints receiver counters (`frames`/`odid` for WiFi;
`aa_hits`/`crc_ok`/`crc_fail`/`odid` for BLE), `--iq-file` replays a
recording, `--sync-threshold` (WiFi, default 0.56) tunes OFDM detection.

## How it works

```
BladeRF (one protocol per BladeRF)
      │
      ▼
GNU Radio flowgraph  (odid/flowgraphs/odid_wifi_bladerf.py  or  odid_bt_bladerf.py)
  ├─ WiFi:  osmosdr source → gr-ieee802-11 RX (wifi_phy_hier layout) → bare 802.11 MAC frame
  └─ BT LE: osmosdr source → GFSK demod → M&M clock recovery → slicer
            → ble_dsp.BLEFramer (AA search, dewhiten, CRC-24) → ODID service data
      │
      │  ZMQ PUSH, bound to tcp://127.0.0.1:5555 (WiFi) / :5556 (BT)
      │  JSON: {"source":"wifi"|"bt", "mac":"...", "rssi":..., "snr":..., "channel":6, "payload":"<hex>"}
      ▼
BladeRFCapture.sniff()  ← ZMQ PULL
      │  Dot11(payload) → extract_odid()     or     parse_odid_service_data()
      ▼
ODIDFrame → tracker / writers / TUI / web / DB (same as every other source)
```

**WiFi.** The receive chain follows gr-ieee802-11's `wifi_phy_hier.grc`:
autocorrelation into `sync_short`, `sync_long`, FFT(64), `frame_equalizer`,
`decode_mac`. Only frames carrying the ODID beacon vendor IE (FA:0B:BC) or
NAN (50:6F:9A:13) are forwarded. Frames carry the tuned `channel` and the
equalizer's SNR as `snr_db`; there is no calibrated RSSI, so `signal_dbm`
stays empty. Simulation test: an ODID beacon modulated with gr-ieee802-11's
own OFDM TX chain decodes byte-exact, also with phase rotation and noise.

**Bluetooth LE.** Standard BLE whitening (`lfsr = ch | 0x40`) and the
reflected CRC-24 (preset 0x555555), checked against a spec-literal LFSR, the
nRF24 variant, the published check value (`"123456789"` → 0xC25A56) and the
channel 37 keystream prefix. A vectorised access-address search feeds a
streaming framer that handles packets spanning work() calls. Default hop
dwell is 0.5 s. No RSSI.

**Process handling.** ZMQ binds to 127.0.0.1 only. The manager starts
flowgraphs with `PR_SET_PDEATHSIG=SIGTERM`, so a crashed `odid serve` never
leaves the BladeRF claimed. A flowgraph that dies moves its source to ERROR.
A failed channel hop is logged and hopping continues; after 5 failures in a
row the flowgraph exits so the source shows an error. Unplugging the BladeRF
moves the source to ERROR within ~9 s without affecting other sources.

## Signal monitor, IQ recording, live gain

Ported from the Spectrum_Analyzer project (`odid/flowgraphs/sdr_monitor.py`,
dashboard `odid/web/static/sdr.js`).

```
osmosdr source ─┬─ receiver
                └─ SdrTap ─┬─ stream_to_vector(256) ─ keep_one_in_n ─ SpectrumProbe (numpy FFT)
                           └─ copy (valve, off) ─ complex_to_interleaved_short ─ file_sink
```

- **Monitor:** about 0.5 MS/s of the stream is analysed. Every 0.25 s it
  sends the average and peak-hold spectrum (256 bins, dBFS), peak level,
  mean power, noise floor and clipped-sample share. The source card shows a
  level meter; the **Spectrum** dialog shows a trace and waterfall. Status
  alarms: clipping ≥ 0.1% → "lower the gain"; peak below −35 dBFS over 10 s
  → "gain may be too low". Off by default for WiFi, where it costs ~6% of
  the CPU-bound receiver's throughput; BT cost is +13% of a core.
- **IQ recording:** SigMF `ci16_le` (full scale 2048) in `<data dir>/iq/`,
  2-30 s from the source card (up to 60 s via the API). Needs a fixed
  channel. 20 MS/s WiFi is 80 MB/s, too fast for most SD cards. Recordings
  share the receiver's sample drops, so the recorder reports `dropped_pct`
  (also in the SigMF meta). BT recordings are complete. Listed, downloaded
  and deleted in the Captures dialog.
- **Replay / offline tuning:** `--iq-file REC.sigmf-meta [--realtime]` runs
  a recording through the normal receiver.
- **Live gain:** applied through gr-osmosdr without a restart and saved as
  the source's start config.
- **Control path:** SourceManager starts flowgraphs with `--control-stdin`
  and writes JSON lines (`record`, `record_stop`, `gain`); results come back
  on the ZMQ socket.
- **API:** `POST /api/sources/{record,record_stop,gain}`, `GET
  /api/recordings`, `DELETE /api/recordings/<id>` (admin); WebSocket message
  `sdr_monitor`.

## Limitations

- **WiFi is CPU-bound on a Pi 5.** The stock gr-ieee802-11 receiver keeps
  about 11-14 of 20 Msps (~2.5 cores) and drops the rest; the dashboard
  shows the drop rate. The cause and a prototype fix that reaches ~20 Msps
  are in [STATUS.md](STATUS.md#bladerf-wifi-drops-samples-cpu-bound).
- **No 802.11b DSSS.** gr-ieee802-11 only demodulates OFDM. Many 2.4 GHz
  ODID transmitters send beacons at 1 Mb/s DSSS, which the BladeRF path
  cannot see. A DSSS receiver is deferred (real DSP work, and it needs a
  known DSSS transmitter to validate). Use a monitor-mode dongle for those.
- **One protocol per BladeRF** (shared LO, see above).
- **No calibrated RSSI** on either path.
- **BLE:** legacy advertising only; a real frequency offset may still need
  an AFC/DC-offset block (not seen on ambient adverts).

## Hardware results

Raspberry Pi 5 + bladeRF 2.0 micro (FW 2.6.0, FPGA 0.16.0, USB 3).

**With a live drone** (2026-10-12; DJI, UAS ID `1581F8LQC259J00258FJ`,
WiFi beacons at OFDM 6 Mb/s on ch 6, no Bluetooth Remote ID). Reference: the
RT5372 dongle on ch 6 in the same `odid serve`.

| Check | Result |
|---|---|
| WiFi ODID decode | ✅ BladeRF and dongle decode identical fields; BladeRF `snr_db` 5.5-20.9 (avg 14.2), dongle −47…−39 dBm |
| Gain vs. the drone (BladeRF ÷ dongle frames, 30 s each) | 20 dB 1.41 · 30 dB 1.17 · **40 dB 1.63** · 50 dB 1.52 · 60 dB 0.47 (overload). Default 40 |
| Hopping (3 s dwell, 70 s) | ✅ ratio 0.089 vs. the dongle (≈ 1/11 expected), all frames tagged ch 6 |
| Switching | ✅ six WiFi/BT stop→start cycles, all clean |
| Unplug while active | ✅ source → ERROR ~9 s later, nothing left running, other sources unaffected |

**Ambient traffic, no transmitter** (2026-10-12 and 2026-10-14):
- WiFi OFDM: 2-20 frames/s from nearby networks; all gains 20-60 work.
- BLE ch 37: ~83 CRC-valid adverts/s, ~72% of access-address hits pass CRC.
  Gain sweep: 20 dB 667 · 30: 809 · 40: 711 · 50: 747 · 60: 58 (saturates).
  Live sweep: peak −40/−21/−8/−2/0 dBFS at gain 0/20/30/40/50, clipping from
  50 dB. Best 20-40; the monitor alarm thresholds come from this.
- BLE uses ~0.4-0.6 core with no overflows.
- WiFi throughput, idle Pi: 10.9-11.9 MS/s without the monitor (~2.6 cores),
  9.6-11.6 with it. It depends on channel traffic (13.7 MS/s on a quieter
  day).
- End to end: start bladerf-bt ch 37 → live gain 30 → 20 → 5 s recording →
  download → `--iq-file` replay decoded 271 BLE packets, matching the live
  rate.

`bench_sdr_tap.py` (repo root) is the benchmark used for the monitor cost.

## Still to verify on hardware

- [ ] A real **BT** Remote ID transmitter, on fixed 37/38/39 and hopping;
      the hop dwell catches adverts at its advertising interval.
- [ ] A **DSSS-only** WiFi transmitter is *not* decoded by the BladeRF but
      is by a dongle on the same channel (confirms the limitation).
- [ ] **Two SDRs:** `--device <serial>` picks the right unit; WiFi and BT
      run at the same time.
- [ ] A 10-minute WiFi soak with the drop monitor (after the gr-ieee802-11
      speedup).
- [ ] Record and replay a real ODID transmitter.

## Tests

| File | What |
|---|---|
| `tests/test_capture_bladerf.py` | ZMQ bridge: bare Dot11, RadioTap fallback, rssi vs `snr_db`, channel, timestamps, malformed messages |
| `tests/test_ble_dsp.py` | Whitening, CRC-24 and framer against independent references and published vectors |
| `tests/test_flowgraphs.py` | GNU Radio loopbacks for WiFi and BT, incl. record → SigMF → `--iq-file` replay (skipped without GNU Radio / gr-ieee802-11) |
| `tests/test_sdr_monitor.py` | Monitor DSP, SigMF, recorder, stdin control, publisher |
| `tests/test_manager.py` | SourceManager lifecycle with a fake flowgraph, PDEATHSIG, config validation |
