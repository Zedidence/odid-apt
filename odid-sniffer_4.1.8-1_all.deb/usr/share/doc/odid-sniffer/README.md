# OpenDroneID Sniffer & Decoder

A Remote ID (OpenDroneID) sniffer, decoder and tracker for Raspberry Pi and
Linux. It captures WiFi NAN action frames, WiFi beacons and Bluetooth
advertising broadcast by drones on 2.4 GHz and decodes them per
**ASTM F3411-19 / F3411-22** and **ASD-STAN prEN 4709-002**.

There are two ways to run it:

- **As an unattended sensor on a Raspberry Pi:** install the `.deb` and
  manage it from a browser, over the LAN or Tailscale, with sign-in. See
  **[DEPLOY.md](DEPLOY.md)**.
- **From source** on a Pi or Linux PC, for the command-line tools and
  development: the rest of this file.

| Document | What's in it |
|---|---|
| [DEPLOY.md](DEPLOY.md) | The Pi package: install, provision, remote access, operation |
| [BLADERF.md](BLADERF.md) | BladeRF SDR receivers: setup, how they work, hardware results |
| [STATUS.md](STATUS.md) | Where the project stands, open work, roadmap |
| [docs/AUDIT_2026-10-13.md](docs/AUDIT_2026-10-13.md) | Code audit findings (some still open) |

---

## Features

- **Capture:** WiFi NAN action frames and beacons with a monitor-mode
  adapter; Bluetooth Remote ID (BT4 legacy + BT5 Long Range) via `bleak`;
  BladeRF SDR via GNU Radio ([BLADERF.md](BLADERF.md)).
- **Decoding:** every ASTM F3411 message: Basic ID, Location/Vector, Self-ID,
  System, Operator ID, Message Pack, Auth.
- **Web dashboard** (`odid serve`): live map with drone and operator
  markers and flight paths; start and stop radio sources from the browser;
  settings, health, logs, captures and accounts; KML/GPX export; works on a
  phone.
- **Console and TUI** output (`--tui`): colour-coded, live table of drones.
- **Tracking:** per-drone state, signal min/max/avg, distance from your
  position (`--lat`/`--lon`), stale-drone eviction (`--drone-ttl`).
- **Alerts:** anomaly flags (null-island GPS, implausible speed or altitude,
  missing Basic ID), watchlist of UAS/Operator IDs, webhook POSTs.
- **Logging:** SQLite database, JSONL, CSV and pcap (each optional);
  `odid replay`, `odid query` and `odid export` work on what was saved.
- **Config file** with persistent defaults, and an `odid init` setup wizard.

## Hardware

| Item | Notes |
|---|---|
| Raspberry Pi 4/5 or a Linux PC | Pi 5 recommended |
| USB WiFi adapter with monitor mode | Ralink RT5372, Atheros AR9271, Realtek RTL8812AU |
| Bluetooth adapter (optional) | The Pi's built-in one works; no WiFi adapter needed for Bluetooth only |
| Nuand bladeRF 2.0 (optional) | Plus GNU Radio 3.10+, gr-osmosdr, gr-ieee802-11; see [BLADERF.md](BLADERF.md) |

---

## Install from source

```bash
git clone https://github.com/Zedidence/ODID_Sniffer
cd ODID_Sniffer
sudo bash install.sh
```

`install.sh` installs the system packages, creates the venv, links
`/usr/local/bin/odid`, optionally installs a systemd service, and runs the
`odid init` wizard.

**By hand.** Modern Raspberry Pi OS and Debian block `pip install` outside a
virtual environment:

```bash
sudo bash setup.sh                                   # system packages (iw, aircrack-ng, libpcap…)

# --system-site-packages lets the venv see GNU Radio / gr-osmosdr, which only
# come from apt (needed by the BladeRF flowgraphs, which run under venv/bin/python).
python3 -m venv --system-site-packages venv
venv/bin/pip install -e '.[all]'                     # rich, aiohttp, bleak, pyzmq
```

The commands below are written as `odid`. With a by-hand install, use
`venv/bin/odid` instead, and `sudo venv/bin/odid` for capture: `sudo`
doesn't see an activated venv, but explicit paths always work.

## Quick start

1. **Find your adapter.** It is usually `wlan1` or `wlan2`; `wlan0` is the
   Pi's built-in WiFi, which can't do monitor mode.
   ```bash
   odid interfaces
   ```
2. **Put it in monitor mode.**
   ```bash
   sudo odid setup wlan1
   iw dev wlan1 info            # should show: type monitor
   ```
   If NetworkManager or wpa_supplicant fight over the adapter, run
   `sudo airmon-ng check kill` first.
3. **Start the dashboard** and open http://localhost:8080/.
   ```bash
   sudo odid serve --lat 51.5074 --lon -0.1278
   ```
   Start any mix of sources (WiFi dongle, built-in Bluetooth, BladeRF) in
   the Sources tab without restarting. A WiFi dongle is switched to monitor
   mode for you (and back on stop) unless it is connected to a network. Your
   position is optional; it adds distances and a marker on the map.

**Or one source, straight in the terminal.** Press Ctrl+C to stop; session
files go to `logs/`.

```bash
sudo odid sniff wlan1                 # scrolling console (no extra deps)
sudo odid sniff wlan1 --tui           # live table of all drones
sudo odid sniff wlan1 --web           # live map on http://localhost:8080/
sudo odid scan wlan1 --tui            # hop all 2.4 GHz channels if ch 6 is quiet
sudo odid btsniff --tui               # Bluetooth only, no WiFi adapter needed
```

**Afterwards, without hardware or sudo:**

```bash
odid replay logs/odid_capture_20260323_120000.pcap --tui
odid query --since 1h                 # or --uas-id ABC123, --anomalies
odid export --format kml --out tracks.kml
```

### What the console output means

```
================================================================================
[14:23:07.412] ODID Frame [NAN Action] ch6 [NEW]
  MAC: aa:bb:cc:dd:ee:ff  Signal: -62 dBm  Counter: 3
  UAS ID: 1ABC234DEF56789  Frames: 1  Duration: 0s
  Distance: 47m
--------------------------------------------------------------------------------
  [Basic ID]
    ID Type  : Serial Number (ANSI/CTA-2063-A)
    UA Type  : Multirotor
    UAS ID   : 1ABC234DEF56789
  [Location]
    Status   : Airborne
    Lat/Lon  : 51.5074100, -0.1278200
    Alt MSL  : 42.0m
    Speed H  : 3.50 m/s
================================================================================
```

- **[NEW]**: first time this MAC has been seen this session.
- **[WARN]**: anomaly detected (see [Anomaly detection](#anomaly-detection)).
- Signal colours: green ≥ −60 dBm · yellow −60 to −75 · red < −75.

---

## Config file

Create `~/.config/odid/config.toml` (or run `odid init`) to persist defaults:

```toml
[observer]
lat = 51.5074
lon = -0.1278

[capture]
interface = "wlan1"        # used when sniff/scan get no interface argument
channels = [1, 6, 11]      # scan channel list
dwell = 5.0                # scan seconds per channel
drone_ttl = 300
max_drones = 2000          # most drones tracked at once; the least recently heard goes (0 = no limit)

[output]
log_dir = "logs"
web = false
web_port = 8080
web_host = "127.0.0.1"
allowed_hosts = ["sniffer.lan"]   # extra names the dashboard answers to (local IPs/hostname always allowed)
web_tls = false            # HTTPS listener for the network (needs accounts + a certificate)
web_tls_host = "0.0.0.0"
web_tls_port = 8443
tls_cert = "/etc/odid/tls/cert.pem"
tls_key = "/etc/odid/tls/key.pem"
min_free_mb = 200          # pause pcap/JSONL/CSV and the DB frame log below this much free disk
db_retention_days = 90     # delete database history older than this (0 = keep forever)
no_csv = false
max_sessions = 0

[alerts]
watchlist = "/home/pi/ids.txt"
webhook = "http://my-server/odid-webhook"

[serve]
autostart = [{ source = "wifi-dongle", interface = "wlan1" }, { source = "bladerf-wifi", gain = 40 }]
```

CLI flags always override config values. Under `sudo`, the invoking user's
config is used. Global options (`--log-dir`, `--no-pcap`, `-v`, …) may come
before or after the subcommand.

The systemd service that `odid init` / `install.sh` installs runs `odid
sniff` as root and reads its own root-owned copy, `/etc/odid/config.toml`
(via `ODID_CONFIG`). Edit it as root, then `sudo systemctl restart odid`. A
config named by `ODID_CONFIG` is ignored when running as root unless it is
root-owned and not group/world-writable. (The packaged service from
[DEPLOY.md](DEPLOY.md) is different: it runs `odid serve` as the
unprivileged `odid` user.)

---

## Command reference

### `odid init`

Interactive setup wizard: detects WiFi and Bluetooth adapters, writes
`~/.config/odid/config.toml`, and can configure monitor mode and install a
systemd service.

### `odid sniff [interface]` / `odid monitor [interface]`

Listen on one channel (default 6). The interface defaults to `[capture]
interface` from the config.

| Flag | Description |
|------|-------------|
| `-c/--channel N` | WiFi channel (default: 6) |
| `--lat LAT --lon LON` | Observer position for distances |
| `--watchlist FILE` | File of UAS/Operator IDs to alert on |
| `--filter EXPR` | Only record/show matching drones, everywhere (see [Frame filtering](#frame-filtering)) |
| `--tui` | Live table |
| `--web` | Web map dashboard |
| `--web-port PORT` | Web dashboard port (default: 8080) |
| `--web-host ADDR` | Web dashboard bind address (default: `127.0.0.1`) |
| `--drone-ttl SECS` | Evict drones not heard for N seconds (default: 300, 0 = never) |
| `--alert-webhook URL` | POST watchlist matches to this URL (once per drone per minute) |
| `--max-sessions N` | Keep only the N most recent log file groups |
| `--log-dir DIR` | Output directory (default: `logs/`) |
| `--no-pcap/--no-jsonl/--no-csv/--no-db` | Disable individual outputs |
| `--log-json` | Structured JSON log records on stderr |
| `-v/--verbose` | Debug logging |

### `odid scan [interface]`

Hop through the 2.4 GHz channels. Same flags as `sniff`, plus:

| Flag | Description |
|------|-------------|
| `-d/--dwell SECS` | Seconds per channel (default: 5) |
| `-c/--channels LIST` | Comma-separated channel list (default: 1-11) |

### `odid btsniff`

Bluetooth Remote ID (BT4 legacy + BT5 Long Range) via `bleak`. Flags:
`--adapter`, `--lat/--lon`, `--watchlist`, `--filter`, `--tui`, `--web`,
`--drone-ttl`, `--alert-webhook`.

### `odid bladerf`

Read decoded frames from a running BladeRF flowgraph over ZMQ
([BLADERF.md](BLADERF.md)). No `sudo` needed.

| Flag | Description |
|------|-------------|
| `--zmq ADDR` | WiFi flowgraph (default: `tcp://127.0.0.1:5555`) |
| `--zmq-bt ADDR` | BT LE flowgraph on a **second** SDR, read at the same time |

Plus `--lat/--lon`, `--watchlist`, `--filter`, `--tui`, `--web`,
`--drone-ttl`, `--alert-webhook`.

### `odid serve`

The web dashboard with live source control. Sources you start are
remembered in `serve-state.json` in the log directory and started again next
time; a source that fails (e.g. an unplugged SDR) is retried every 5-60 s
until you stop it. With no saved state, `[serve] autostart` decides what
starts. Under systemd it supports `Type=notify` and `WatchdogSec=`.

| Flag | Description |
|------|-------------|
| `--web-port PORT` | HTTP port (default: 8080) |
| `--host ADDR` | Plain-HTTP bind address (default: `127.0.0.1`). For the network use HTTPS (`web_tls`); plain HTTP off loopback is refused |
| `--allowed-host NAME` | Extra hostname the dashboard answers to (repeatable, added to `allowed_hosts`). Any other `Host` header is rejected, which blocks DNS-rebinding attacks |
| `--no-autostart` | Start with no sources |
| `--lat LAT --lon LON` | Observer position |
| `--drone-ttl SECS` | Drone eviction TTL (default: 300) |

| Source | Options |
|--------|---------|
| WiFi dongle | Interface (e.g. `wlan1`), channel |
| Built-in BT | Adapter (blank = system default) |
| BladeRF WiFi / BT | Gain, channel, hopping, monitor ([BLADERF.md](BLADERF.md#using-it)) |

**Sign-in and remote access.** With no accounts the dashboard has no
sign-in and stays on `127.0.0.1`. To put it on the network:

```bash
sudo odid passwd alice                 # admin: everything (prompts for a password)
sudo odid passwd bob --role viewer     # map and exports only
odid users                             # list (odid users --remove bob)
sudo odid tls                          # self-signed HTTPS certificate (prints its fingerprint)
```

Then set `web_tls = true` for HTTPS on port 8443, or publish the loopback
port with `tailscale serve`. Cookies are HttpOnly, SameSite=Strict and
Secure over HTTPS; writes need a CSRF token; failed sign-ins back off per IP
and per user; sign-ins and admin actions are logged with `AUDIT`. On the Pi
package, `odid provision` sets all of this up ([DEPLOY.md](DEPLOY.md)).

### `odid replay <file.pcap>`

Run a saved capture through the full pipeline, with a progress bar.

```bash
odid replay logs/capture.pcap --filter uas_id=prefix:ABC --lat 51.5 --lon -0.1
odid replay logs/capture.pcap --rate 0.1 --tui
```

Flags: `--rate SECS` (delay between frames, 0 = fastest), `--lat/--lon`,
`--watchlist`, `--filter`, `--tui`, `--web`.

### `odid query`

Query the SQLite drone database.

```bash
odid query --since 1h
odid query --mac aa:bb:cc:dd:ee:ff --frames
odid query --since 2h --json
```

| Flag | Description |
|------|-------------|
| `--db PATH` | Database (default: `logs/odid_drones.db`) |
| `--since TIMESPEC` | Time window: `1h`, `30m`, `2d` |
| `--uas-id ID` | UAS ID (partial match) |
| `--mac MAC` | MAC address (exact) |
| `--anomalies` | Only drones with anomaly flags |
| `--frames` | Frame log instead of the drone summary |
| `--stats` | Database statistics |
| `--limit N` | Maximum rows (default: 50) |
| `--json` | JSON output |

### `odid export`

Flight tracks as KML and/or GPX (also from the dashboard toolbar).

```bash
odid export --db logs/odid_drones.db --format kml --out tracks.kml
odid export logs/odid_session_20260324.jsonl --format gpx
odid export --format both
```

### Other commands

| Command | Does |
|---|---|
| `odid setup <iface>` | Put an interface in monitor mode |
| `odid diagnose <iface>` | Check an interface is ready to capture |
| `odid interfaces` | List WiFi interfaces with mode and channel |
| `odid passwd`, `odid users`, `odid tls` | Dashboard accounts and certificate (above) |
| `odid provision` | Configure the packaged Pi service ([DEPLOY.md](DEPLOY.md)) |

---

## Frame filtering

`--filter EXPR` is checked at startup; a typo gets suggestions
(`Unknown filter field 'ua_tipe'. Did you mean: ua_type?`).

| Expression | Meaning |
|-----------|---------|
| `ua_type=Multirotor` | Only multirotors (partial match, case-insensitive) |
| `uas_id=ABC123` | Exact UAS ID |
| `uas_id=prefix:ABC` | UAS ID starting with `ABC` |
| `status=Airborne` | Only airborne drones (also `Ground`, `Emergency`) |
| `operator_id=FLEET` | Operator ID containing `FLEET` |

## Watchlist and webhook alerts

A watchlist is plain text, one ID per line, `#` for comments. Matches are
checked against UAS ID and Operator ID (case-insensitive), printed as a
bright alert, logged at WARNING and optionally POSTed to `--alert-webhook`:

```json
{"event": "watchlist_match", "mac": "aa:bb:cc:dd:ee:ff", "hits": ["UAS ID=1ABC234DEF56789"]}
```

Webhooks are sent from a background thread with a 5 s timeout.

## Anomaly detection

Each anomaly is recorded once per drone, with a first-seen time, in the
console (`[WARN]`), the dashboard and the database (`anomaly_flags`).

| Condition | Threshold |
|-----------|-----------|
| Null-island GPS | Lat = 0.0 and Lon = 0.0 |
| Implausible speed | > 100 m/s horizontal |
| Implausible altitude | > 10,000 m MSL |
| Missing Basic ID | None after 10 frames |

## Output files

Written to `--log-dir` (default `logs/`):

| File | Contents |
|------|----------|
| `odid_session_<ts>.jsonl` | One JSON record per frame |
| `odid_capture_<ts>.pcap` | Raw capture, replayable with `odid replay` |
| `odid_locations_<ts>.csv` | Per-frame CSV summary |
| `odid_drones.db` | SQLite database, cumulative across sessions |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `externally-managed-environment` | Use `venv/bin/pip`, not `pip` |
| `ModuleNotFoundError` after `sudo` | Use `sudo venv/bin/odid`; sudo doesn't inherit an activated venv |
| `ModuleNotFoundError: rich` / `aiohttp` / `bleak` | `venv/bin/pip install -e '.[all]'` |
| `wlan1 is not in monitor mode` | `sudo odid setup wlan1` |
| Monitor mode won't stick, or "interface busy" | `sudo airmon-ng check kill`, then `setup` again |
| `Permission denied` | Capture commands need `sudo` |
| No WiFi frames | Check `iw dev wlan1 info` says `type monitor`; try `scan` instead of `sniff`; check the adapter supports monitor mode (`iw list`); run with `-v` |
| No Bluetooth frames | `hciconfig` shows the adapter `UP RUNNING`; `bleak` installed; run with `-v` |
| BladeRF flowgraph says `gnuradio not installed` but it is | The venv lacks `--system-site-packages`: `rm -rf venv` and recreate it |

Debug logging: `sudo odid sniff wlan1 -v 2>&1 | tee debug.log`, or
`--log-json` for structured records.

---

## Technical details

**WiFi NAN action frame:**

```
[RadioTap Header]
[802.11 Management Frame: Action]
  Category: Public (0x04)
  Action: Vendor Specific (0x09)
  OUI: 0xFA0BBC (WiFi Alliance)
  OUI Type: 0x0D (OpenDroneID)
  [Message Counter / Proto Version]
  [ODID Message Data: N × 25 bytes]
    Byte 0: [msg_type:4][proto_version:4]
    Bytes 1–24: type-specific payload
```

**Bluetooth advertising:**

```
AD Type 0x16 (Service Data – 16-bit UUID)
  UUID: 0xFFFA (ASTM Remote ID)
  [0]   App code = 0x0D
  [1]   Counter  = [counter:4][proto_version:4]
  [2..] N × 25-byte ODID messages (same encoding as WiFi)
```

**Code layout:**

```
odid/
├── cli.py, config.py        # Typer CLI, TOML config
├── provision.py, sdnotify.py  # Pi package setup, systemd notify/watchdog
├── capture/                 # wifi (scapy), bluetooth (bleak), bladerf (ZMQ), interface,
│                            # manager + autostart (live sources for odid serve)
├── decode/                  # frame extraction, ASTM F3411 message decoders
├── track/                   # per-drone state + anomalies, SQLite
├── output/                  # console, TUI, web dashboard server, JSONL/CSV/pcap, KML/GPX
├── web/                     # dashboard APIs: auth, TLS, settings, health, logs, captures, actions
│   └── static/              # dashboard HTML/CSS/JS (Leaflet bundled)
└── flowgraphs/              # GNU Radio BladeRF receivers, BLE DSP, signal monitor
packaging/                   # .deb build, systemd units, polkit, udev, firewall, installer
tests/                       # pytest suite
```

Memory stays bounded on long runs: location history is a 1000-point deque
per drone, stale drones are evicted every 60 s, pcap writes are buffered
(64 KB), the database commits every 100 frames or 2 s, and the dashboard
sends only changed fields over its WebSocket.

---

## Legal notice

This tool is for legitimate purposes such as security research, authorised
monitoring, education and regulatory compliance checks. Follow your local
laws on wireless monitoring and drone tracking.

## License

Educational and research use.
