# Deploying ODID Sniffer on a Raspberry Pi

The `odid-sniffer` `.deb` turns a Pi running **Raspberry Pi OS / Debian 13
(trixie)** into a self-starting Remote ID sensor:

- **Service:** `odid.service` runs `odid serve` as the unprivileged `odid` user.
- **Privileges:** only `CAP_NET_RAW` and `CAP_NET_ADMIN`, with systemd sandboxing.
- **Radios:** the sources you choose start at boot, and failed ones are retried (for example an SDR that is unplugged and plugged back in).
- **Updates:** apt, or the `odid-update.service` oneshot.

A git checkout with `install.sh` is still the development setup. Bookworm and
older are not supported by the package (their python3-typer and aiohttp are
too old).

## 1. Build the package

On any Debian/Raspberry Pi OS machine (no root needed):

```bash
packaging/build-deb.sh            # -> dist/odid-sniffer_<version>-1_all.deb
```

The package is `Architecture: all`. The Python dependencies (scapy, aiohttp,
typer, rich, pyzmq, bleak) and GNU Radio / gr-osmosdr / bladeRF come from apt,
so there is no venv.

## 2. Install on a Pi

Copy the `.deb` over, then:

```bash
sudo bash packaging/get-odid.sh --deb ./odid-sniffer_4.1.8-1_all.deb
# or without the helper:
sudo apt install ./odid-sniffer_4.1.8-1_all.deb && sudo odid provision
```

`odid provision` writes `/etc/odid/config.toml` and restarts the service. It:

- **Detects radios:** WiFi interfaces, a BladeRF and Bluetooth adapters. It
  asks which ones the service should run, and refuses to use the interface
  that carries your network.
- **Creates the first admin account,** which is required before anything is
  reachable from the network.
- **Offers remote access:**
  - **LAN:** HTTPS on port 8443 with a self-signed certificate. It prints the
    certificate's SHA-256 fingerprint; compare it with what your browser shows
    on the first visit.
  - **Tailscale:** if Tailscale is installed and logged in, it runs
    `tailscale serve`, so `https://<pi>.<tailnet>.ts.net/` works from any of
    your devices with a real certificate, without opening any port.

For a headless setup:

```bash
echo 'a-long-password' | sudo odid provision -y --admin alice --password-stdin \
    --dongle wlan1 --bladerf wifi --lat 41.75 --lon -87.94 --lan --tailscale
```

With `-y` and no `--password-stdin`, a random admin password is generated and
printed once.

### Accounts

```bash
sudo odid passwd alice                 # create, or change a password (signs that user out)
sudo odid passwd bob --role viewer     # viewers see the map and exports; no radio control
sudo odid users                        # list;  sudo odid users --remove bob
```

In the dashboard, **Account** (next to your name) lets anyone change their
own password; admins can also add viewers, reset their passwords and remove
them there. Admin accounts can only be created, changed or removed on the
sensor with `sudo odid passwd` / `sudo odid users`, so a stolen browser
session can't create another admin.

Accounts live in `/var/lib/odid/auth.json` (mode 0600). The running service
picks up changes without a restart. Sign-ins, sign-outs, failed attempts and
every account, settings, capture and restart/reboot/update action appear in
`journalctl -u odid | grep AUDIT`.

## 3. Signed apt repository (fleet installs and updates)

```bash
gpg --quick-gen-key "ODID packages <you@example.com>" ed25519 sign never
packaging/make-apt-repo.sh public/ <KEY-ID> dist/*.deb
# upload public/ to any static HTTPS host (GitHub Pages, S3, nginx…)
```

`make-apt-repo.sh` prints the signing key's fingerprint. Publish it next to
the install command (somewhere other than the repository host), so a
compromised host can't swap the key. Then on each Pi:

```bash
curl -fsSL https://host/path/get-odid.sh | \
    sudo ODID_APT_REPO=https://host/path ODID_KEY_FPR=<fingerprint> bash
```

Later updates: `sudo apt upgrade`, or `sudo systemctl start odid-update`.
The oneshot service writes its result to `/run/odid-update/status.json`, and the
dashboard's Update button will use it.

## Files and operation

| Path | What |
|---|---|
| `/etc/odid/config.toml` | settings (`root:odid` 0640: the service reads it, only root edits it, e.g. with `odid provision`) |
| `/var/lib/odid/settings.toml` | settings changed in the dashboard (**Settings** panel, admins only). Each key overrides the same key in `config.toml`; **reset** next to a setting removes the override |
| `/var/lib/odid/` | database, session logs, `serve-state.json` (sources to resume), `auth.json` (accounts) |
| `/etc/odid/tls/` | HTTPS certificate and key (key `root:odid` 0640) |
| `/usr/lib/systemd/system/odid*.service` | units |
| `/usr/share/polkit-1/rules.d/50-odid.rules` | the only privileged actions `odid` may request: restart itself, start the updater, reboot |
| `/etc/NetworkManager/conf.d/90-odid-capture.conf` | written by `odid provision`: NetworkManager leaves the capture dongle alone |
| `/usr/lib/udev/rules.d/89-odid-bladerf.rules` | BladeRF access for group `plugdev` |

```bash
systemctl status odid                # state
journalctl -u odid -f                # logs
sudo systemctl restart odid          # after editing the config
```

The service refuses to put the dashboard on the network without at least one
account. It also refuses plain HTTP off loopback (`allow_insecure_http = true`
overrides this), so passwords never cross the network unencrypted. Without
remote access, use an SSH tunnel: `ssh -L 8080:127.0.0.1:8080 pi@<pi>`.

`sudo odid tls --regenerate` replaces the certificate.
`sudo odid tls --tailscale-cert` uses the Tailscale-issued certificate for
the LAN listener as well.

### Staying reachable (same WiFi or Tailscale)

**Same WiFi.** Open `https://<hostname>.local:8443/` or `https://<ip>:8443/`.
- **Guest networks** usually block devices from reaching each other, so this
  fails on a guest SSID even though the Pi is online. Put the Pi on a trusted
  network, or use Tailscale, which works through guest networks.
- **WiFi power saving** makes a Pi drop off the network now and then.
  `odid provision` offers to turn it off (`--wifi-powersave-off`). By hand:
  `sudo nmcli connection modify <ssid> 802-11-wireless.powersave 2`.
- **Give each sensor its own name** (for example
  `sudo hostnamectl set-hostname odid-01`), then run
  `sudo odid tls --regenerate` so the certificate has the new name. A fixed
  DHCP lease on the router keeps the IP address stable too.
- The certificate lists the IP addresses the Pi had when it was made. If an
  address changes, the System tab shows a warning; fix it with
  `sudo odid tls --regenerate`.

**Tailscale (from anywhere).**

```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up --ssh
sudo odid provision --tailscale        # safe to re-run
```

Then open `https://<pi>.<tailnet>.ts.net/` from any device signed in to your
tailnet. In the Tailscale admin console, **disable key expiry** for the
sensor; otherwise it leaves the tailnet after 180 days. If `tailscale serve`
stops publishing the dashboard, the System tab shows a warning.

**Sign-in is never switched off at runtime.** A dashboard that started with
a network listener (or behind `tailscale serve`) answers 503 to every request
if its last account disappears. `odid users --remove` refuses to delete the
last account unless you add `--force`.

### Firewall (optional)

The package ships a firewall, **off by default**. It allows SSH and the
dashboard (8443) from the LAN, everything over Tailscale, DHCP, mDNS and
ping, and drops all other incoming traffic. VNC (5900) then works over
Tailscale only. Capture is not affected.

```bash
sudo nft -f /usr/share/odid/odid-firewall.nft      # try it first (gone after a reboot)
sudo systemctl enable --now odid-firewall          # keep it
sudo systemctl disable --now odid-firewall         # turn it off again
```

It only adds its own table (`inet odid_fw`) and never flushes other rules,
so Tailscale's firewall rules are left alone. Don't add it to
`/etc/nftables.conf`: that file starts with `flush ruleset`, and reloading
it would also wipe Tailscale's rules.

### Hardware watchdog

`odid.service` restarts after a crash or hang. For a frozen kernel,
Raspberry Pi OS already enables the hardware watchdog (60 s, from
`/usr/lib/systemd/system.conf.d/40-rpi-enable-watchdog.conf`). Check it with
`systemctl show -p RuntimeWatchdogUSec` (expect `1min`). On another OS, set
`RuntimeWatchdogSec=60` in `/etc/systemd/system.conf` and reboot.

**Remove:** `sudo apt remove odid-sniffer` keeps your data and settings.
`sudo apt purge odid-sniffer` also deletes `/etc/odid` and `/var/lib/odid`.
